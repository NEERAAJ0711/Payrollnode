import { pgTable, text, serial, integer, boolean, timestamp, decimal, date, time, pgEnum, unique } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum('user_role', ['system_admin', 'admin', 'employee']);
export const employeeStatusEnum = pgEnum('employee_status', ['active', 'inactive', 'probation', 'terminated']);
export const jobStatusEnum = pgEnum('job_status', ['draft', 'active', 'closed', 'cancelled']);
export const applicationStatusEnum = pgEnum('application_status', ['pending', 'reviewing', 'interviewed', 'offered', 'hired', 'rejected']);
export const permissionRequestStatusEnum = pgEnum('permission_request_status', ['pending', 'approved', 'rejected']);
export const permissionTypeEnum = pgEnum('permission_type', [
  // Employee Management
  'employee_create', 'employee_edit', 'employee_delete', 'employee_view', 'employee_profile_edit',
  // Job Management  
  'job_create', 'job_edit', 'job_delete', 'job_view', 'job_application_review',
  // Department Management
  'department_create', 'department_edit', 'department_delete', 'department_view',
  // Attendance Management
  'attendance_view_all', 'attendance_edit', 'attendance_delete', 'attendance_reports',
  // Payroll Management
  'payroll_view', 'payroll_edit', 'payroll_generate', 'payroll_finalize', 'payroll_reports',
  // Leave Management
  'leave_view_all', 'leave_approve_level1', 'leave_approve_level2', 'leave_approve_final', 'leave_reject',
  // Advance Request Management
  'advance_view_all', 'advance_approve_level1', 'advance_approve_level2', 'advance_approve_final', 'advance_reject', 'advance_mark_paid',
  // Recruitment Management
  'recruitment_view', 'recruitment_manage', 'interview_schedule', 'job_offer_create',
  // Company Settings
  'company_settings', 'company_profile_edit', 'company_approval',
  // User Management
  'user_create', 'user_edit', 'user_delete', 'user_view', 'user_role_change',
  // System Administration
  'system_admin_access', 'permission_manage', 'audit_logs_view'
]);
export const companyStatusEnum = pgEnum('company_status', ['pending', 'approved', 'rejected', 'suspended']);
export const companyTypeEnum = pgEnum('company_type', ['proprietorship', 'partnership', 'private_limited', 'limited']);
export const leaveTypeEnum = pgEnum('leave_type', ['casual', 'sick', 'earned', 'maternity', 'paternity', 'comp_off', 'lwp']);
export const leaveStatusEnum = pgEnum('leave_status', ['pending', 'approved', 'rejected', 'cancelled']);
export const advanceStatusEnum = pgEnum('advance_status', ['pending', 'approved', 'rejected', 'cancelled', 'paid']);
export const approvalLevelEnum = pgEnum('approval_level', ['level_1', 'level_2', 'level_3', 'final']);
export const salaryEntryModeEnum = pgEnum('salary_entry_mode', ['gross', 'ctc', 'earning_heads']);

// Companies table
export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  address: text("address"),
  type: companyTypeEnum("type"),
  gstPan: text("gst_pan"),
  pfNo: text("pf_no"),
  esicNo: text("esic_no"),
  cinNo: text("cin_no"),
  authorizedPersonName: text("authorized_person_name"),
  authorizedPersonContact: text("authorized_person_contact"),
  website: text("website"),
  industry: text("industry"),
  size: text("size"),
  logo: text("logo"),
  status: companyStatusEnum("status").default('pending').notNull(),
  subscriptionPlan: text("subscription_plan").default('basic'),
  profileComplete: boolean("profile_complete").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: userRoleEnum("role").notNull().default('employee'),
  companyId: integer("company_id").references(() => companies.id),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Departments table
export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  managerId: integer("manager_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Employees table
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  employeeId: text("employee_id").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  departmentId: integer("department_id").references(() => departments.id),
  position: text("position"),
  salary: decimal("salary"),
  hireDate: timestamp("hire_date"),
  status: employeeStatusEnum("status").default('active').notNull(),
  managerId: integer("manager_id"),
  address: text("address"),
  dateOfBirth: timestamp("date_of_birth"),
  emergencyContact: text("emergency_contact"),
  emergencyPhone: text("emergency_phone"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Employee Payroll table
export const employeePayroll = pgTable("employee_payroll", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  
  // Payroll toggles
  epfEnabled: boolean("epf_enabled").default(false),
  employeePfLimit: boolean("employee_pf_limit").default(false),
  employerPfLimit: boolean("employer_pf_limit").default(false),
  esicEnabled: boolean("esic_enabled").default(false),
  lwfEnabled: boolean("lwf_enabled").default(false),
  otEnabled: boolean("ot_enabled").default(false),
  doubleOt: boolean("double_ot").default(false),
  vpfEnabled: boolean("vpf_enabled").default(false),
  vpfAmount: decimal("vpf_amount"),
  tdsEnabled: boolean("tds_enabled").default(false),
  tdsAmount: decimal("tds_amount"),
  ptEnabled: boolean("pt_enabled").default(false),
  ptAmount: decimal("pt_amount"),
  bonusEnabled: boolean("bonus_enabled").default(false),
  bonusMonthlyPayment: boolean("bonus_monthly_payment").default(false),
  
  // Salary structure
  entryType: text("entry_type").default('gross'), // 'ctc', 'gross', 'earning_heads'
  ctcValue: decimal("ctc_value"),
  grossValue: decimal("gross_value"),
  
  // Earning heads
  earningHead1: decimal("earning_head1"), // Basic Salary
  earningHead2: decimal("earning_head2"), // HRA
  earningHead3: decimal("earning_head3"), // Conveyance Allowance
  earningHead4: decimal("earning_head4"), // Other Allowances
  
  // Employee contribution amounts
  epfEmployeeAmount: decimal("epf_employee_amount"),
  esicEmployeeAmount: decimal("esic_employee_amount"),
  lwfEmployeeAmount: decimal("lwf_employee_amount"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Employee Salary Structures table for month-wise historical tracking
export const employeeSalaryStructures = pgTable("employee_salary_structures", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  year: integer("year").notNull(),
  month: integer("month").notNull(), // 1-12
  
  // Payroll toggles
  epfEnabled: boolean("epf_enabled").default(false),
  employeePfLimit: boolean("employee_pf_limit").default(false),
  employerPfLimit: boolean("employer_pf_limit").default(false),
  esicEnabled: boolean("esic_enabled").default(false),
  lwfEnabled: boolean("lwf_enabled").default(false),
  otEnabled: boolean("ot_enabled").default(false),
  doubleOt: boolean("double_ot").default(false),
  vpfEnabled: boolean("vpf_enabled").default(false),
  vpfAmount: decimal("vpf_amount"),
  tdsEnabled: boolean("tds_enabled").default(false),
  tdsAmount: decimal("tds_amount"),
  ptEnabled: boolean("pt_enabled").default(false),
  ptAmount: decimal("pt_amount"),
  bonusEnabled: boolean("bonus_enabled").default(false),
  bonusMonthlyPayment: boolean("bonus_monthly_payment").default(false),
  
  // Salary structure
  entryType: text("entry_type").default('gross'), // 'ctc', 'gross', 'earning_heads'
  ctcValue: decimal("ctc_value"),
  grossValue: decimal("gross_value"),
  
  // Earning heads
  earningHead1: decimal("earning_head1"), // Basic Salary
  earningHead2: decimal("earning_head2"), // HRA
  earningHead3: decimal("earning_head3"), // Conveyance Allowance
  earningHead4: decimal("earning_head4"), // Other Allowances
  
  // Employee contribution amounts
  epfEmployeeAmount: decimal("epf_employee_amount"),
  esicEmployeeAmount: decimal("esic_employee_amount"),
  lwfEmployeeAmount: decimal("lwf_employee_amount"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  // Unique constraint to ensure only one salary structure per employee per month
  employeeMonthlyUnique: unique().on(table.employeeId, table.year, table.month),
}));

// Salary Components - Define available salary components (Basic, HRA, etc.)
export const salaryComponents = pgTable("salary_components", {
  id: serial("id").primaryKey(),
  componentKey: text("component_key").notNull().unique(), // 'basic', 'hra', 'conveyance', etc.
  displayName: text("display_name").notNull(), // 'Basic Salary', 'House Rent Allowance', etc.
  isTaxable: boolean("is_taxable").default(true),
  isEmployerCost: boolean("is_employer_cost").default(false), // For CTC calculations (PF employer contribution, etc.)
  isDefault: boolean("is_default").default(false), // System-provided components
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Company Salary Component Configuration - Percentage settings per company
export const companySalaryComponentConfig = pgTable("company_salary_component_config", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  componentKey: text("component_key").references(() => salaryComponents.componentKey).notNull(),
  entryMode: salaryEntryModeEnum("entry_mode").notNull(), // Which mode this config applies to
  percentageOfGross: decimal("percentage_of_gross"), // For gross mode calculations
  percentageOfCTC: decimal("percentage_of_ctc"), // For CTC mode calculations
  priority: integer("priority").default(0), // Calculation order
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  // Unique constraint per company, component, and mode
  companyComponentModeUnique: unique().on(table.companyId, table.componentKey, table.entryMode),
}));

// Employee Salary Component Values - Store individual component amounts
export const employeeSalaryComponentValues = pgTable("employee_salary_component_values", {
  id: serial("id").primaryKey(),
  structureId: integer("structure_id").references(() => employeeSalaryStructures.id).notNull(),
  componentKey: text("component_key").references(() => salaryComponents.componentKey).notNull(),
  amount: decimal("amount").notNull(),
  calculatedFromPercentage: boolean("calculated_from_percentage").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  // Unique constraint per structure and component
  structureComponentUnique: unique().on(table.structureId, table.componentKey),
}));

// Jobs table
export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  departmentId: integer("department_id").references(() => departments.id),
  requirements: text("requirements"),
  salaryMin: decimal("salary_min"),
  salaryMax: decimal("salary_max"),
  location: text("location"),
  employmentType: text("employment_type").default('full-time'),
  status: jobStatusEnum("status").default('draft').notNull(),
  postedBy: integer("posted_by").references(() => users.id).notNull(),
  postedAt: timestamp("posted_at"),
  closingDate: timestamp("closing_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Job Applications table
export const jobApplications = pgTable("job_applications", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").references(() => jobs.id).notNull(),
  applicantName: text("applicant_name").notNull(),
  applicantEmail: text("applicant_email").notNull(),
  applicantPhone: text("applicant_phone"),
  resume: text("resume"),
  coverLetter: text("cover_letter"),
  status: applicationStatusEnum("status").default('pending').notNull(),
  appliedAt: timestamp("applied_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Enums for attendance
export const attendanceStatusEnum = pgEnum('attendance_status', ['present', 'absent', 'half_day', 'late', 'early_leave', 'comp_off', 'paid_leave', 'unpaid_leave']);
export const verificationType = pgEnum('verification_type', ['face', 'location', 'manual', 'biometric']);

// Attendance table - Enhanced for comprehensive tracking
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  date: date("date").notNull(),
  checkIn: timestamp("check_in"),
  checkOut: timestamp("check_out"),
  hoursWorked: decimal("hours_worked", { precision: 4, scale: 2 }),
  status: attendanceStatusEnum("status").default('absent').notNull(),
  isPresent: boolean("is_present").default(false).notNull(),
  // Face verification
  faceVerified: boolean("face_verified").default(false),
  faceImage: text("face_image"), // Base64 image for verification
  faceConfidence: decimal("face_confidence", { precision: 5, scale: 2 }),
  // Location verification
  locationVerified: boolean("location_verified").default(false),
  checkInLatitude: decimal("check_in_latitude", { precision: 10, scale: 7 }),
  checkInLongitude: decimal("check_in_longitude", { precision: 10, scale: 7 }),
  checkOutLatitude: decimal("check_out_latitude", { precision: 10, scale: 7 }),
  checkOutLongitude: decimal("check_out_longitude", { precision: 10, scale: 7 }),
  workLocation: text("work_location"), // Detected location name
  // Verification details
  verificationType: verificationType("verification_type").default('manual'),
  deviceInfo: text("device_info"), // Device used for check-in
  ipAddress: text("ip_address"),
  notes: text("notes"),
  approvedBy: integer("approved_by").references(() => users.id),
  approvedAt: timestamp("approved_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Monthly attendance summary table
export const monthlyAttendance = pgTable("monthly_attendance", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  year: integer("year").notNull(),
  month: integer("month").notNull(), // 1-12
  totalWorkingDays: integer("total_working_days").notNull(),
  presentDays: integer("present_days").default(0),
  absentDays: integer("absent_days").default(0),
  halfDays: integer("half_days").default(0),
  lateDays: integer("late_days").default(0),
  paidLeaveDays: integer("paid_leave_days").default(0),
  unpaidLeaveDays: integer("unpaid_leave_days").default(0),
  compOffDays: integer("comp_off_days").default(0),
  weeklyOffDays: integer("weekly_off_days").default(0),
  holidayDays: integer("holiday_days").default(0),
  payableDays: integer("payable_days").default(0), // Present + Paid Leave + Weekly Off + Comp Off + Holidays
  totalHoursWorked: decimal("total_hours_worked", { precision: 6, scale: 2 }),
  averageCheckInTime: time("average_check_in_time"),
  averageCheckOutTime: time("average_check_out_time"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Face templates for verification (store encrypted face embeddings)
export const faceTemplates = pgTable("face_templates", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  templateData: text("template_data").notNull(), // Encrypted face embedding
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Attendance locations (authorized work locations)
export const attendanceLocations = pgTable("attendance_locations", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
  radius: integer("radius").default(100), // Allowed radius in meters
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Permissions table
export const permissions = pgTable("permissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  category: text("category").notNull(),
  module: text("module").notNull(), // e.g., 'employees', 'payroll', 'attendance'
  isActive: boolean("is_active").default(true),
  requiresApproval: boolean("requires_approval").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User Permissions table (direct permission assignments)
export const userPermissions = pgTable("user_permissions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  permissionId: integer("permission_id").references(() => permissions.id).notNull(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  grantedBy: integer("granted_by").references(() => users.id).notNull(),
  grantedAt: timestamp("granted_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").default(true),
  reason: text("reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Permission Templates (predefined sets of permissions for roles)
export const permissionTemplates = pgTable("permission_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  role: userRoleEnum("role").notNull(),
  permissionIds: text("permission_ids").notNull(), // JSON array of permission IDs
  isDefault: boolean("is_default").default(false),
  createdBy: integer("created_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Employee Profiles table (for employees not yet hired by any company)
export const employeeProfiles = pgTable("employee_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  fatherName: text("father_name"),
  presentAddress: text("present_address"),
  permanentAddress: text("permanent_address"),
  currentSalary: text("current_salary"),
  expectedSalary: text("expected_salary"),
  noticePeriod: text("notice_period"),
  primaryContact: text("primary_contact"),
  alternativeContact: text("alternative_contact"),
  totalExperience: text("total_experience"),
  speciality: text("speciality"),
  skills: text("skills"),
  experience: text("experience"),
  phone: text("phone"),
  address: text("address"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Employment History table
export const employmentHistory = pgTable("employment_history", {
  id: serial("id").primaryKey(),
  employeeProfileId: integer("employee_profile_id").references(() => employeeProfiles.id).notNull(),
  companyName: text("company_name").notNull(),
  joinDate: date("join_date"),
  leftDate: date("left_date"),
  reasonForLeaving: text("reason_for_leaving"),
  jobDescription: text("job_description"),
  department: text("department"),
  designation: text("designation"),
  lastDrawnSalary: text("last_drawn_salary"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// KYC Details table
export const kycDetails = pgTable("kyc_details", {
  id: serial("id").primaryKey(),
  employeeProfileId: integer("employee_profile_id").references(() => employeeProfiles.id).notNull(),
  aadharNo: text("aadhar_no"),
  panNo: text("pan_no"),
  bankAccountNo: text("bank_account_no"),
  ifscCode: text("ifsc_code"),
  uanNo: text("uan_no"),
  esicNo: text("esic_no"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Family Details table
export const familyDetails = pgTable("family_details", {
  id: serial("id").primaryKey(),
  employeeProfileId: integer("employee_profile_id").references(() => employeeProfiles.id).notNull(),
  memberName: text("member_name").notNull(),
  relation: text("relation").notNull(),
  aadharNo: text("aadhar_no"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Role permissions table
export const rolePermissions = pgTable("role_permissions", {
  id: serial("id").primaryKey(),
  role: userRoleEnum("role").notNull(),
  permissionId: integer("permission_id").references(() => permissions.id).notNull(),
  companyId: integer("company_id").references(() => companies.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Permission requests table (matching current database structure)
export const permissionRequests = pgTable("permission_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  requestedBy: integer("requested_by").references(() => users.id).notNull(),
  permissionType: permissionTypeEnum("permission_type").notNull(),
  reason: text("reason").notNull(),
  status: permissionRequestStatusEnum("status").default('pending').notNull(),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  expiresAt: timestamp("expires_at"),
  companyId: integer("company_id").references(() => companies.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// User activities table for audit trail
export const userActivities = pgTable("user_activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  companyId: integer("company_id").references(() => companies.id),
  action: text("action").notNull(),
  entityType: text("entity_type"),
  entityId: integer("entity_id"),
  details: text("details"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Interviews table
export const interviews = pgTable("interviews", {
  id: serial("id").primaryKey(),
  jobApplicationId: integer("job_application_id").references(() => jobApplications.id).notNull(),
  scheduledAt: timestamp("scheduled_at").notNull(),
  duration: integer("duration").default(60), // minutes
  location: text("location"),
  meetingLink: text("meeting_link"),
  interviewerIds: text("interviewer_ids"), // JSON array of user IDs
  status: text("status").default('scheduled').notNull(), // scheduled, completed, cancelled, rescheduled
  notes: text("notes"),
  rating: integer("rating"), // 1-10 scale
  result: text("result"), // pass, fail, pending
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Job offers table
export const jobOffers = pgTable("job_offers", {
  id: serial("id").primaryKey(),
  jobApplicationId: integer("job_application_id").references(() => jobApplications.id).notNull(),
  offeredSalary: text("offered_salary"),
  startDate: timestamp("start_date"),
  expiryDate: timestamp("expiry_date"),
  terms: text("terms"), // JSON object with offer terms
  status: text("status").default('pending').notNull(), // pending, accepted, rejected, withdrawn
  acceptedAt: timestamp("accepted_at"),
  rejectedAt: timestamp("rejected_at"),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Relations
export const companiesRelations = relations(companies, ({ many }) => ({
  users: many(users),
  departments: many(departments),
  employees: many(employees),
  jobs: many(jobs),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  company: one(companies, { fields: [users.companyId], references: [companies.id] }),
  employee: one(employees, { fields: [users.id], references: [employees.userId] }),
  postedJobs: many(jobs, { relationName: "job_poster" }),
  reviewedApplications: many(jobApplications, { relationName: "application_reviewer" }),
  permissionRequests: many(permissionRequests, { relationName: "permission_user" }),
  requestedPermissions: many(permissionRequests, { relationName: "permission_requester" }),
  level1ReviewedPermissions: many(permissionRequests, { relationName: "permission_level1_reviewer" }),
  level2ReviewedPermissions: many(permissionRequests, { relationName: "permission_level2_reviewer" }),
  finalReviewedPermissions: many(permissionRequests, { relationName: "permission_final_reviewer" }),
  activities: many(userActivities),
}));

export const departmentsRelations = relations(departments, ({ one, many }) => ({
  company: one(companies, { fields: [departments.companyId], references: [companies.id] }),
  manager: one(employees, { fields: [departments.managerId], references: [employees.id] }),
  employees: many(employees),
  jobs: many(jobs),
}));

export const employeesRelations = relations(employees, ({ one, many }) => ({
  user: one(users, { fields: [employees.userId], references: [users.id] }),
  company: one(companies, { fields: [employees.companyId], references: [companies.id] }),
  department: one(departments, { fields: [employees.departmentId], references: [departments.id] }),
  manager: one(employees, { fields: [employees.managerId], references: [employees.id], relationName: "employee_manager" }),
  subordinates: many(employees, { relationName: "employee_manager" }),
  managedDepartments: many(departments, { relationName: "department_manager" }),
  attendance: many(attendance),
  salaryStructures: many(employeeSalaryStructures),
}));

export const jobsRelations = relations(jobs, ({ one, many }) => ({
  company: one(companies, { fields: [jobs.companyId], references: [companies.id] }),
  department: one(departments, { fields: [jobs.departmentId], references: [departments.id] }),
  postedBy: one(users, { fields: [jobs.postedBy], references: [users.id], relationName: "job_poster" }),
  applications: many(jobApplications),
}));

export const jobApplicationsRelations = relations(jobApplications, ({ one, many }) => ({
  job: one(jobs, { fields: [jobApplications.jobId], references: [jobs.id] }),
  reviewedBy: one(users, { fields: [jobApplications.reviewedBy], references: [users.id], relationName: "application_reviewer" }),
  interviews: many(interviews),
  offers: many(jobOffers),
}));

export const interviewsRelations = relations(interviews, ({ one }) => ({
  jobApplication: one(jobApplications, { fields: [interviews.jobApplicationId], references: [jobApplications.id] }),
}));

export const jobOffersRelations = relations(jobOffers, ({ one }) => ({
  jobApplication: one(jobApplications, { fields: [jobOffers.jobApplicationId], references: [jobApplications.id] }),
}));

export const attendanceRelations = relations(attendance, ({ one }) => ({
  employee: one(employees, { fields: [attendance.employeeId], references: [employees.id] }),
}));

export const employeeSalaryStructuresRelations = relations(employeeSalaryStructures, ({ one }) => ({
  employee: one(employees, { fields: [employeeSalaryStructures.employeeId], references: [employees.id] }),
  company: one(companies, { fields: [employeeSalaryStructures.companyId], references: [companies.id] }),
}));

export const permissionsRelations = relations(permissions, ({ many }) => ({
  rolePermissions: many(rolePermissions),
}));

export const rolePermissionsRelations = relations(rolePermissions, ({ one }) => ({
  permission: one(permissions, { fields: [rolePermissions.permissionId], references: [permissions.id] }),
  company: one(companies, { fields: [rolePermissions.companyId], references: [companies.id] }),
}));

export const permissionRequestsRelations = relations(permissionRequests, ({ one }) => ({
  user: one(users, { fields: [permissionRequests.userId], references: [users.id], relationName: "permission_user" }),
  requestedByUser: one(users, { fields: [permissionRequests.requestedBy], references: [users.id], relationName: "permission_requester" }),
  reviewedByUser: one(users, { fields: [permissionRequests.reviewedBy], references: [users.id], relationName: "permission_reviewer" }),
  company: one(companies, { fields: [permissionRequests.companyId], references: [companies.id] }),
}));

export const employeeProfilesRelations = relations(employeeProfiles, ({ one, many }) => ({
  user: one(users, { fields: [employeeProfiles.userId], references: [users.id] }),
  employmentHistory: many(employmentHistory),
  kycDetails: one(kycDetails),
  familyDetails: many(familyDetails),
}));

export const employmentHistoryRelations = relations(employmentHistory, ({ one }) => ({
  employeeProfile: one(employeeProfiles, { fields: [employmentHistory.employeeProfileId], references: [employeeProfiles.id] }),
}));

export const kycDetailsRelations = relations(kycDetails, ({ one }) => ({
  employeeProfile: one(employeeProfiles, { fields: [kycDetails.employeeProfileId], references: [employeeProfiles.id] }),
}));

export const familyDetailsRelations = relations(familyDetails, ({ one }) => ({
  employeeProfile: one(employeeProfiles, { fields: [familyDetails.employeeProfileId], references: [employeeProfiles.id] }),
}));

export const userActivitiesRelations = relations(userActivities, ({ one }) => ({
  user: one(users, { fields: [userActivities.userId], references: [users.id] }),
  company: one(companies, { fields: [userActivities.companyId], references: [companies.id] }),
}));

// Monthly Payroll Tables
export const monthlyPayroll = pgTable("monthly_payroll", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  month: integer("month").notNull(), // 1-12
  year: integer("year").notNull(),
  status: text("status").notNull().default('draft'), // 'draft', 'finalized'
  generatedBy: integer("generated_by").references(() => users.id).notNull(),
  finalizedBy: integer("finalized_by").references(() => users.id),
  finalizedAt: timestamp("finalized_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const payrollRecords = pgTable("payroll_records", {
  id: serial("id").primaryKey(),
  monthlyPayrollId: integer("monthly_payroll_id").references(() => monthlyPayroll.id).notNull(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  
  // Attendance Data
  presentDays: integer("present_days").notNull().default(0),
  weeklyOffs: integer("weekly_offs").notNull().default(0),
  leaveDays: integer("leave_days").notNull().default(0),
  holidays: integer("holidays").notNull().default(0),
  payableDays: integer("payable_days").notNull().default(0),
  overtimeHours: decimal("overtime_hours").default('0'),
  
  // Salary Components
  basicSalary: decimal("basic_salary").notNull().default('0'),
  hra: decimal("hra").default('0'),
  conveyanceAllowance: decimal("conveyance_allowance").default('0'),
  otherAllowances: decimal("other_allowances").default('0'),
  grossSalary: decimal("gross_salary").notNull().default('0'),
  overtimeAmount: decimal("overtime_amount").default('0'),
  
  // Deductions
  epfEmployee: decimal("epf_employee").default('0'),
  esicEmployee: decimal("esic_employee").default('0'),
  lwfEmployee: decimal("lwf_employee").default('0'),
  vpfAmount: decimal("vpf_amount").default('0'),
  tdsAmount: decimal("tds_amount").default('0'),
  ptAmount: decimal("pt_amount").default('0'),
  totalDeductions: decimal("total_deductions").notNull().default('0'),
  
  // Employer Contributions
  epfEmployer: decimal("epf_employer").default('0'),
  epfAdmin: decimal("epf_admin").default('0'),
  esicEmployer: decimal("esic_employer").default('0'),
  lwfEmployer: decimal("lwf_employer").default('0'),
  bonus: decimal("bonus").default('0'),
  totalEmployerContributions: decimal("total_employer_contributions").default('0'),
  
  // Net Calculations
  netSalary: decimal("net_salary").notNull().default('0'),
  ctc: decimal("ctc").notNull().default('0'),
  
  // Payment Status
  paymentStatus: text("payment_status").notNull().default('unpaid'), // 'unpaid', 'paid', 'partially_paid'
  paidAmount: decimal("paid_amount").default('0'),
  paymentDate: timestamp("payment_date"),
  paymentMethod: text("payment_method"), // 'bank_transfer', 'cash', 'cheque'
  paymentReference: text("payment_reference"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Payroll Relations
export const monthlyPayrollRelations = relations(monthlyPayroll, ({ one, many }) => ({
  company: one(companies, { fields: [monthlyPayroll.companyId], references: [companies.id] }),
  generatedBy: one(users, { fields: [monthlyPayroll.generatedBy], references: [users.id], relationName: "payroll_generator" }),
  finalizedBy: one(users, { fields: [monthlyPayroll.finalizedBy], references: [users.id], relationName: "payroll_finalizer" }),
  records: many(payrollRecords),
}));

export const payrollRecordsRelations = relations(payrollRecords, ({ one }) => ({
  monthlyPayroll: one(monthlyPayroll, { fields: [payrollRecords.monthlyPayrollId], references: [monthlyPayroll.id] }),
  employee: one(employees, { fields: [payrollRecords.employeeId], references: [employees.id] }),
  company: one(companies, { fields: [payrollRecords.companyId], references: [companies.id] }),
}));

// Payroll Insert Schemas
export const insertMonthlyPayrollSchema = createInsertSchema(monthlyPayroll).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPayrollRecordSchema = createInsertSchema(payrollRecords).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Permission schemas
export const insertPermissionSchema = createInsertSchema(permissions).omit({
  id: true,
  createdAt: true,
});

export const insertUserPermissionSchema = createInsertSchema(userPermissions).omit({
  id: true,
  createdAt: true,
});

export const insertPermissionTemplateSchema = createInsertSchema(permissionTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPermissionRequestSchema = createInsertSchema(permissionRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  requestedBy: true,
  level1ReviewerId: true,
  level1ReviewedAt: true,
  level1Comments: true,
  level2ReviewerId: true,
  level2ReviewedAt: true,
  level2Comments: true,
  finalReviewerId: true,
  finalReviewedAt: true,
  finalComments: true,
  autoApproveAt: true,
});

// Permission-related Type Exports (moved to main types section to avoid duplicates)

// Types
export type MonthlyPayroll = typeof monthlyPayroll.$inferSelect;
export type InsertMonthlyPayroll = typeof insertMonthlyPayrollSchema._type;
export type PayrollRecord = typeof payrollRecords.$inferSelect;
export type InsertPayrollRecord = typeof insertPayrollRecordSchema._type;

// Client Compliances Types (definitions moved to end of file to avoid duplicates)

// Additional Company Settings Tables
export const designations = pgTable('designations', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  departmentId: integer('department_id').references(() => departments.id),
  companyId: integer('company_id').references(() => companies.id),
  level: text('level'), // Junior, Mid, Senior, Lead, Manager, Director
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const branches = pgTable('branches', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id),
  name: text('name').notNull(),
  address: text('address'),
  city: text('city'),
  state: text('state'),
  zipCode: text('zip_code'),
  phone: text('phone'),
  manager: text('manager'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const locations = pgTable('locations', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id),
  branchId: integer('branch_id').references(() => branches.id),
  name: text('name').notNull(),
  address: text('address'),
  capacity: integer('capacity'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const costCenters = pgTable('cost_centers', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id),
  code: text('code').notNull(),
  name: text('name').notNull(),
  description: text('description'),
  budget: text('budget'),
  manager: text('manager'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const biometricMachines = pgTable('biometric_machines', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id),
  serialNumber: text('serial_number').notNull(),
  ipAddress: text('ip_address').notNull(),
  port: integer('port').notNull(),
  location: text('location'),
  model: text('model'),
  status: text('status').default('active'), // active, inactive, maintenance
  lastSync: timestamp('last_sync').defaultNow(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const holidays = pgTable('holidays', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id),
  name: text('name').notNull(),
  date: date('date').notNull(),
  type: text('type').default('company'), // national, regional, company
  description: text('description'),
  mandatory: boolean('mandatory').default(true),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const leavePolicies = pgTable('leave_policies', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id),
  name: text('name').notNull(),
  type: text('type'), // annual, sick, maternity, paternity, personal, emergency
  allowedDays: integer('allowed_days').notNull(),
  carryForward: boolean('carry_forward').default(false),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Leave Requests table
export const leaveRequests = pgTable("leave_requests", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  leaveType: leaveTypeEnum("leave_type").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  totalDays: decimal("total_days", { precision: 5, scale: 1 }).notNull(),
  reason: text("reason").notNull(),
  status: leaveStatusEnum("status").default('pending').notNull(),
  appliedAt: timestamp("applied_at").defaultNow().notNull(),
  
  // Multi-level approval tracking
  level1ApproverId: integer("level_1_approver_id").references(() => users.id),
  level1ApprovedAt: timestamp("level_1_approved_at"),
  level1Comments: text("level_1_comments"),
  
  level2ApproverId: integer("level_2_approver_id").references(() => users.id),
  level2ApprovedAt: timestamp("level_2_approved_at"),
  level2Comments: text("level_2_comments"),
  
  finalApproverId: integer("final_approver_id").references(() => users.id),
  finalApprovedAt: timestamp("final_approved_at"),
  finalComments: text("final_comments"),
  
  rejectedById: integer("rejected_by_id").references(() => users.id),
  rejectedAt: timestamp("rejected_at"),
  rejectionReason: text("rejection_reason"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Advance Requests table
export const advanceRequests = pgTable("advance_requests", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  reason: text("reason").notNull(),
  repaymentPeriod: integer("repayment_period").notNull(), // months
  status: advanceStatusEnum("status").default('pending').notNull(),
  appliedAt: timestamp("applied_at").defaultNow().notNull(),
  
  // Multi-level approval tracking
  level1ApproverId: integer("level_1_approver_id").references(() => users.id),
  level1ApprovedAt: timestamp("level_1_approved_at"),
  level1Comments: text("level_1_comments"),
  
  level2ApproverId: integer("level_2_approver_id").references(() => users.id),
  level2ApprovedAt: timestamp("level_2_approved_at"),
  level2Comments: text("level_2_comments"),
  
  finalApproverId: integer("final_approver_id").references(() => users.id),
  finalApprovedAt: timestamp("final_approved_at"),
  finalComments: text("final_comments"),
  
  rejectedById: integer("rejected_by_id").references(() => users.id),
  rejectedAt: timestamp("rejected_at"),
  rejectionReason: text("rejection_reason"),
  
  // Payment tracking
  paidAmount: decimal("paid_amount", { precision: 10, scale: 2 }),
  paidAt: timestamp("paid_at"),
  paymentMethod: text("payment_method"),
  paymentReference: text("payment_reference"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Approval Workflow Configuration table
export const approvalWorkflows = pgTable("approval_workflows", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").references(() => companies.id).notNull(),
  requestType: text("request_type").notNull(), // 'leave', 'advance'
  level1ApproverRole: text("level_1_approver_role"), // 'manager', 'hr', 'admin'
  level2ApproverRole: text("level_2_approver_role"),
  finalApproverRole: text("final_approver_role"),
  amountThresholds: text("amount_thresholds"), // JSON string for advance amounts
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Client Compliances Tables
export const clients = pgTable('clients', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id).notNull(),
  projectName: text('project_name').notNull(),
  projectCost: text('project_cost').notNull(),
  startDate: date('start_date'),
  principalEmployer: text('principal_employer'),
  clientName: text('client_name'),
  natureAndLocationOfWork: text('nature_and_location_of_work'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const complianceSetups = pgTable('compliance_setups', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id).notNull(),
  employeeId: integer('employee_id').references(() => employees.id).notNull(),
  basicSalary: text('basic_salary').notNull(),
  grossSalary: text('gross_salary').notNull(),
  differenceAdjustment: boolean('difference_adjustment').default(false),
  pfType: text('pf_type').notNull(), // 'exempt', 'actual', 'ctc'
  esicType: text('esic_type').notNull(), // 'exempt', 'actual', 'ctc'
  bonusType: text('bonus_type').notNull(), // 'exempt', 'actual', 'ctc'
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Employee Assignments table
export const employeeAssignments = pgTable('employee_assignments', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id).notNull(),
  employeeId: integer('employee_id').references(() => employees.id).notNull(),
  designationId: integer('designation_id').references(() => designations.id).notNull(),
  assignDate: text('assign_date').notNull(),
  deassignDate: text('deassign_date'),
  address: text('address').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const compliancesData = pgTable('compliances_data', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id).notNull(),
  projectId: integer('project_id').references(() => clients.id).notNull(),
  employeeId: integer('employee_id').references(() => employees.id).notNull(),
  month: text('month').notNull(), // YYYY-MM format
  actualPayable: text('actual_payable'),
  compliancesGross: text('compliances_gross'),
  compliancesAttendance: integer('compliances_attendance'),
  compliancesOT: integer('compliances_ot'),
  compliancesGrossEarn: text('compliances_gross_earn'),
  pfDeduction: text('pf_deduction'),
  esicDeduction: text('esic_deduction'),
  netPayableAmount: text('net_payable_amount'),
  differenceAmount: text('difference_amount'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Additional relations
export const designationRelations = relations(designations, ({ one }) => ({
  department: one(departments, {
    fields: [designations.departmentId],
    references: [departments.id],
  }),
  company: one(companies, {
    fields: [designations.companyId],
    references: [companies.id],
  }),
}));

export const branchRelations = relations(branches, ({ one, many }) => ({
  company: one(companies, {
    fields: [branches.companyId],
    references: [companies.id],
  }),
  locations: many(locations),
}));

export const locationRelations = relations(locations, ({ one }) => ({
  company: one(companies, {
    fields: [locations.companyId],
    references: [companies.id],
  }),
  branch: one(branches, {
    fields: [locations.branchId],
    references: [branches.id],
  }),
}));

export const costCenterRelations = relations(costCenters, ({ one }) => ({
  company: one(companies, {
    fields: [costCenters.companyId],
    references: [companies.id],
  }),
}));

export const biometricMachineRelations = relations(biometricMachines, ({ one }) => ({
  company: one(companies, {
    fields: [biometricMachines.companyId],
    references: [companies.id],
  }),
}));

export const holidayRelations = relations(holidays, ({ one }) => ({
  company: one(companies, {
    fields: [holidays.companyId],
    references: [companies.id],
  }),
}));

export const leavePolicyRelations = relations(leavePolicies, ({ one }) => ({
  company: one(companies, {
    fields: [leavePolicies.companyId],
    references: [companies.id],
  }),
}));

// Insert schemas
export const insertCompanySchema = createInsertSchema(companies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDepartmentSchema = createInsertSchema(departments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmployeeSchema = createInsertSchema(employees).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmployeeProfileSchema = createInsertSchema(employeeProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertJobApplicationSchema = createInsertSchema(jobApplications).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMonthlyAttendanceSchema = createInsertSchema(monthlyAttendance).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFaceTemplateSchema = createInsertSchema(faceTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAttendanceLocationSchema = createInsertSchema(attendanceLocations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRolePermissionSchema = createInsertSchema(rolePermissions).omit({
  id: true,
  createdAt: true,
});

export const insertEmploymentHistorySchema = createInsertSchema(employmentHistory).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertKycDetailsSchema = createInsertSchema(kycDetails).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFamilyDetailsSchema = createInsertSchema(familyDetails).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserActivitySchema = createInsertSchema(userActivities).omit({
  id: true,
  createdAt: true,
});

export const insertInterviewSchema = createInsertSchema(interviews).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertJobOfferSchema = createInsertSchema(jobOffers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmployeePayrollSchema = createInsertSchema(employeePayroll).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmployeeSalaryStructureSchema = createInsertSchema(employeeSalaryStructures).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).transform((data) => {
  // Transform empty strings to null for decimal fields to prevent database errors
  return {
    ...data,
    vpfAmount: data.vpfAmount === '' || data.vpfAmount === undefined ? null : data.vpfAmount,
    tdsAmount: data.tdsAmount === '' || data.tdsAmount === undefined ? null : data.tdsAmount,
    ptAmount: data.ptAmount === '' || data.ptAmount === undefined ? null : data.ptAmount,
    ctcValue: data.ctcValue === '' || data.ctcValue === undefined ? null : data.ctcValue,
    grossValue: data.grossValue === '' || data.grossValue === undefined ? null : data.grossValue,
    earningHead1: data.earningHead1 === '' || data.earningHead1 === undefined ? null : data.earningHead1,
    earningHead2: data.earningHead2 === '' || data.earningHead2 === undefined ? null : data.earningHead2,
    earningHead3: data.earningHead3 === '' || data.earningHead3 === undefined ? null : data.earningHead3,
    earningHead4: data.earningHead4 === '' || data.earningHead4 === undefined ? null : data.earningHead4,
    epfEmployeeAmount: data.epfEmployeeAmount === '' || data.epfEmployeeAmount === undefined ? null : data.epfEmployeeAmount,
    esicEmployeeAmount: data.esicEmployeeAmount === '' || data.esicEmployeeAmount === undefined ? null : data.esicEmployeeAmount,
    lwfEmployeeAmount: data.lwfEmployeeAmount === '' || data.lwfEmployeeAmount === undefined ? null : data.lwfEmployeeAmount,
  };
});

// Types for employeeSalaryStructures
export type InsertEmployeeSalaryStructure = z.infer<typeof insertEmployeeSalaryStructureSchema>;
export type SelectEmployeeSalaryStructure = typeof employeeSalaryStructures.$inferSelect;

export const insertLeaveRequestSchema = createInsertSchema(leaveRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  appliedAt: true,
});

export const insertAdvanceRequestSchema = createInsertSchema(advanceRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  appliedAt: true,
});

export const insertApprovalWorkflowSchema = createInsertSchema(approvalWorkflows).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertComplianceSetupSchema = createInsertSchema(complianceSetups).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCompliancesDataSchema = createInsertSchema(compliancesData).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmployeeAssignmentSchema = createInsertSchema(employeeAssignments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Salary component schemas
export const insertSalaryComponentSchema = createInsertSchema(salaryComponents).omit({
  id: true,
  createdAt: true,
});

export const insertCompanySalaryComponentConfigSchema = createInsertSchema(companySalaryComponentConfig).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmployeeSalaryComponentValuesSchema = createInsertSchema(employeeSalaryComponentValues).omit({
  id: true,
  createdAt: true,
});

// Employee Assignment Relations
export const employeeAssignmentRelations = relations(employeeAssignments, ({ one }) => ({
  company: one(companies, {
    fields: [employeeAssignments.companyId],
    references: [companies.id],
  }),
  employee: one(employees, {
    fields: [employeeAssignments.employeeId],
    references: [employees.id],
  }),
  designation: one(designations, {
    fields: [employeeAssignments.designationId],
    references: [designations.id],
  }),
}));

// Types
export type Company = typeof companies.$inferSelect;
export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Department = typeof departments.$inferSelect;
export type InsertDepartment = z.infer<typeof insertDepartmentSchema>;
export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type EmployeeProfile = typeof employeeProfiles.$inferSelect;
export type InsertEmployeeProfile = z.infer<typeof insertEmployeeProfileSchema>;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;
export type JobApplication = typeof jobApplications.$inferSelect;
export type InsertJobApplication = z.infer<typeof insertJobApplicationSchema>;
export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type MonthlyAttendance = typeof monthlyAttendance.$inferSelect;
export type InsertMonthlyAttendance = z.infer<typeof insertMonthlyAttendanceSchema>;
export type FaceTemplate = typeof faceTemplates.$inferSelect;
export type InsertFaceTemplate = z.infer<typeof insertFaceTemplateSchema>;
export type AttendanceLocation = typeof attendanceLocations.$inferSelect;
export type InsertAttendanceLocation = z.infer<typeof insertAttendanceLocationSchema>;
export type Permission = typeof permissions.$inferSelect;
export type InsertPermission = z.infer<typeof insertPermissionSchema>;
export type UserPermission = typeof userPermissions.$inferSelect;
export type InsertUserPermission = z.infer<typeof insertUserPermissionSchema>;
export type PermissionTemplate = typeof permissionTemplates.$inferSelect;
export type InsertPermissionTemplate = z.infer<typeof insertPermissionTemplateSchema>;
export type RolePermission = typeof rolePermissions.$inferSelect;
export type InsertRolePermission = z.infer<typeof insertRolePermissionSchema>;
export type PermissionRequest = typeof permissionRequests.$inferSelect;
export type InsertPermissionRequest = z.infer<typeof insertPermissionRequestSchema>;
export type EmploymentHistory = typeof employmentHistory.$inferSelect;
export type InsertEmploymentHistory = z.infer<typeof insertEmploymentHistorySchema>;
export type KycDetails = typeof kycDetails.$inferSelect;
export type InsertKycDetails = z.infer<typeof insertKycDetailsSchema>;
export type FamilyDetails = typeof familyDetails.$inferSelect;
export type InsertFamilyDetails = z.infer<typeof insertFamilyDetailsSchema>;
export type UserActivity = typeof userActivities.$inferSelect;
export type InsertUserActivity = z.infer<typeof insertUserActivitySchema>;
export type Interview = typeof interviews.$inferSelect;
export type InsertInterview = z.infer<typeof insertInterviewSchema>;
export type JobOffer = typeof jobOffers.$inferSelect;
export type InsertJobOffer = z.infer<typeof insertJobOfferSchema>;
export type EmployeePayroll = typeof employeePayroll.$inferSelect;
export type InsertEmployeePayroll = z.infer<typeof insertEmployeePayrollSchema>;
export type LeaveRequest = typeof leaveRequests.$inferSelect;
export type InsertLeaveRequest = z.infer<typeof insertLeaveRequestSchema>;
export type AdvanceRequest = typeof advanceRequests.$inferSelect;
export type InsertAdvanceRequest = z.infer<typeof insertAdvanceRequestSchema>;
export type ApprovalWorkflow = typeof approvalWorkflows.$inferSelect;
export type InsertApprovalWorkflow = z.infer<typeof insertApprovalWorkflowSchema>;
export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;
export type ComplianceSetup = typeof complianceSetups.$inferSelect;
export type InsertComplianceSetup = z.infer<typeof insertComplianceSetupSchema>;
export type CompliancesData = typeof compliancesData.$inferSelect;
export type InsertCompliancesData = z.infer<typeof insertCompliancesDataSchema>;
export type EmployeeAssignment = typeof employeeAssignments.$inferSelect;
export type InsertEmployeeAssignment = z.infer<typeof insertEmployeeAssignmentSchema>;

// Salary component types
export type SalaryComponent = typeof salaryComponents.$inferSelect;
export type InsertSalaryComponent = z.infer<typeof insertSalaryComponentSchema>;
export type CompanySalaryComponentConfig = typeof companySalaryComponentConfig.$inferSelect;
export type InsertCompanySalaryComponentConfig = z.infer<typeof insertCompanySalaryComponentConfigSchema>;
export type EmployeeSalaryComponentValues = typeof employeeSalaryComponentValues.$inferSelect;
export type InsertEmployeeSalaryComponentValues = z.infer<typeof insertEmployeeSalaryComponentValuesSchema>;

// Login schema
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export type LoginData = z.infer<typeof loginSchema>;
