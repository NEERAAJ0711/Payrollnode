import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building2, Search, FileText, AlertCircle, Calendar, Clock, DollarSign } from "lucide-react";
import { Link } from "wouter";

interface CompanyRequiredRouteProps {
  children: React.ReactNode;
}

export default function CompanyRequiredRoute({ children }: CompanyRequiredRouteProps) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: employee } = useQuery({
    queryKey: ['/api/employee/profile'],
    enabled: !!user?.id && user?.role === 'employee',
  });

  const { data: publicJobs = [] } = useQuery({
    queryKey: ['/api/jobs/public'],
    enabled: !!user?.id && user?.role === 'employee',
  });

  // Check employee status by Aadhaar verification
  const { data: employeeStatus, isLoading: statusLoading, error: statusError } = useQuery({
    queryKey: ['/api/employee/aadhaar-status'],
    enabled: !!user?.id && user?.role === 'employee',
    staleTime: 0, // Always refetch to get latest status
    refetchOnMount: true,
  });

  // Show loading while checking status
  if (statusLoading || !employeeStatus) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p>Checking employee status...</p>
      </div>
    </div>;
  }

  // Debug logging
  console.log('CompanyRequiredRoute - employeeStatus:', employeeStatus);
  console.log('CompanyRequiredRoute - aadhaarVerified:', employeeStatus?.aadhaarVerified);
  console.log('CompanyRequiredRoute - isEmployeeInCompany:', employeeStatus?.isEmployeeInCompany);

  // If employee is found in company database, allow access
  if (employeeStatus?.aadhaarVerified === true && employeeStatus?.isEmployeeInCompany === true) {
    console.log('CompanyRequiredRoute - Allowing access to HR features');
    return <>{children}</>;
  }

  // If no company, show job search interface
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="relative">
              <Search className="h-16 w-16 text-blue-600" />
            </div>
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Job Seeker Portal</h1>
            <p className="text-lg text-gray-600 mt-2">
              Search and apply for jobs with companies
            </p>
          </div>
        </div>

        {/* Available Actions */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Job Search */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5 text-blue-600" />
                Available Jobs
              </CardTitle>
              <CardDescription>
                Search and apply for available positions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {publicJobs.length > 0 ? (
                  <div className="space-y-2">
                    {publicJobs.slice(0, 3).map((job: any) => (
                      <div key={job.id} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">{job.title}</h4>
                            <p className="text-sm text-gray-600">{job.department}</p>
                          </div>
                          <Badge variant={job.status === 'active' ? 'default' : 'secondary'}>
                            {job.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {publicJobs.length > 3 && (
                      <p className="text-sm text-gray-500">
                        +{publicJobs.length - 3} more jobs available
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-8">
                    No jobs available at the moment
                  </p>
                )}
                <Link href="/jobs">
                  <Button className="w-full">
                    <Search className="mr-2 h-4 w-4" />
                    Browse All Jobs
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Profile Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-green-600" />
                Profile Management
              </CardTitle>
              <CardDescription>
                Complete your profile while waiting for company assignment
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">Personal Information</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">Contact Details</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">Professional Details</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                </div>
                <Link href="/profile">
                  <Button variant="outline" className="w-full">
                    <FileText className="mr-2 h-4 w-4" />
                    Update Profile
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contact Admin */}
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <h3 className="text-lg font-medium text-blue-900">Need Company Assignment?</h3>
              <p className="text-blue-700">
                Contact your administrator or HR department to be assigned to a company and gain access to all HR features.
              </p>
              <div className="flex justify-center gap-4">
                <Button variant="outline" onClick={() => setLocation('/jobs')}>
                  Browse Jobs
                </Button>
                <Button variant="outline" onClick={() => setLocation('/profile')}>
                  Complete Profile
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}