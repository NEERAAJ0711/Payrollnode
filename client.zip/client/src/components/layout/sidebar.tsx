import { authService } from "@/lib/auth";
import { useLocation } from "wouter";
import { Users, Briefcase, BarChart3, Clock, DollarSign, Building2, Settings, LogOut, Home, Calendar, CreditCard, Shield, FileText, CheckSquare, Database, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";

interface SidebarProps {
  companyName?: string;
}

export default function Sidebar({ companyName = "HR System" }: SidebarProps) {
  const [location, setLocation] = useLocation();
  const user = authService.getUser();

  // Get employee profile to check company assignment
  const { data: employee } = useQuery({
    queryKey: ['/api/employee/profile'],
    enabled: !!user?.id && user?.role === 'employee',
  });

  // Check employee status by Aadhaar verification
  const { data: employeeStatus } = useQuery({
    queryKey: ['/api/employee/aadhaar-status'],
    enabled: !!user?.id && user?.role === 'employee',
    staleTime: 0, // Always refetch to get latest status
    refetchOnMount: true,
  });

  const hasCompany = employeeStatus?.isEmployeeInCompany;

  const handleLogout = async () => {
    await authService.logout();
    setLocation('/login');
  };

  const navigationItems = user?.role === 'employee' 
    ? [
        { path: "/", icon: Home, label: "Dashboard", active: location === "/" },
        { path: "/employee/profile", icon: Users, label: "My Profile", active: location === "/employee/profile" },
        ...(hasCompany ? [
          { path: "/employee/attendance", icon: Clock, label: "Attendance", active: location === "/employee/attendance" },
          { path: "/employee/permissions", icon: Shield, label: "Permission Requests", active: location === "/employee/permissions" },
          { path: "/employee/leave-application", icon: Calendar, label: "Leave Application", active: location === "/employee/leave-application" },
          { path: "/employee/advance-request", icon: CreditCard, label: "Advance Request", active: location === "/employee/advance-request" },
        ] : []),
        { path: "/jobs", icon: Briefcase, label: "Available Jobs", active: location === "/jobs" },
      ]
    : [
        { path: "/", icon: Home, label: "Dashboard", active: location === "/" },
        { path: "/employees", icon: Users, label: "Employees", active: location === "/employees" },
        { path: "/admin/attendance", icon: Clock, label: "Attendance", active: location === "/admin/attendance" },
        { path: "/admin/leave-management", icon: Calendar, label: "Leave Management", active: location === "/admin/leave-management" },
        { path: "/admin/advance-management", icon: CreditCard, label: "Advance Requests", active: location === "/admin/advance-management" },
        { path: "/payroll", icon: DollarSign, label: "Payroll", active: location === "/payroll" },
        { path: "/recruitment", icon: BarChart3, label: "Recruitment", active: location === "/recruitment" },
      ];

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="w-72 bg-white border-r border-gray-200 flex flex-col h-screen">
      {/* Logo and Company Info */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-hr-primary rounded-lg flex items-center justify-center">
            <Building2 className="text-white text-lg" size={20} />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-hr-text-primary">{companyName}</h1>
            <p className="text-sm text-hr-neutral capitalize">{user?.role?.replace('_', ' ')}</p>
          </div>
        </div>
      </div>



      {/* Navigation Menu */}
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {navigationItems.map((item) => (
            <Button
              key={item.path}
              variant={item.active ? "default" : "ghost"}
              className={`w-full justify-start space-x-3 ${
                item.active 
                  ? "bg-hr-primary text-white hover:bg-hr-primary/90" 
                  : "text-hr-neutral hover:text-hr-text-primary hover:bg-gray-50"
              }`}
              onClick={() => setLocation(item.path)}
            >
              <item.icon size={18} />
              <span>{item.label}</span>
            </Button>
          ))}

          {/* Role-based sections */}
          {user?.role === 'system_admin' && (
            <div className="mt-6">
              <h3 className="text-xs uppercase text-hr-neutral font-semibold mb-2 px-3">
                System Admin
              </h3>
              <Button
                variant="ghost"
                className={`w-full justify-start space-x-3 ${
                  location === "/admin/companies" 
                    ? "bg-hr-primary text-white hover:bg-hr-primary/90" 
                    : "text-hr-neutral hover:text-hr-text-primary hover:bg-gray-50"
                }`}
                onClick={() => setLocation("/admin/companies")}
              >
                <Building2 size={18} />
                <span>Company Management</span>
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start space-x-3 ${
                  location === "/admin/users" 
                    ? "bg-hr-primary text-white hover:bg-hr-primary/90" 
                    : "text-hr-neutral hover:text-hr-text-primary hover:bg-gray-50"
                }`}
                onClick={() => setLocation("/admin/users")}
              >
                <Users size={18} />
                <span>User Management</span>
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start space-x-3 ${
                  location === "/admin/permissions" 
                    ? "bg-hr-primary text-white hover:bg-hr-primary/90" 
                    : "text-hr-neutral hover:text-hr-text-primary hover:bg-gray-50"
                }`}
                onClick={() => setLocation("/admin/permissions")}
              >
                <Settings size={18} />
                <span>Permission Management</span>
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start space-x-3 ${
                  location === "/admin/company-settings" 
                    ? "bg-hr-primary text-white hover:bg-hr-primary/90" 
                    : "text-hr-neutral hover:text-hr-text-primary hover:bg-gray-50"
                }`}
                onClick={() => setLocation("/admin/company-settings")}
              >
                <Building2 size={18} />
                <span>Company Settings</span>
              </Button>
            </div>
          )}

          {user?.role === 'admin' && (
            <>
              <div className="mt-6">
                <h3 className="text-xs uppercase text-hr-neutral font-semibold mb-2 px-3">
                  Client Compliances
                </h3>
                <Button
                  variant="ghost"
                  className={`w-full justify-start space-x-3 ${
                    location.startsWith("/client-compliances") 
                      ? "bg-hr-primary text-white hover:bg-hr-primary/90" 
                      : "text-hr-neutral hover:text-hr-text-primary hover:bg-gray-50"
                  }`}
                  onClick={() => setLocation("/client-compliances")}
                >
                  <FileText size={18} />
                  <span>Client Compliances</span>
                </Button>
              </div>
              <div className="mt-6">
                <h3 className="text-xs uppercase text-hr-neutral font-semibold mb-2 px-3">
                  Administration
                </h3>
              <Button
                variant="ghost"
                className={`w-full justify-start space-x-3 ${
                  location === "/admin/users" 
                    ? "bg-hr-primary text-white hover:bg-hr-primary/90" 
                    : "text-hr-neutral hover:text-hr-text-primary hover:bg-gray-50"
                }`}
                onClick={() => setLocation("/admin/users")}
              >
                <Users size={18} />
                <span>User Management</span>
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start space-x-3 ${
                  location === "/admin/permissions" 
                    ? "bg-hr-primary text-white hover:bg-hr-primary/90" 
                    : "text-hr-neutral hover:text-hr-text-primary hover:bg-gray-50"
                }`}
                onClick={() => setLocation("/admin/permissions")}
              >
                <Settings size={18} />
                <span>Permission Management</span>
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start space-x-3 ${
                  location === "/admin/company-settings" 
                    ? "bg-hr-primary text-white hover:bg-hr-primary/90" 
                    : "text-hr-neutral hover:text-hr-text-primary hover:bg-gray-50"
                }`}
                onClick={() => setLocation("/admin/company-settings")}
              >
                <Building2 size={18} />
                <span>Company Settings</span>
              </Button>

              </div>
            </>
          )}
        </div>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar className="w-8 h-8">
              <AvatarFallback className="bg-hr-primary text-white text-sm">
                {user ? getInitials(user.username) : 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-hr-text-primary truncate">
                {user?.username}
              </p>
              <p className="text-xs text-hr-neutral truncate">
                {user?.email}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-hr-neutral hover:text-hr-accent"
            onClick={handleLogout}
          >
            <LogOut size={16} />
          </Button>
        </div>
      </div>
    </div>
  );
}
