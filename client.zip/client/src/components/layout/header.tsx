import { Search, Bell, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  title: string;
  subtitle?: string;
  onSearch?: (query: string) => void;
  onAddNew?: () => void;
  showAddButton?: boolean;
}

export default function Header({ 
  title, 
  subtitle, 
  onSearch, 
  onAddNew, 
  showAddButton = true 
}: HeaderProps) {
  return (
    <header className="bg-white border-b border-gray-200 p-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-hr-text-primary">{title}</h1>
          {subtitle && <p className="text-hr-neutral">{subtitle}</p>}
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Search */}
          {onSearch && (
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-hr-neutral" />
              <Input
                placeholder="Search..."
                className="pl-10 w-64 focus:ring-hr-primary focus:border-hr-primary"
                onChange={(e) => onSearch(e.target.value)}
              />
            </div>
          )}
          
          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-4 w-4 text-hr-neutral" />
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs"
                >
                  3
                </Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <div className="p-4 border-b">
                <h3 className="font-semibold text-hr-text-primary">Notifications</h3>
              </div>
              <div className="max-h-96 overflow-y-auto">
                <DropdownMenuItem className="p-4 border-b border-gray-100">
                  <div>
                    <p className="text-sm font-medium text-hr-text-primary">
                      New job application received
                    </p>
                    <p className="text-xs text-hr-neutral mt-1">
                      For Senior Developer position - 5 min ago
                    </p>
                  </div>
                </DropdownMenuItem>
                <DropdownMenuItem className="p-4 border-b border-gray-100">
                  <div>
                    <p className="text-sm font-medium text-hr-text-primary">
                      Payroll reminder
                    </p>
                    <p className="text-xs text-hr-neutral mt-1">
                      Monthly payroll due in 3 days - 1 hour ago
                    </p>
                  </div>
                </DropdownMenuItem>
                <DropdownMenuItem className="p-4">
                  <div>
                    <p className="text-sm font-medium text-hr-text-primary">
                      System maintenance scheduled
                    </p>
                    <p className="text-xs text-hr-neutral mt-1">
                      Biometric system update - 2 hours ago
                    </p>
                  </div>
                </DropdownMenuItem>
              </div>
              <DropdownMenuSeparator />
              <div className="p-2">
                <Button variant="ghost" className="w-full">
                  View all notifications
                </Button>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Add New Button */}
          {showAddButton && onAddNew && (
            <Button 
              onClick={onAddNew}
              className="bg-hr-primary text-white hover:bg-hr-primary/90"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add New
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
