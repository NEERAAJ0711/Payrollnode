import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { authService } from "@/lib/auth";
import Sidebar from "./sidebar";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [location] = useLocation();
  const user = authService.getUser();

  // Get company data for sidebar
  const { data: company } = useQuery({
    queryKey: ['/api/companies', user?.companyId],
    enabled: !!user?.companyId && user?.role !== 'system_admin',
  });

  // Don't show sidebar for login/signup pages
  if (location === '/login' || location === '/signup') {
    return <>{children}</>;
  }

  // Don't show sidebar for company setup pages
  if (location === '/company-profile-setup' || location === '/company-approval-pending') {
    return <>{children}</>;
  }



  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar companyName={company?.name || "HR System"} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          <div className="p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}