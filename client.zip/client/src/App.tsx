import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import LoginPage from "@/pages/login";
import DashboardPage from "@/pages/dashboard";
import EmployeesPage from "@/pages/employees";
import JobsPage from "@/pages/jobs";
import EmployeeProfile from "@/pages/employee-profile";
import RecruitmentDashboard from "@/pages/recruitment-dashboard";
import UserManagement from "@/pages/user-management";
import CompanyManagement from "@/pages/company-management";
import PermissionManagement from "@/pages/permission-management";
import PermissionRequestSimple from "@/pages/permission-request-simple";
import CompanyProfileSetup from "./pages/company-profile-setup";
import CompanyApprovalPending from "./pages/company-approval-pending";
import CompanySettings from "./pages/company-settings";
import ManageEmployee from "./pages/manage-employee";
import AddEmployee from "./pages/add-employee";
import ViewEmployee from "./pages/view-employee";
import EditEmployee from "./pages/edit-employee";
import AttendancePage from "./pages/attendance";
import DailyLogPage from "./pages/daily-log";
import PayrollPage from "./pages/payroll";
import LeaveApplicationPage from "./pages/leave-application";
import AdvanceRequestPage from "./pages/advance-request";
import AdminLeaveManagement from "./pages/admin-leave-management";
import AdminAdvanceManagement from "./pages/admin-advance-management";
import SignupPage from "@/pages/signup";
import ClientCompliances from "./pages/client-compliances";

import ProtectedRoute from "@/components/layout/protected-route";
import CompanyRequiredRoute from "@/components/layout/company-required-route";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      <Route path="/signup" component={SignupPage} />
      <Route path="/">
        <ProtectedRoute>
          <DashboardPage />
        </ProtectedRoute>
      </Route>
      <Route path="/admin-dashboard">
        <ProtectedRoute>
          <DashboardPage />
        </ProtectedRoute>
      </Route>
      <Route path="/employee-dashboard">
        <ProtectedRoute>
          <DashboardPage />
        </ProtectedRoute>
      </Route>
      <Route path="/employees">
        <ProtectedRoute>
          <EmployeesPage />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/employees">
        <ProtectedRoute>
          <EmployeesPage />
        </ProtectedRoute>
      </Route>
      <Route path="/jobs">
        <ProtectedRoute>
          <JobsPage />
        </ProtectedRoute>
      </Route>
      <Route path="/profile">
        <ProtectedRoute>
          <EmployeeProfile />
        </ProtectedRoute>
      </Route>
      <Route path="/employee/profile">
        <ProtectedRoute>
          <EmployeeProfile />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/users">
        <ProtectedRoute>
          <UserManagement />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/companies">
        <ProtectedRoute>
          <CompanyManagement />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/permissions">
        <ProtectedRoute>
          <PermissionManagement />
        </ProtectedRoute>
      </Route>
      <Route path="/employee/permissions">
        <ProtectedRoute>
          <CompanyRequiredRoute>
            <PermissionRequestSimple />
          </CompanyRequiredRoute>
        </ProtectedRoute>
      </Route>
      <Route path="/recruitment">
        <ProtectedRoute>
          <RecruitmentDashboard />
        </ProtectedRoute>
      </Route>
      <Route path="/company-profile-setup">
        <ProtectedRoute>
          <CompanyProfileSetup />
        </ProtectedRoute>
      </Route>
      <Route path="/company-approval-pending">
        <ProtectedRoute>
          <CompanyApprovalPending />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/company-settings">
        <ProtectedRoute>
          <CompanySettings />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/manage-employee">
        <ProtectedRoute>
          <ManageEmployee />
        </ProtectedRoute>
      </Route>
      <Route path="/attendance">
        <ProtectedRoute>
          <CompanyRequiredRoute>
            <AttendancePage />
          </CompanyRequiredRoute>
        </ProtectedRoute>
      </Route>
      <Route path="/admin/attendance">
        <ProtectedRoute>
          <AttendancePage />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/attendance/daily-log/:employeeId/:year/:month">
        {(params) => (
          <ProtectedRoute>
            <DailyLogPage />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/employee/attendance">
        <ProtectedRoute>
          <CompanyRequiredRoute>
            <AttendancePage />
          </CompanyRequiredRoute>
        </ProtectedRoute>
      </Route>
      <Route path="/admin/add-employee">
        <ProtectedRoute>
          <AddEmployee />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/employees/:id/view">
        {(params) => (
          <ProtectedRoute>
            <ViewEmployee params={params} />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/employees/:id/edit">
        {(params) => (
          <ProtectedRoute>
            <EditEmployee params={params} />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/payroll">
        <ProtectedRoute>
          <PayrollPage />
        </ProtectedRoute>
      </Route>
      <Route path="/leave-application">
        <ProtectedRoute>
          <CompanyRequiredRoute>
            <LeaveApplicationPage />
          </CompanyRequiredRoute>
        </ProtectedRoute>
      </Route>
      <Route path="/employee/leave-application">
        <ProtectedRoute>
          <CompanyRequiredRoute>
            <LeaveApplicationPage />
          </CompanyRequiredRoute>
        </ProtectedRoute>
      </Route>
      <Route path="/advance-request">
        <ProtectedRoute>
          <CompanyRequiredRoute>
            <AdvanceRequestPage />
          </CompanyRequiredRoute>
        </ProtectedRoute>
      </Route>
      <Route path="/employee/advance-request">
        <ProtectedRoute>
          <CompanyRequiredRoute>
            <AdvanceRequestPage />
          </CompanyRequiredRoute>
        </ProtectedRoute>
      </Route>
      <Route path="/admin/leave-management">
        <ProtectedRoute>
          <AdminLeaveManagement />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/advance-management">
        <ProtectedRoute>
          <AdminAdvanceManagement />
        </ProtectedRoute>
      </Route>
      <Route path="/client-compliances">
        <ProtectedRoute>
          <ClientCompliances />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/client-compliances">
        <ProtectedRoute>
          <ClientCompliances />
        </ProtectedRoute>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
