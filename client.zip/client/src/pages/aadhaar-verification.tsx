import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertTriangle, Shield, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequestWithAuth } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";

export default function AadhaarVerification() {
  const [aadhaarNumber, setAadhaarNumber] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const { toast } = useToast();

  // Format Aadhaar number with spaces
  const formatAadhaar = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    const formatted = cleaned.replace(/(\d{4})(\d{4})(\d{4})/, '$1 $2 $3');
    return formatted.slice(0, 14); // Limit to 12 digits + 2 spaces
  };

  const handleAadhaarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatAadhaar(e.target.value);
    setAadhaarNumber(formatted);
  };

  const verifyAadhaarMutation = useMutation({
    mutationFn: async (aadhaar: string) => {
      // Simulate UIDAI API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock verification - in real implementation, call UIDAI API
      const cleanAadhaar = aadhaar.replace(/\s/g, '');
      if (cleanAadhaar.length !== 12) {
        throw new Error("Invalid Aadhaar number");
      }
      
      // Update KYC details with verified Aadhaar
      const response = await apiRequestWithAuth('PUT', '/api/employee/kyc', {
        aadharNo: cleanAadhaar,
        isAadhaarVerified: true
      });
      
      return await response.json();
    },
    onSuccess: () => {
      setIsVerified(true);
      toast({
        title: "Aadhaar Verified Successfully!",
        description: "Profile information has been loaded. You can now access all application features.",
      });
      // Invalidate all related queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/employee/profile'] });
      queryClient.invalidateQueries({ queryKey: ['/api/employee/kyc'] });
      queryClient.invalidateQueries({ queryKey: ['/api/employee/aadhaar-status'] });
      
      // Redirect to profile to see loaded information
      setTimeout(() => {
        window.location.href = '/profile';
      }, 2000);
    },
    onError: (error: any) => {
      toast({
        title: "Verification Failed",
        description: error.message || "Please check your Aadhaar number and try again.",
        variant: "destructive"
      });
    }
  });

  const handleVerify = () => {
    const cleanAadhaar = aadhaarNumber.replace(/\s/g, '');
    if (cleanAadhaar.length !== 12) {
      toast({
        title: "Invalid Aadhaar Number",
        description: "Please enter a valid 12-digit Aadhaar number.",
        variant: "destructive"
      });
      return;
    }
    verifyAadhaarMutation.mutate(aadhaarNumber);
  };

  if (isVerified) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <CardTitle className="text-green-700">Verification Complete!</CardTitle>
            <CardDescription>
              Your Aadhaar has been successfully verified. Redirecting to dashboard...
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
            <Shield className="w-6 h-6 text-orange-600" />
          </div>
          <CardTitle className="text-orange-700">Aadhaar Verification Required</CardTitle>
          <CardDescription>
            You must verify your Aadhaar number to access the application
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex items-start">
              <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 mr-3 flex-shrink-0" />
              <div className="text-sm text-orange-800">
                <p className="font-medium mb-1">Mandatory Verification</p>
                <p>As per company policy, all employees must verify their Aadhaar number before accessing any application features.</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="aadhaar">Aadhaar Number</Label>
            <Input
              id="aadhaar"
              type="text"
              placeholder="1234 5678 9012"
              value={aadhaarNumber}
              onChange={handleAadhaarChange}
              maxLength={14}
              className="text-center text-lg tracking-wider"
            />
            <p className="text-xs text-gray-500 text-center">
              Enter your 12-digit Aadhaar number
            </p>
          </div>

          <Button 
            onClick={handleVerify}
            disabled={verifyAadhaarMutation.isPending || aadhaarNumber.replace(/\s/g, '').length !== 12}
            className="w-full"
          >
            {verifyAadhaarMutation.isPending ? "Verifying..." : "Verify Aadhaar"}
          </Button>

          <div className="text-xs text-gray-500 text-center space-y-1">
            <p>🔒 Your Aadhaar data is secure and encrypted</p>
            <p>This verification is done through official UIDAI services</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}