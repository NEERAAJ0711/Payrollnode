import { useAuth } from "@/lib/auth";
import SystemAdminDashboard from "./system-admin-dashboard";
import AdminDashboard from "./admin-dashboard";  
import EmployeeDashboard from "./employee-dashboard";

export default function Dashboard() {
  const { user } = useAuth();

  if (!user) {
    return <div>Loading...</div>;
  }

  // Route to the appropriate dashboard based on user role
  switch (user.role) {
    case 'system_admin':
      return <SystemAdminDashboard />;
    case 'admin':
      return <AdminDashboard />;
    case 'employee':
      return <EmployeeDashboard />;
    default:
      return (
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Unknown user role: {user.role}</p>
        </div>
      );
  }
}