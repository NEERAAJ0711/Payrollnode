import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { authService, apiRequestWithAuth, usePermission } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, User, Home, FileText, Clock, DollarSign, Users, Building2, CreditCard, Shield, Calendar, CheckCircle, XCircle, IdCard } from "lucide-react";

interface EmployeeFormData {
  // Basic Information
  employeeName: string;
  fatherName: string;
  isHusbandName: boolean;
  dateOfBirth: string;
  dateOfJoin: string;
  gender: string;
  
  // Work Information
  departmentId: string;
  designation: string;
  branchId: string;
  costCenterId: string;
  locationId: string;
  
  // Address Information
  presentAddress: string;
  permanentAddress: string;
  
  // Identity Documents
  aadharNo: string;
  panNo: string;
  
  // Banking Information
  bankAccountNo: string;
  ifscCode: string;
  
  // Compliance Information
  uanNo: string;
  esicNo: string;
  
  // Payroll Information
  payCode: string;
  payrollSetting: string;
  
  // Time Office Policy Information
  dutyStartTime: string;
  dutyEndTime: string;
  permissibleLateArrival: string;
  permissibleEarlyDeparture: string;
  firstWeeklyOffDay: string;
  secondWeeklyOffDay: string;
  overtimeApplicable: boolean;
  presentMarkingDuration: string;
  
  // Family Details
  familyDetails: string;
}

function AddEmployeeContent() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("personal");
  const user = authService.getUser();
  const companyId = user?.companyId;

  const [formData, setFormData] = useState<EmployeeFormData>({
    employeeName: '',
    fatherName: '',
    isHusbandName: false,
    dateOfBirth: '',
    dateOfJoin: '',
    gender: '',
    departmentId: '',
    designation: '',
    branchId: '',
    costCenterId: '',
    locationId: '',
    presentAddress: '',
    permanentAddress: '',
    aadharNo: '',
    panNo: '',
    bankAccountNo: '',
    ifscCode: '',
    uanNo: '',
    esicNo: '',
    payCode: '',
    payrollSetting: '',
    dutyStartTime: '',
    dutyEndTime: '',
    permissibleLateArrival: '',
    permissibleEarlyDeparture: '',
    firstWeeklyOffDay: '',
    secondWeeklyOffDay: '',
    overtimeApplicable: false,
    presentMarkingDuration: '',
    familyDetails: ''
  });

  const [isLookingUp, setIsLookingUp] = useState(false);
  const [lookupMessage, setLookupMessage] = useState('');
  const [showAadhaarPopup, setShowAadhaarPopup] = useState(false);
  const [aadhaarData, setAadhaarData] = useState<any>(null);

  // Aadhaar lookup mutation
  const aadhaarLookupMutation = useMutation({
    mutationFn: async (aadhaarNo: string) => {
      console.log('🔍 Starting Aadhaar lookup for:', aadhaarNo);
      try {
        const response = await apiRequestWithAuth('POST', '/api/admin/lookup-employee-by-aadhaar', {
          aadhaarNo: aadhaarNo
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error('❌ API Error:', response.status, errorText);
          throw new Error(`API Error: ${response.status} - ${errorText}`);
        }
        
        const data = await response.json();
        console.log('✅ Lookup response:', data);
        return data;
      } catch (error) {
        console.error('❌ Lookup failed:', error);
        throw error;
      }
    },
    onSuccess: (data) => {
      if (data.found) {
        const { employeeProfile, kycDetails } = data;
        // Store the fetched data and show approval popup
        setAadhaarData({
          employeeProfile,
          kycDetails,
          employeeName: `${employeeProfile.firstName} ${employeeProfile.lastName}`.trim(),
          fatherName: employeeProfile.fatherName || 'Not Available',
          dateOfBirth: employeeProfile.dateOfBirth ? 
            new Date(employeeProfile.dateOfBirth).toLocaleDateString('en-IN') : 
            'Not Available'
        });
        setShowAadhaarPopup(true);
        setLookupMessage('✅ Employee data found - Please review and approve');
      } else {
        setLookupMessage('ℹ️ No existing profile found - proceed with new entry');
        toast({
          title: "New Employee",
          description: "No existing profile found. Please fill in all details.",
        });
      }
      setIsLookingUp(false);
    },
    onError: (error: any) => {
      setLookupMessage('❌ Error looking up employee data');
      setIsLookingUp(false);
      toast({
        title: "Lookup Failed",
        description: error.message || "Failed to lookup employee data",
        variant: "destructive"
      });
    }
  });

  // Handle Aadhaar input and trigger lookup
  const handleAadhaarChange = (value: string) => {
    console.log('🆔 Aadhaar input changed:', value);
    
    // Format Aadhaar as user types (1234 5678 9012)
    const cleanValue = value.replace(/\s/g, '');
    const formattedValue = cleanValue.replace(/(\d{4})(\d{4})(\d{4})/, '$1 $2 $3');
    
    console.log('🔢 Clean value:', cleanValue, 'Length:', cleanValue.length);
    
    setFormData(prev => ({ ...prev, aadharNo: formattedValue }));
    
    // If 12 digits entered, automatically lookup
    if (cleanValue.length === 12) {
      console.log('✅ 12 digits entered, triggering lookup...');
      setIsLookingUp(true);
      setLookupMessage('🔍 Looking up employee data...');
      aadhaarLookupMutation.mutate(cleanValue);
    } else if (cleanValue.length > 12) {
      // Prevent more than 12 digits
      const truncated = cleanValue.substring(0, 12);
      const formattedTruncated = truncated.replace(/(\d{4})(\d{4})(\d{4})/, '$1 $2 $3');
      setFormData(prev => ({ ...prev, aadharNo: formattedTruncated }));
      console.log('✂️ Truncated to 12 digits');
    } else {
      setLookupMessage('');
      console.log('⏳ Waiting for 12 digits...');
    }
  };

  // Generic input handler for other fields
  const handleInputChange = (field: keyof EmployeeFormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Copy present address to permanent address
  const copyPresentToPermanent = () => {
    setFormData(prev => ({
      ...prev,
      permanentAddress: prev.presentAddress
    }));
  };

  // Handle Aadhaar approval - populate form with fetched data
  const handleAadhaarApproval = () => {
    if (aadhaarData) {
      const { employeeProfile, kycDetails } = aadhaarData;
      setFormData(prev => ({
        ...prev,
        employeeName: `${employeeProfile.firstName} ${employeeProfile.lastName}`.trim(),
        fatherName: employeeProfile.fatherName || '',
        presentAddress: employeeProfile.presentAddress || '',
        permanentAddress: employeeProfile.permanentAddress || '',
        aadharNo: kycDetails.aadharNo || prev.aadharNo,
        panNo: kycDetails.panNo || '',
        bankAccountNo: kycDetails.bankAccountNo || '',
        ifscCode: kycDetails.ifscCode || '',
        uanNo: kycDetails.uanNo || '',
        esicNo: kycDetails.esicNo || ''
      }));
      setShowAadhaarPopup(false);
      setActiveTab('personal'); // Switch to first tab
      toast({
        title: "Data Loaded Successfully",
        description: `Employee profile for ${employeeProfile.firstName} ${employeeProfile.lastName} has been loaded. You can modify any information before saving.`,
      });
    }
  };

  // Handle Aadhaar cancellation
  const handleAadhaarCancellation = () => {
    setShowAadhaarPopup(false);
    setAadhaarData(null);
    setLookupMessage('');
    // Clear the Aadhaar field to allow new entry
    setFormData(prev => ({ ...prev, aadharNo: '' }));
  };

  // Fetch departments
  const { data: departments = [] } = useQuery<any[]>({
    queryKey: [`/api/departments/${companyId}`],
    enabled: !!companyId,
  });

  // Mock data for other dropdowns (you can replace with real API calls)
  const designations = [
    { id: '1', title: 'Software Engineer' },
    { id: '2', title: 'Senior Software Engineer' },
    { id: '3', title: 'Team Lead' },
    { id: '4', title: 'Manager' },
    { id: '5', title: 'HR Executive' },
    { id: '6', title: 'Accountant' },
  ];

  const branches = [
    { id: '1', name: 'Headquarters' },
    { id: '2', name: 'West Coast Office' },
    { id: '3', name: 'Regional Branch' },
  ];

  const costCenters = [
    { id: '1', name: 'IT Department', code: 'CC001' },
    { id: '2', name: 'HR Department', code: 'CC002' },
    { id: '3', name: 'Finance Department', code: 'CC003' },
  ];

  const locations = [
    { id: '1', name: 'Floor 1 - Reception' },
    { id: '2', name: 'Floor 3 - Development' },
    { id: '3', name: 'Floor 2 - Administration' },
  ];

  const payrollSettings = [
    { id: 'monthly', name: 'Monthly Salary' },
    { id: 'hourly', name: 'Hourly Wages' },
    { id: 'contract', name: 'Contract Based' },
  ];

  const timeOfficePolicies = [
    { id: 'standard', name: 'Standard 9-5' },
    { id: 'flexible', name: 'Flexible Hours' },
    { id: 'shift', name: 'Shift Based' },
    { id: 'remote', name: 'Remote Work' },
  ];

  const createEmployeeMutation = useMutation({
    mutationFn: async (data: EmployeeFormData) => {
      // Map form data to database schema
      const [firstName, ...lastNameParts] = data.employeeName.split(' ');
      const lastName = lastNameParts.join(' ') || firstName;
      
      // Create simplified employee data matching the actual database schema
      const employeeData = {
        companyId: companyId,
        userId: user?.id || 1, // Use current user ID
        employeeId: data.payCode || `EMP${Date.now()}`,
        firstName: firstName,
        lastName: lastName,
        email: data.employeeName.toLowerCase().replace(/\s+/g, '.') + '@company.com',
        phone: data.aadharNo || '',
        departmentId: data.departmentId ? parseInt(data.departmentId) : undefined,
        position: data.designation || '',
        address: data.presentAddress || data.permanentAddress || '',
        status: 'active' as const,
      };

      console.log('Sending employee data:', employeeData);
      
      const response = await apiRequestWithAuth('POST', '/api/employees', employeeData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/employees/${companyId}`] });
      toast({
        title: "Success",
        description: "Employee created successfully",
      });
      setLocation('/admin/employees');
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create employee",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.employeeName || !formData.dateOfJoin || !formData.gender) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    createEmployeeMutation.mutate(formData);
  };



  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLocation('/admin/employees')}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Employees
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Add New Employee</h1>
          <p className="text-muted-foreground">Complete employee information form</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-7 bg-gray-100 p-1 rounded-lg">
            <TabsTrigger 
              value="personal" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <User className="h-4 w-4" />
              Personal
            </TabsTrigger>
            <TabsTrigger 
              value="employment" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Building2 className="h-4 w-4" />
              Employment
            </TabsTrigger>
            <TabsTrigger 
              value="address" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Home className="h-4 w-4" />
              Address
            </TabsTrigger>
            <TabsTrigger 
              value="identity" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Shield className="h-4 w-4" />
              Identity
            </TabsTrigger>
            <TabsTrigger 
              value="payroll" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <DollarSign className="h-4 w-4" />
              Payroll
            </TabsTrigger>
            <TabsTrigger 
              value="timeoffice" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Clock className="h-4 w-4" />
              Time Office
            </TabsTrigger>
            <TabsTrigger 
              value="family" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Users className="h-4 w-4" />
              Family
            </TabsTrigger>
          </TabsList>

          {/* Personal Information Tab */}
          <TabsContent value="personal" className="space-y-6">
            <Card className="border-l-4 border-l-hr-primary">
              <CardHeader className="bg-gradient-to-r from-hr-primary/5 to-transparent">
                <CardTitle className="flex items-center gap-3 text-hr-primary">
                  <User className="h-6 w-6" />
                  Personal Information
                </CardTitle>
                <CardDescription className="text-gray-600">Basic personal details and identification</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="employeeName" className="text-sm font-semibold text-gray-700">
                    Employee Full Name *
                  </Label>
                  <Input
                    id="employeeName"
                    value={formData.employeeName}
                    onChange={(e) => handleInputChange('employeeName', e.target.value)}
                    placeholder="Enter complete full name"
                    className="h-12 border-2 focus:border-hr-primary"
                    required
                  />
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-semibold text-gray-700">
                      {formData.isHusbandName ? "Husband Name" : "Father Name"}
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isHusbandName"
                        checked={formData.isHusbandName}
                        onCheckedChange={(checked) => handleInputChange('isHusbandName', checked as boolean)}
                      />
                      <Label htmlFor="isHusbandName" className="text-xs text-gray-600">Use Husband Name</Label>
                    </div>
                  </div>
                  <Input
                    id="fatherName"
                    value={formData.fatherName}
                    onChange={(e) => handleInputChange('fatherName', e.target.value)}
                    placeholder={formData.isHusbandName ? "Enter husband's name" : "Enter father's name"}
                    className="h-12 border-2 focus:border-hr-primary"
                  />
                </div>
              </div>

              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="dateOfBirth" className="text-sm font-semibold text-gray-700">
                    Date of Birth
                  </Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                    className="h-12 border-2 focus:border-hr-primary"
                  />
                </div>

                <div className="space-y-3">
                  <Label htmlFor="dateOfJoin" className="text-sm font-semibold text-gray-700">
                    Date of Joining *
                  </Label>
                  <Input
                    id="dateOfJoin"
                    type="date"
                    value={formData.dateOfJoin}
                    onChange={(e) => handleInputChange('dateOfJoin', e.target.value)}
                    className="h-12 border-2 focus:border-hr-primary"
                    required
                  />
                </div>
              </div>

              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="gender" className="text-sm font-semibold text-gray-700">
                    Gender *
                  </Label>
                  <Select value={formData.gender} onValueChange={(value) => handleInputChange('gender', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-hr-primary">
                      <SelectValue placeholder="Choose gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="payCode" className="text-sm font-semibold text-gray-700">
                    Employee Pay Code *
                  </Label>
                  <Input
                    id="payCode"
                    value={formData.payCode}
                    onChange={(e) => handleInputChange('payCode', e.target.value)}
                    placeholder="Enter employee pay code"
                    className="h-12 border-2 focus:border-hr-primary"
                    required
                  />
                  <p className="text-xs text-gray-500">Unique identifier for payroll processing</p>
                </div>
              </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Employment Details Tab */}
          <TabsContent value="employment" className="space-y-6">
            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-blue-700">
                  <Building2 className="h-6 w-6" />
                  Employment Details
                </CardTitle>
                <CardDescription className="text-gray-600">Department, position, and workplace assignment</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="departmentId" className="text-sm font-semibold text-gray-700">
                    Department
                  </Label>
                  <Select value={formData.departmentId} onValueChange={(value) => handleInputChange('departmentId', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Choose department" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments.map((dept: any) => (
                        <SelectItem key={dept.id} value={dept.id.toString()}>{dept.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="designation" className="text-sm font-semibold text-gray-700">
                    Designation
                  </Label>
                  <Select value={formData.designation} onValueChange={(value) => handleInputChange('designation', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Select job title" />
                    </SelectTrigger>
                    <SelectContent>
                      {designations.map((designation) => (
                        <SelectItem key={designation.id} value={designation.id}>{designation.title}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="branchId" className="text-sm font-semibold text-gray-700">
                    Branch/Office
                  </Label>
                  <Select value={formData.branchId} onValueChange={(value) => handleInputChange('branchId', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Select office branch" />
                    </SelectTrigger>
                    <SelectContent>
                      {branches.map((branch) => (
                        <SelectItem key={branch.id} value={branch.id}>{branch.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="costCenterId" className="text-sm font-semibold text-gray-700">
                    Cost Center
                  </Label>
                  <Select value={formData.costCenterId} onValueChange={(value) => handleInputChange('costCenterId', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Select cost center" />
                    </SelectTrigger>
                    <SelectContent>
                      {costCenters.map((center) => (
                        <SelectItem key={center.id} value={center.id}>
                          {center.code} - {center.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="locationId" className="text-sm font-semibold text-gray-700">
                    Work Location
                  </Label>
                  <Select value={formData.locationId} onValueChange={(value) => handleInputChange('locationId', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Select work location" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations.map((location) => (
                        <SelectItem key={location.id} value={location.id}>{location.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          {/* Address Information Tab */}
          <TabsContent value="address" className="space-y-6">
            <Card className="border-l-4 border-l-green-500">
              <CardHeader className="bg-gradient-to-r from-green-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-green-700">
                  <Home className="h-6 w-6" />
                  Address Information
                </CardTitle>
                <CardDescription className="text-gray-600">Current and permanent residential addresses</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="space-y-3">
                  <Label htmlFor="presentAddress" className="text-sm font-semibold text-gray-700">
                    Present Address
                  </Label>
                  <Textarea
                    id="presentAddress"
                    value={formData.presentAddress}
                    onChange={(e) => handleInputChange('presentAddress', e.target.value)}
                    placeholder="Enter complete current residential address with landmark"
                    className="min-h-[120px] border-2 focus:border-green-500 resize-none"
                    rows={5}
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="permanentAddress" className="text-sm font-semibold text-gray-700">
                      Permanent Address
                    </Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={copyPresentToPermanent}
                      className="text-xs border-green-500 text-green-600 hover:bg-green-50"
                    >
                      Copy from Present
                    </Button>
                  </div>
                  <Textarea
                    id="permanentAddress"
                    value={formData.permanentAddress}
                    onChange={(e) => handleInputChange('permanentAddress', e.target.value)}
                    placeholder="Enter permanent address (if different from present)"
                    className="min-h-[120px] border-2 focus:border-green-500 resize-none"
                    rows={5}
                  />
                </div>
              </div>
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          {/* Identity & Financial Information Tab */}
          <TabsContent value="identity" className="space-y-6">
            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-purple-700">
                  <Shield className="h-6 w-6" />
                  Identity & Financial Information
                </CardTitle>
                <CardDescription className="text-gray-600">Government documents, banking details, and compliance information</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="space-y-8">
              {/* Identity Documents */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">Identity Documents</h4>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="aadharNo" className="text-sm font-semibold text-gray-700">
                      Aadhar Number <span className="text-xs text-blue-600">(Auto-lookup enabled)</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="aadharNo"
                        value={formData.aadharNo}
                        onChange={(e) => handleAadhaarChange(e.target.value)}
                        placeholder="1234 5678 9012"
                        maxLength={14}
                        className="h-12 border-2 focus:border-purple-500 font-mono tracking-wider"
                        disabled={isLookingUp}
                      />
                      {isLookingUp && (
                        <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-purple-600"></div>
                        </div>
                      )}
                    </div>
                    {lookupMessage && (
                      <p className={`text-xs mt-2 ${
                        lookupMessage.includes('✅') ? 'text-green-600' : 
                        lookupMessage.includes('❌') ? 'text-red-600' : 
                        lookupMessage.includes('🔍') ? 'text-blue-600' : 'text-gray-600'
                      }`}>
                        {lookupMessage}
                      </p>
                    )}
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        console.log('🧪 Test button clicked');
                        if (formData.aadharNo.replace(/\s/g, '').length === 12) {
                          aadhaarLookupMutation.mutate(formData.aadharNo.replace(/\s/g, ''));
                        } else {
                          console.log('⚠️ Need exactly 12 digits for test');
                        }
                      }}
                      className="mt-2 text-xs"
                    >
                      🧪 Test Lookup
                    </Button>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="panNo" className="text-sm font-semibold text-gray-700">
                      PAN Number
                    </Label>
                    <Input
                      id="panNo"
                      value={formData.panNo}
                      onChange={(e) => handleInputChange('panNo', e.target.value.toUpperCase())}
                      placeholder="ABCDE1234F"
                      maxLength={10}
                      className="h-12 border-2 focus:border-purple-500 font-mono tracking-wider uppercase"
                    />
                  </div>
                </div>
              </div>

              {/* Banking Details */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">Banking Details</h4>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="bankAccountNo" className="text-sm font-semibold text-gray-700">
                      Bank Account Number
                    </Label>
                    <Input
                      id="bankAccountNo"
                      value={formData.bankAccountNo}
                      onChange={(e) => handleInputChange('bankAccountNo', e.target.value)}
                      placeholder="Enter account number"
                      className="h-12 border-2 focus:border-purple-500 font-mono"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="ifscCode" className="text-sm font-semibold text-gray-700">
                      IFSC Code
                    </Label>
                    <Input
                      id="ifscCode"
                      value={formData.ifscCode}
                      onChange={(e) => handleInputChange('ifscCode', e.target.value.toUpperCase())}
                      placeholder="ABCD0123456"
                      maxLength={11}
                      className="h-12 border-2 focus:border-purple-500 font-mono tracking-wider uppercase"
                    />
                  </div>
                </div>
              </div>

              {/* Compliance Information */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">Compliance Information</h4>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="uanNo" className="text-sm font-semibold text-gray-700">
                      UAN Number (Provident Fund)
                    </Label>
                    <Input
                      id="uanNo"
                      value={formData.uanNo}
                      onChange={(e) => handleInputChange('uanNo', e.target.value.replace(/\D/g, ''))}
                      placeholder="123456789012"
                      maxLength={12}
                      className="h-12 border-2 focus:border-purple-500 font-mono"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="esicNo" className="text-sm font-semibold text-gray-700">
                      ESIC Number
                    </Label>
                    <Input
                      id="esicNo"
                      value={formData.esicNo}
                      onChange={(e) => handleInputChange('esicNo', e.target.value)}
                      placeholder="1234567890"
                      className="h-12 border-2 focus:border-purple-500 font-mono"
                    />
                  </div>
                </div>
              </div>
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          {/* Payroll Information Tab */}
          <TabsContent value="payroll" className="space-y-6">
            <Card className="border-l-4 border-l-orange-500">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-orange-700">
                  <DollarSign className="h-6 w-6" />
                  Payroll Settings
                </CardTitle>
                <CardDescription className="text-gray-600">Compensation structure and payroll configuration</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <Label htmlFor="payrollSetting" className="text-sm font-semibold text-gray-700">
                      Payroll Setting *
                    </Label>
                    <Select value={formData.payrollSetting} onValueChange={(value) => handleInputChange('payrollSetting', value)}>
                      <SelectTrigger className="h-12 border-2 focus:border-orange-500">
                        <SelectValue placeholder="Choose payroll type" />
                      </SelectTrigger>
                      <SelectContent>
                        {payrollSettings.map((setting) => (
                          <SelectItem key={setting.id} value={setting.id}>{setting.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Time Office Policy Tab */}
          <TabsContent value="timeoffice" className="space-y-6">
            <Card className="border-l-4 border-l-indigo-500">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-indigo-700">
                  <Clock className="h-6 w-6" />
                  Time Office Policy
                </CardTitle>
                <CardDescription className="text-gray-600">Work schedule, attendance rules, and time management policies</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Duty Timing */}
                  <div className="space-y-6">
                    <h4 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2">Work Timing</h4>
                    <div className="space-y-3">
                      <Label htmlFor="dutyStartTime" className="text-sm font-semibold text-gray-700">
                        Duty Start Time *
                      </Label>
                      <Input
                        id="dutyStartTime"
                        type="time"
                        value={formData.dutyStartTime}
                        onChange={(e) => handleInputChange('dutyStartTime', e.target.value)}
                        className="h-12 border-2 focus:border-indigo-500"
                        required
                      />
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="dutyEndTime" className="text-sm font-semibold text-gray-700">
                        Duty End Time *
                      </Label>
                      <Input
                        id="dutyEndTime"
                        type="time"
                        value={formData.dutyEndTime}
                        onChange={(e) => handleInputChange('dutyEndTime', e.target.value)}
                        className="h-12 border-2 focus:border-indigo-500"
                        required
                      />
                    </div>
                  </div>

                  {/* Permissible Timing */}
                  <div className="space-y-6">
                    <h4 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2">Flexibility Rules</h4>
                    <div className="space-y-3">
                      <Label htmlFor="permissibleLateArrival" className="text-sm font-semibold text-gray-700">
                        Permissible Late Arrival (minutes)
                      </Label>
                      <Input
                        id="permissibleLateArrival"
                        type="number"
                        min="0"
                        max="120"
                        value={formData.permissibleLateArrival}
                        onChange={(e) => handleInputChange('permissibleLateArrival', e.target.value)}
                        placeholder="30"
                        className="h-12 border-2 focus:border-indigo-500"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="permissibleEarlyDeparture" className="text-sm font-semibold text-gray-700">
                        Permissible Early Departure (minutes)
                      </Label>
                      <Input
                        id="permissibleEarlyDeparture"
                        type="number"
                        min="0"
                        max="120"
                        value={formData.permissibleEarlyDeparture}
                        onChange={(e) => handleInputChange('permissibleEarlyDeparture', e.target.value)}
                        placeholder="15"
                        className="h-12 border-2 focus:border-indigo-500"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="presentMarkingDuration" className="text-sm font-semibold text-gray-700">
                        Present Marking Duration (hours)
                      </Label>
                      <Input
                        id="presentMarkingDuration"
                        type="number"
                        min="1"
                        max="12"
                        step="0.5"
                        value={formData.presentMarkingDuration}
                        onChange={(e) => handleInputChange('presentMarkingDuration', e.target.value)}
                        placeholder="4"
                        className="h-12 border-2 focus:border-indigo-500"
                      />
                      <p className="text-xs text-gray-500">Minimum hours for half-day marking</p>
                    </div>
                  </div>

                  {/* Weekly Offs & OT */}
                  <div className="space-y-6">
                    <h4 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2">Weekly Offs & Overtime</h4>
                    <div className="space-y-3">
                      <Label htmlFor="firstWeeklyOffDay" className="text-sm font-semibold text-gray-700">
                        First Weekly Off Day *
                      </Label>
                      <Select value={formData.firstWeeklyOffDay} onValueChange={(value) => handleInputChange('firstWeeklyOffDay', value)}>
                        <SelectTrigger className="h-12 border-2 focus:border-indigo-500">
                          <SelectValue placeholder="Select day" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sunday">Sunday</SelectItem>
                          <SelectItem value="monday">Monday</SelectItem>
                          <SelectItem value="tuesday">Tuesday</SelectItem>
                          <SelectItem value="wednesday">Wednesday</SelectItem>
                          <SelectItem value="thursday">Thursday</SelectItem>
                          <SelectItem value="friday">Friday</SelectItem>
                          <SelectItem value="saturday">Saturday</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="secondWeeklyOffDay" className="text-sm font-semibold text-gray-700">
                        Second Weekly Off Day
                      </Label>
                      <Select value={formData.secondWeeklyOffDay} onValueChange={(value) => handleInputChange('secondWeeklyOffDay', value)}>
                        <SelectTrigger className="h-12 border-2 focus:border-indigo-500">
                          <SelectValue placeholder="Select day (optional)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          <SelectItem value="sunday">Sunday</SelectItem>
                          <SelectItem value="monday">Monday</SelectItem>
                          <SelectItem value="tuesday">Tuesday</SelectItem>
                          <SelectItem value="wednesday">Wednesday</SelectItem>
                          <SelectItem value="thursday">Thursday</SelectItem>
                          <SelectItem value="friday">Friday</SelectItem>
                          <SelectItem value="saturday">Saturday</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <Checkbox
                          id="overtimeApplicable"
                          checked={formData.overtimeApplicable}
                          onCheckedChange={(checked) => handleInputChange('overtimeApplicable', checked as boolean)}
                          className="border-2 border-indigo-500"
                        />
                        <Label htmlFor="overtimeApplicable" className="text-sm font-semibold text-gray-700">
                          Overtime Applicable
                        </Label>
                      </div>
                      <p className="text-xs text-gray-500 pl-7">
                        Enable overtime calculation for extra working hours
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Family & Emergency Contact Tab */}
          <TabsContent value="family" className="space-y-6">
            <Card className="border-l-4 border-l-pink-500">
              <CardHeader className="bg-gradient-to-r from-pink-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-pink-700">
                  <Users className="h-6 w-6" />
                  Family & Emergency Contact
                </CardTitle>
                <CardDescription className="text-gray-600">Family member information and emergency contact details</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="space-y-3">
              <Label htmlFor="familyDetails" className="text-sm font-semibold text-gray-700">
                Family Details & Emergency Contact
              </Label>
              <Textarea
                id="familyDetails"
                value={formData.familyDetails}
                onChange={(e) => handleInputChange('familyDetails', e.target.value)}
                placeholder="Enter family member details, emergency contact person name, relationship, phone number, address, etc."
                className="min-h-[150px] border-2 focus:border-pink-500 resize-none"
                rows={6}
              />
              <p className="text-xs text-gray-500 mt-2">
                Include: Emergency contact name, relationship, phone number, alternate contact details, family member information for benefits/insurance purposes
              </p>
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          {/* Submit Actions - Always visible */}
          <div className="bg-gray-50 p-8 rounded-lg border border-gray-200 mt-8">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
              <div className="text-sm text-gray-600">
                <p className="font-medium">Ready to create employee profile?</p>
                <p>All information will be saved securely in the system.</p>
              </div>
              <div className="flex space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation('/admin/employees')}
                  className="px-8 py-3 border-2 hover:bg-gray-100"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="px-8 py-3 bg-hr-primary hover:bg-hr-primary/90 text-white font-semibold shadow-lg"
                  disabled={createEmployeeMutation.isPending}
                >
                  {createEmployeeMutation.isPending ? (
                    <>
                      <Clock className="mr-2 h-4 w-4 animate-spin" />
                      Creating Employee...
                    </>
                  ) : (
                    <>
                      <User className="mr-2 h-4 w-4" />
                      Create Employee Profile
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </Tabs>
      </form>

      {/* Aadhaar Verification Popup */}
      <Dialog open={showAadhaarPopup} onOpenChange={setShowAadhaarPopup}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-blue-700">
              <IdCard className="h-6 w-6" />
              Aadhaar Verification - Employee Found
            </DialogTitle>
            <DialogDescription>
              Employee profile found in the system. Please review the details below and approve to proceed.
            </DialogDescription>
          </DialogHeader>
          
          {aadhaarData && (
            <div className="space-y-4 py-4">
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h4 className="font-semibold text-blue-800 mb-3">Employee Details from Aadhaar</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Employee Name:</span>
                    <span className="font-semibold text-gray-900">{aadhaarData.employeeName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Father's Name:</span>
                    <span className="font-semibold text-gray-900">{aadhaarData.fatherName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Date of Birth:</span>
                    <span className="font-semibold text-gray-900">{aadhaarData.dateOfBirth}</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                <p className="text-sm text-amber-800">
                  <strong>Note:</strong> Clicking "Approve" will load this employee's existing profile data into the registration form. You can modify any information before saving.
                </p>
              </div>
            </div>
          )}

          <DialogFooter className="gap-3">
            <Button
              variant="outline"
              onClick={handleAadhaarCancellation}
              className="px-6 py-2 border-2 border-gray-300 hover:bg-gray-100"
            >
              <XCircle className="mr-2 h-4 w-4" />
              Cancel
            </Button>
            <Button
              onClick={handleAadhaarApproval}
              className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white"
            >
              <CheckCircle className="mr-2 h-4 w-4" />
              Approve & Load Data
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function AddEmployee() {
  const { hasPermission: canCreateEmployee, loading: permissionLoading } = usePermission('employee_create');
  
  if (permissionLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Checking permissions...</p>
        </div>
      </div>
    );
  }
  
  if (!canCreateEmployee) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Shield className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-red-600 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">You don't have permission to create employees.</p>
          <p className="text-sm text-gray-500">Request 'employee_create' permission from your administrator.</p>
        </div>
      </div>
    );
  }

  return <AddEmployeeContent />;
}