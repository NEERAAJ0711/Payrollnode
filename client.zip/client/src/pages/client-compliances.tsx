import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, CheckSquare, Database } from 'lucide-react';
import ClientList from './client-list';
import EmployeeCompliancesSetup from './employee-compliances-setup';
import CompliancesData from './compliances-data';

export default function ClientCompliances() {
  const [activeTab, setActiveTab] = useState('client-list');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Client Compliances Management</h1>
        <p className="text-gray-600 mt-2">Comprehensive compliance management system for client projects and employee setup</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="client-list" className="flex items-center space-x-2">
            <FileText className="w-4 h-4" />
            <span>Client List</span>
          </TabsTrigger>
          <TabsTrigger value="employee-setup" className="flex items-center space-x-2">
            <CheckSquare className="w-4 h-4" />
            <span>Employee Setup</span>
          </TabsTrigger>
          <TabsTrigger value="compliances-data" className="flex items-center space-x-2">
            <Database className="w-4 h-4" />
            <span>Compliances Data</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="client-list" className="space-y-4">
          <div className="bg-white rounded-lg border shadow-sm">
            <ClientList />
          </div>
        </TabsContent>

        <TabsContent value="employee-setup" className="space-y-4">
          <div className="bg-white rounded-lg border shadow-sm">
            <EmployeeCompliancesSetup />
          </div>
        </TabsContent>

        <TabsContent value="compliances-data" className="space-y-4">
          <div className="bg-white rounded-lg border shadow-sm">
            <CompliancesData />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}