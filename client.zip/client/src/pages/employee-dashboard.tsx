import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Link } from "wouter";
import { Calendar, Clock, FileText, User, Settings, Bell, MapPin, Phone, Building2, AlertCircle, Search, DollarSign } from "lucide-react";
import { useAuth } from "@/lib/auth";

export default function EmployeeDashboard() {
  const { user } = useAuth();
  
  const { data: employee } = useQuery({
    queryKey: ['/api/employee/profile'],
    enabled: !!user?.id,
  });

  const { data: company } = useQuery({
    queryKey: [`/api/companies/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: attendance = [] } = useQuery({
    queryKey: [`/api/attendance/${employee?.id}`],
    enabled: !!employee?.id,
  });

  const { data: jobs = [] } = useQuery({
    queryKey: [`/api/jobs/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: publicJobs = [] } = useQuery({
    queryKey: ['/api/jobs/public'],
    enabled: !!user?.id,
  });

  const { data: permissionRequests = [] } = useQuery({
    queryKey: ['/api/permission-requests'],
  });

  const todayAttendance = attendance.find((a: any) => {
    const today = new Date().toDateString();
    return new Date(a.date).toDateString() === today;
  });

  const recentJobs = jobs.filter((job: any) => job.status === 'active').slice(0, 3);
  const myRequests = permissionRequests.filter((req: any) => req.requestedBy === user?.id);

  const getInitials = (firstName?: string, lastName?: string) => {
    return `${firstName?.charAt(0) || ''}${lastName?.charAt(0) || ''}`.toUpperCase();
  };

  // Check employee status by Aadhaar verification
  const { data: employeeStatus, isLoading: statusLoading } = useQuery({
    queryKey: ['/api/employee/aadhaar-status'],
    enabled: !!user?.id && user?.role === 'employee',
    staleTime: 0, // Always refetch to get latest status
    refetchOnMount: true,
  });

  // Show loading while checking status
  if (statusLoading || !employeeStatus) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p>Loading dashboard...</p>
      </div>
    </div>;
  }

  // Debug logging
  console.log('EmployeeDashboard - employeeStatus:', employeeStatus);
  console.log('EmployeeDashboard - aadhaarVerified:', employeeStatus?.aadhaarVerified);
  console.log('EmployeeDashboard - isEmployeeInCompany:', employeeStatus?.isEmployeeInCompany);

  // If employee is NOT in any company database, show job search interface
  if (employeeStatus?.aadhaarVerified === true && employeeStatus?.isEmployeeInCompany === false) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Welcome, {employee?.firstName || user?.username}
            </h1>
            <p className="text-muted-foreground">
              Complete your profile and search for job opportunities
            </p>
          </div>
          <div className="flex gap-2">
            <Link href="/profile">
              <Button>
                <User className="mr-2 h-4 w-4" />
                My Profile
              </Button>
            </Link>
          </div>
        </div>



        {/* Available Actions */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Job Search */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5 text-blue-600" />
                Available Jobs
              </CardTitle>
              <CardDescription>
                Search and apply for available positions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {publicJobs.length > 0 ? (
                  <div className="space-y-3">
                    {publicJobs.slice(0, 3).map((job: any) => (
                      <div key={job.id} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">{job.title}</h4>
                            <p className="text-sm text-gray-600">{job.department}</p>
                          </div>
                          <Badge variant={job.status === 'active' ? 'default' : 'secondary'}>
                            {job.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {publicJobs.length > 3 && (
                      <p className="text-sm text-gray-500">
                        +{publicJobs.length - 3} more jobs available
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-8">
                    No jobs available at the moment
                  </p>
                )}
                <Link href="/jobs">
                  <Button className="w-full">
                    <Search className="mr-2 h-4 w-4" />
                    Browse All Jobs
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Profile Completion */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-green-600" />
                Profile Management
              </CardTitle>
              <CardDescription>
                Complete your profile while waiting for company assignment
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">Personal Information</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">Contact Details</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm">Professional Details</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                </div>
                <Link href="/profile">
                  <Button variant="outline" className="w-full">
                    <User className="mr-2 h-4 w-4" />
                    Update Profile
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Welcome back, {employee?.firstName || user?.username}
          </h1>
          <p className="text-muted-foreground">
            {employee?.position} at {company?.name}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Bell className="mr-2 h-4 w-4" />
            Notifications
          </Button>
          <Link href="/employee/profile">
            <Button>
              <User className="mr-2 h-4 w-4" />
              My Profile
            </Button>
          </Link>
        </div>
      </div>

      {/* Employee Info Card */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center space-x-4">
            <Avatar className="h-20 w-20">
              <AvatarFallback className="text-lg">
                {getInitials(employee?.firstName, employee?.lastName)}
              </AvatarFallback>
            </Avatar>
            <div className="space-y-1 flex-1">
              <h3 className="text-xl font-semibold">
                {employee?.firstName} {employee?.lastName}
              </h3>
              <p className="text-muted-foreground">{employee?.position}</p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {employee?.address || 'No address on file'}
                </div>
                <div className="flex items-center gap-1">
                  <Phone className="h-3 w-3" />
                  {employee?.phone || 'No phone on file'}
                </div>
              </div>
            </div>
            <div className="text-right">
              <Badge variant={employee?.status === 'active' ? 'default' : 'secondary'}>
                {employee?.status || 'Active'}
              </Badge>
              <p className="text-sm text-muted-foreground mt-1">
                Employee ID: {employee?.employeeId}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Status</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {todayAttendance ? 
                (todayAttendance.isPresent ? 'Present' : 'Absent') : 
                'Not Checked In'
              }
            </div>
            <p className="text-xs text-muted-foreground">
              {todayAttendance?.checkIn ? 
                `Checked in at ${new Date(todayAttendance.checkIn).toLocaleTimeString()}` :
                'Click to check in'
              }
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">This Month</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {attendance.filter((a: any) => {
                const month = new Date().getMonth();
                return new Date(a.date).getMonth() === month && a.isPresent;
              }).length}
            </div>
            <p className="text-xs text-muted-foreground">
              Days present
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Requests</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {myRequests.filter((r: any) => r.status === 'pending').length}
            </div>
            <p className="text-xs text-muted-foreground">
              Permission requests
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Attendance Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Attendance Tracking
            </CardTitle>
            <CardDescription>
              Manage your daily check-in and attendance
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!todayAttendance ? (
              <div className="text-center py-6">
                <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-lg font-medium mb-2">Ready to start your day?</p>
                <Button className="w-full">
                  Check In Now
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Check In:</span>
                  <span className="font-medium">
                    {todayAttendance.checkIn ? 
                      new Date(todayAttendance.checkIn).toLocaleTimeString() : 
                      'Not checked in'
                    }
                  </span>
                </div>
                {todayAttendance.checkOut ? (
                  <div className="flex justify-between">
                    <span>Check Out:</span>
                    <span className="font-medium">
                      {new Date(todayAttendance.checkOut).toLocaleTimeString()}
                    </span>
                  </div>
                ) : (
                  <Button className="w-full" variant="destructive">
                    Check Out
                  </Button>
                )}
                {todayAttendance.hoursWorked && (
                  <div className="flex justify-between">
                    <span>Hours Worked:</span>
                    <span className="font-medium">{todayAttendance.hoursWorked}h</span>
                  </div>
                )}
              </div>
            )}
            <div className="pt-2">
              <Link href="/employee/attendance">
                <Button variant="outline" className="w-full">
                  View Attendance History
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Open Positions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Available Positions
            </CardTitle>
            <CardDescription>
              Internal job opportunities at {company?.name}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentJobs.length > 0 ? (
              recentJobs.map((job: any) => (
                <div key={job.id} className="border rounded-lg p-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">{job.title}</h4>
                      <p className="text-sm text-muted-foreground">{job.location}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {job.employmentType} • Posted {new Date(job.postedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge variant="outline">
                      Internal
                    </Badge>
                  </div>
                  <div className="mt-3">
                    <Button size="sm" variant="outline" className="w-full">
                      View Details
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-6">
                No open positions at this time
              </p>
            )}
          </CardContent>
        </Card>

        {/* Permission Requests */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Permission Requests
            </CardTitle>
            <CardDescription>
              Your submitted requests and their status
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {myRequests.length > 0 ? (
              myRequests.slice(0, 3).map((request: any) => (
                <div key={request.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">
                      {request.permissionType.replace('_', ' ')}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(request.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant={
                    request.status === 'approved' ? 'default' :
                    request.status === 'pending' ? 'secondary' : 'destructive'
                  }>
                    {request.status}
                  </Badge>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-4">
                No permission requests submitted
              </p>
            )}
            <div className="pt-2">
              <Button className="w-full" variant="outline">
                Request New Permission
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>
              Common tasks and shortcuts
            </CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            <Link href="/employee/profile">
              <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
                <User className="h-5 w-5" />
                <span>Update Profile</span>
              </Button>
            </Link>
            <Link href="/employee/attendance">
              <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
                <Calendar className="h-5 w-5" />
                <span>View Schedule</span>
              </Button>
            </Link>
            <Link href="/employee/requests">
              <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
                <FileText className="h-5 w-5" />
                <span>Submit Request</span>
              </Button>
            </Link>
            <Link href="/employee/payroll">
              <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
                <Settings className="h-5 w-5" />
                <span>View Payroll</span>
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}