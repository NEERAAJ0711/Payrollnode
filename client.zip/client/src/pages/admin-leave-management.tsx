import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Clock, CheckCircle, XCircle, Eye, Filter, Search, Users, FileText } from "lucide-react";
import { authService } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";

interface LeaveRequest {
  id: number;
  employeeId: number;
  companyId: number;
  leaveType: string;
  startDate: string;
  endDate: string;
  totalDays: string;
  reason: string;
  status: string;
  appliedAt: string;
  level1ApprovedAt?: string;
  level2ApprovedAt?: string;
  finalApprovedAt?: string;
  rejectedAt?: string;
  rejectionReason?: string;
  employee?: {
    firstName: string;
    lastName: string;
    department?: string;
  };
}

const StatusBadges = {
  pending: { color: "bg-yellow-100 text-yellow-800", label: "Pending" },
  approved: { color: "bg-green-100 text-green-800", label: "Approved" },
  rejected: { color: "bg-red-100 text-red-800", label: "Rejected" },
  cancelled: { color: "bg-gray-100 text-gray-800", label: "Cancelled" }
};

const LeaveTypeLabels = {
  casual: "Casual Leave",
  sick: "Sick Leave",
  annual: "Annual Leave",
  maternity: "Maternity Leave",
  paternity: "Paternity Leave",
  emergency: "Emergency Leave"
};

export default function AdminLeaveManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedLeave, setSelectedLeave] = useState<LeaveRequest | null>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [approvalDialogOpen, setApprovalDialogOpen] = useState(false);
  const [rejectionDialogOpen, setRejectionDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [comments, setComments] = useState("");
  const [rejectionReason, setRejectionReason] = useState("");

  const user = authService.getUser();
  const companyId = user?.companyId;

  const { data: leaveRequests = [], isLoading } = useQuery<LeaveRequest[]>({
    queryKey: [`/api/leave-requests/${companyId}`],
    enabled: !!companyId,
  });

  const approveMutation = useMutation({
    mutationFn: async ({ id, level, comments }: { id: number; level: 1 | 2 | 3; comments?: string }) => {
      return await apiRequest(`/api/leave-requests/${id}/approve`, 'PUT', { level, comments });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/leave-requests/${companyId}`] });
      setApprovalDialogOpen(false);
      setComments("");
      toast({
        title: "Success",
        description: "Leave request approved successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to approve leave request",
        variant: "destructive"
      });
    }
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: number; reason: string }) => {
      return await apiRequest(`/api/leave-requests/${id}/reject`, 'PUT', { reason });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/leave-requests/${companyId}`] });
      setRejectionDialogOpen(false);
      setRejectionReason("");
      toast({
        title: "Success",
        description: "Leave request rejected",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reject leave request",
        variant: "destructive"
      });
    }
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN');
  };

  const getApprovalStatus = (leave: LeaveRequest) => {
    if (leave.status === 'rejected') return 'Rejected';
    if (leave.status === 'approved') return 'Fully Approved';
    
    if (leave.finalApprovedAt) return 'Final Approved';
    if (leave.level2ApprovedAt) return 'Level 2 Approved';
    if (leave.level1ApprovedAt) return 'Level 1 Approved';
    
    return 'Pending Approval';
  };

  const getNextApprovalLevel = (leave: LeaveRequest): 1 | 2 | 3 => {
    if (!leave.level1ApprovedAt) return 1;
    if (!leave.level2ApprovedAt) return 2;
    return 3;
  };

  const filteredRequests = leaveRequests.filter(request => {
    const matchesStatus = filterStatus === "all" || request.status === filterStatus;
    const matchesSearch = !searchTerm || 
      `${request.employee?.firstName} ${request.employee?.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.leaveType.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesStatus && matchesSearch;
  });

  const stats = {
    total: leaveRequests.length,
    pending: leaveRequests.filter(req => req.status === 'pending').length,
    approved: leaveRequests.filter(req => req.status === 'approved').length,
    rejected: leaveRequests.filter(req => req.status === 'rejected').length,
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Loading leave requests...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Leave Management</h1>
          <p className="text-muted-foreground">
            Manage and approve employee leave requests
          </p>
        </div>
      </div>

      {/* Leave Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Requests</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.approved}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rejected</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.rejected}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle>Filter and Search</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <div className="flex-1">
              <Label htmlFor="search">Search Employee or Leave Type</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  id="search"
                  placeholder="Search by employee name or leave type..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="w-48">
              <Label htmlFor="status">Filter by Status</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Leave Requests List */}
      <Card>
        <CardHeader>
          <CardTitle>Leave Requests</CardTitle>
          <CardDescription>Review and manage employee leave applications</CardDescription>
        </CardHeader>
        <CardContent>
          {filteredRequests.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">No leave requests found</p>
              <p className="text-sm text-gray-400">Try adjusting your filters</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredRequests.map((leave) => (
                <div key={leave.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4">
                        <div>
                          <h3 className="font-semibold text-lg">
                            {leave.employee?.firstName} {leave.employee?.lastName}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {LeaveTypeLabels[leave.leaveType as keyof typeof LeaveTypeLabels]} • 
                            {formatDate(leave.startDate)} to {formatDate(leave.endDate)} • {leave.totalDays} day(s)
                          </p>
                        </div>
                      </div>
                      <p className="text-gray-700 mt-2 line-clamp-2">{leave.reason}</p>
                      <div className="mt-2 flex items-center space-x-4">
                        <Badge className={StatusBadges[leave.status as keyof typeof StatusBadges].color}>
                          {StatusBadges[leave.status as keyof typeof StatusBadges].label}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          Applied: {formatDate(leave.appliedAt)}
                        </span>
                        <span className="text-sm text-gray-600">
                          Status: {getApprovalStatus(leave)}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedLeave(leave);
                          setViewDialogOpen(true);
                        }}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      {leave.status === 'pending' && (
                        <>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => {
                              setSelectedLeave(leave);
                              setApprovalDialogOpen(true);
                            }}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setSelectedLeave(leave);
                              setRejectionDialogOpen(true);
                            }}
                          >
                            <XCircle className="w-4 h-4 mr-1" />
                            Reject
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Leave Details Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Leave Request Details</DialogTitle>
            <DialogDescription>Complete information about the leave request</DialogDescription>
          </DialogHeader>
          {selectedLeave && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">Employee</Label>
                  <p className="text-sm">{selectedLeave.employee?.firstName} {selectedLeave.employee?.lastName}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Leave Type</Label>
                  <p className="text-sm">{LeaveTypeLabels[selectedLeave.leaveType as keyof typeof LeaveTypeLabels]}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Start Date</Label>
                  <p className="text-sm">{formatDate(selectedLeave.startDate)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">End Date</Label>
                  <p className="text-sm">{formatDate(selectedLeave.endDate)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Total Days</Label>
                  <p className="text-sm">{selectedLeave.totalDays}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Status</Label>
                  <Badge className={StatusBadges[selectedLeave.status as keyof typeof StatusBadges].color}>
                    {StatusBadges[selectedLeave.status as keyof typeof StatusBadges].label}
                  </Badge>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">Reason</Label>
                <p className="text-sm mt-1 p-2 bg-gray-50 rounded">{selectedLeave.reason}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">Approval Status</Label>
                <p className="text-sm">{getApprovalStatus(selectedLeave)}</p>
              </div>
              {selectedLeave.rejectionReason && (
                <div>
                  <Label className="text-sm font-medium text-gray-500">Rejection Reason</Label>
                  <p className="text-sm mt-1 p-2 bg-red-50 rounded">{selectedLeave.rejectionReason}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Approval Dialog */}
      <Dialog open={approvalDialogOpen} onOpenChange={setApprovalDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Leave Request</DialogTitle>
            <DialogDescription>
              Add comments and approve this leave request (Level {selectedLeave ? getNextApprovalLevel(selectedLeave) : 1})
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="comments">Comments (Optional)</Label>
              <Textarea
                id="comments"
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                placeholder="Add any comments for this approval..."
                className="mt-1"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setApprovalDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (selectedLeave) {
                    approveMutation.mutate({
                      id: selectedLeave.id,
                      level: getNextApprovalLevel(selectedLeave),
                      comments
                    });
                  }
                }}
                disabled={approveMutation.isPending}
                className="bg-green-600 hover:bg-green-700"
              >
                {approveMutation.isPending ? "Approving..." : "Approve"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Rejection Dialog */}
      <Dialog open={rejectionDialogOpen} onOpenChange={setRejectionDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Leave Request</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this leave request
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="rejectionReason">Rejection Reason *</Label>
              <Textarea
                id="rejectionReason"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Explain why this leave request is being rejected..."
                className="mt-1"
                required
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setRejectionDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (selectedLeave && rejectionReason.trim()) {
                    rejectMutation.mutate({
                      id: selectedLeave.id,
                      reason: rejectionReason
                    });
                  }
                }}
                disabled={rejectMutation.isPending || !rejectionReason.trim()}
                variant="destructive"
              >
                {rejectMutation.isPending ? "Rejecting..." : "Reject"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}