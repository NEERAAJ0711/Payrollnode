import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { CreditCard, Clock, CheckCircle, XCircle, Eye, Filter, Search, Users, DollarSign, AlertCircle } from "lucide-react";
import { authService } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";

interface AdvanceRequest {
  id: number;
  employeeId: number;
  companyId: number;
  amount: string;
  reason: string;
  repaymentPeriod: string;
  status: string;
  requestedAt: string;
  level1ApprovedAt?: string;
  level2ApprovedAt?: string;
  finalApprovedAt?: string;
  rejectedAt?: string;
  rejectionReason?: string;
  paidAt?: string;
  paidAmount?: string;
  paymentMethod?: string;
  paymentReference?: string;
  employee?: {
    firstName: string;
    lastName: string;
    department?: string;
  };
}

const StatusBadges = {
  pending: { color: "bg-yellow-100 text-yellow-800", label: "Pending" },
  approved: { color: "bg-green-100 text-green-800", label: "Approved" },
  rejected: { color: "bg-red-100 text-red-800", label: "Rejected" },
  cancelled: { color: "bg-gray-100 text-gray-800", label: "Cancelled" },
  paid: { color: "bg-blue-100 text-blue-800", label: "Paid" }
};

export default function AdminAdvanceManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedAdvance, setSelectedAdvance] = useState<AdvanceRequest | null>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [approvalDialogOpen, setApprovalDialogOpen] = useState(false);
  const [rejectionDialogOpen, setRejectionDialogOpen] = useState(false);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [comments, setComments] = useState("");
  const [rejectionReason, setRejectionReason] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [paymentReference, setPaymentReference] = useState("");

  const user = authService.getUser();
  const companyId = user?.companyId;

  const { data: advanceRequests = [], isLoading } = useQuery<AdvanceRequest[]>({
    queryKey: [`/api/advance-requests/${companyId}`],
    enabled: !!companyId,
  });

  const approveMutation = useMutation({
    mutationFn: async ({ id, level, comments }: { id: number; level: 1 | 2 | 3; comments?: string }) => {
      return await apiRequest(`/api/advance-requests/${id}/approve`, 'PUT', { level, comments });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/advance-requests/${companyId}`] });
      setApprovalDialogOpen(false);
      setComments("");
      toast({
        title: "Success",
        description: "Advance request approved successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to approve advance request",
        variant: "destructive"
      });
    }
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: number; reason: string }) => {
      return await apiRequest(`/api/advance-requests/${id}/reject`, 'PUT', { reason });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/advance-requests/${companyId}`] });
      setRejectionDialogOpen(false);
      setRejectionReason("");
      toast({
        title: "Success",
        description: "Advance request rejected",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reject advance request",
        variant: "destructive"
      });
    }
  });

  const markPaidMutation = useMutation({
    mutationFn: async ({ id, amount, method, reference }: { id: number; amount: string; method: string; reference?: string }) => {
      return await apiRequest(`/api/advance-requests/${id}/mark-paid`, 'PUT', { paidAmount: amount, paymentMethod: method, reference });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/advance-requests/${companyId}`] });
      setPaymentDialogOpen(false);
      setPaymentAmount("");
      setPaymentMethod("");
      setPaymentReference("");
      toast({
        title: "Success",
        description: "Advance payment recorded successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to record payment",
        variant: "destructive"
      });
    }
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN');
  };

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(parseFloat(amount));
  };

  const getApprovalStatus = (advance: AdvanceRequest) => {
    if (advance.status === 'rejected') return 'Rejected';
    if (advance.status === 'paid') return 'Paid';
    if (advance.status === 'approved') return 'Fully Approved';
    
    if (advance.finalApprovedAt) return 'Final Approved';
    if (advance.level2ApprovedAt) return 'Level 2 Approved';
    if (advance.level1ApprovedAt) return 'Level 1 Approved';
    
    return 'Pending Approval';
  };

  const getNextApprovalLevel = (advance: AdvanceRequest): 1 | 2 | 3 => {
    if (!advance.level1ApprovedAt) return 1;
    if (!advance.level2ApprovedAt) return 2;
    return 3;
  };

  const filteredRequests = advanceRequests.filter(request => {
    const matchesStatus = filterStatus === "all" || request.status === filterStatus;
    const matchesSearch = !searchTerm || 
      `${request.employee?.firstName} ${request.employee?.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.reason.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesStatus && matchesSearch;
  });

  const stats = {
    total: advanceRequests.length,
    pending: advanceRequests.filter(req => req.status === 'pending').length,
    approved: advanceRequests.filter(req => req.status === 'approved').length,
    rejected: advanceRequests.filter(req => req.status === 'rejected').length,
    paid: advanceRequests.filter(req => req.status === 'paid').length,
    totalAmount: advanceRequests.reduce((sum, req) => sum + parseFloat(req.amount), 0),
    approvedAmount: advanceRequests
      .filter(req => req.status === 'approved' || req.status === 'paid')
      .reduce((sum, req) => sum + parseFloat(req.amount), 0),
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Loading advance requests...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Advance Management</h1>
          <p className="text-muted-foreground">
            Manage and approve employee advance requests
          </p>
        </div>
      </div>

      {/* Advance Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Requests</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.approved}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Paid</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.paid}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Amount</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">{formatCurrency(stats.totalAmount.toString())}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved Amount</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold text-green-600">{formatCurrency(stats.approvedAmount.toString())}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle>Filter and Search</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <div className="flex-1">
              <Label htmlFor="search">Search Employee or Reason</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  id="search"
                  placeholder="Search by employee name or advance reason..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="w-48">
              <Label htmlFor="status">Filter by Status</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Advance Requests List */}
      <Card>
        <CardHeader>
          <CardTitle>Advance Requests</CardTitle>
          <CardDescription>Review and manage employee advance applications</CardDescription>
        </CardHeader>
        <CardContent>
          {filteredRequests.length === 0 ? (
            <div className="text-center py-8">
              <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">No advance requests found</p>
              <p className="text-sm text-gray-400">Try adjusting your filters</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredRequests.map((advance) => (
                <div key={advance.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4">
                        <div>
                          <h3 className="font-semibold text-lg">
                            {advance.employee?.firstName} {advance.employee?.lastName}
                          </h3>
                          <p className="text-sm text-gray-600">
                            Amount: {formatCurrency(advance.amount)} • Repayment: {advance.repaymentPeriod} months
                          </p>
                        </div>
                      </div>
                      <p className="text-gray-700 mt-2 line-clamp-2">{advance.reason}</p>
                      <div className="mt-2 flex items-center space-x-4">
                        <Badge className={StatusBadges[advance.status as keyof typeof StatusBadges].color}>
                          {StatusBadges[advance.status as keyof typeof StatusBadges].label}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          Requested: {formatDate(advance.requestedAt)}
                        </span>
                        <span className="text-sm text-gray-600">
                          Status: {getApprovalStatus(advance)}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedAdvance(advance);
                          setViewDialogOpen(true);
                        }}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      {advance.status === 'pending' && (
                        <>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => {
                              setSelectedAdvance(advance);
                              setApprovalDialogOpen(true);
                            }}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setSelectedAdvance(advance);
                              setRejectionDialogOpen(true);
                            }}
                          >
                            <XCircle className="w-4 h-4 mr-1" />
                            Reject
                          </Button>
                        </>
                      )}
                      {advance.status === 'approved' && (
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => {
                            setSelectedAdvance(advance);
                            setPaymentAmount(advance.amount);
                            setPaymentDialogOpen(true);
                          }}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          <DollarSign className="w-4 h-4 mr-1" />
                          Mark Paid
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Advance Details Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Advance Request Details</DialogTitle>
            <DialogDescription>Complete information about the advance request</DialogDescription>
          </DialogHeader>
          {selectedAdvance && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">Employee</Label>
                  <p className="text-sm">{selectedAdvance.employee?.firstName} {selectedAdvance.employee?.lastName}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Amount</Label>
                  <p className="text-sm font-semibold">{formatCurrency(selectedAdvance.amount)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Repayment Period</Label>
                  <p className="text-sm">{selectedAdvance.repaymentPeriod} months</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Status</Label>
                  <Badge className={StatusBadges[selectedAdvance.status as keyof typeof StatusBadges].color}>
                    {StatusBadges[selectedAdvance.status as keyof typeof StatusBadges].label}
                  </Badge>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Requested Date</Label>
                  <p className="text-sm">{formatDate(selectedAdvance.requestedAt)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Approval Status</Label>
                  <p className="text-sm">{getApprovalStatus(selectedAdvance)}</p>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">Reason</Label>
                <p className="text-sm mt-1 p-2 bg-gray-50 rounded">{selectedAdvance.reason}</p>
              </div>
              {selectedAdvance.rejectionReason && (
                <div>
                  <Label className="text-sm font-medium text-gray-500">Rejection Reason</Label>
                  <p className="text-sm mt-1 p-2 bg-red-50 rounded">{selectedAdvance.rejectionReason}</p>
                </div>
              )}
              {selectedAdvance.status === 'paid' && (
                <div className="border-t pt-4">
                  <h4 className="font-medium mb-2">Payment Details</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Paid Amount</Label>
                      <p className="text-sm">{formatCurrency(selectedAdvance.paidAmount || selectedAdvance.amount)}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Payment Method</Label>
                      <p className="text-sm">{selectedAdvance.paymentMethod}</p>
                    </div>
                    {selectedAdvance.paymentReference && (
                      <div>
                        <Label className="text-sm font-medium text-gray-500">Reference</Label>
                        <p className="text-sm">{selectedAdvance.paymentReference}</p>
                      </div>
                    )}
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Paid Date</Label>
                      <p className="text-sm">{selectedAdvance.paidAt ? formatDate(selectedAdvance.paidAt) : 'N/A'}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Approval Dialog */}
      <Dialog open={approvalDialogOpen} onOpenChange={setApprovalDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Advance Request</DialogTitle>
            <DialogDescription>
              Add comments and approve this advance request (Level {selectedAdvance ? getNextApprovalLevel(selectedAdvance) : 1})
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="comments">Comments (Optional)</Label>
              <Textarea
                id="comments"
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                placeholder="Add any comments for this approval..."
                className="mt-1"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setApprovalDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (selectedAdvance) {
                    approveMutation.mutate({
                      id: selectedAdvance.id,
                      level: getNextApprovalLevel(selectedAdvance),
                      comments
                    });
                  }
                }}
                disabled={approveMutation.isPending}
                className="bg-green-600 hover:bg-green-700"
              >
                {approveMutation.isPending ? "Approving..." : "Approve"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Rejection Dialog */}
      <Dialog open={rejectionDialogOpen} onOpenChange={setRejectionDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Advance Request</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this advance request
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="rejectionReason">Rejection Reason *</Label>
              <Textarea
                id="rejectionReason"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Explain why this advance request is being rejected..."
                className="mt-1"
                required
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setRejectionDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (selectedAdvance && rejectionReason.trim()) {
                    rejectMutation.mutate({
                      id: selectedAdvance.id,
                      reason: rejectionReason
                    });
                  }
                }}
                disabled={rejectMutation.isPending || !rejectionReason.trim()}
                variant="destructive"
              >
                {rejectMutation.isPending ? "Rejecting..." : "Reject"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Record Payment</DialogTitle>
            <DialogDescription>
              Record the payment details for this approved advance request
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="paymentAmount">Payment Amount *</Label>
              <Input
                id="paymentAmount"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                placeholder="Enter paid amount"
                type="number"
                className="mt-1"
                required
              />
            </div>
            <div>
              <Label htmlFor="paymentMethod">Payment Method *</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select payment method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                  <SelectItem value="online">Online Payment</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="paymentReference">Payment Reference (Optional)</Label>
              <Input
                id="paymentReference"
                value={paymentReference}
                onChange={(e) => setPaymentReference(e.target.value)}
                placeholder="Transaction ID, cheque number, etc."
                className="mt-1"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setPaymentDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (selectedAdvance && paymentAmount && paymentMethod) {
                    markPaidMutation.mutate({
                      id: selectedAdvance.id,
                      amount: paymentAmount,
                      method: paymentMethod,
                      reference: paymentReference
                    });
                  }
                }}
                disabled={markPaidMutation.isPending || !paymentAmount || !paymentMethod}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {markPaidMutation.isPending ? "Recording..." : "Record Payment"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}