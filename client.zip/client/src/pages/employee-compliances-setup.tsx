import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Settings, Save, User } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth';

const complianceSetupSchema = z.object({
  employeeId: z.string().min(1, 'Employee selection is required'),
  basicSalary: z.string().min(1, 'Basic salary is required'),
  grossSalary: z.string().min(1, 'Gross salary is required'),
  differenceAdjustment: z.boolean().default(false),
  pfType: z.enum(['exempt', 'actual', 'ctc']),
  esicType: z.enum(['exempt', 'actual', 'ctc']),
  bonusType: z.enum(['exempt', 'actual', 'ctc']),
});

type ComplianceSetupFormData = z.infer<typeof complianceSetupSchema>;

export default function EmployeeCompliancesSetup() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedEmployee, setSelectedEmployee] = useState<string>('');

  const { data: employees = [] } = useQuery({
    queryKey: ['/api/employees', user?.companyId],
    enabled: !!user?.companyId,
  });

  const { data: complianceSetups = [] } = useQuery({
    queryKey: ['/api/compliance-setups', user?.companyId],
    enabled: !!user?.companyId,
  });

  const form = useForm<ComplianceSetupFormData>({
    resolver: zodResolver(complianceSetupSchema),
    defaultValues: {
      employeeId: '',
      basicSalary: '',
      grossSalary: '',
      differenceAdjustment: false,
      pfType: 'actual',
      esicType: 'actual',
      bonusType: 'actual',
    },
  });

  const createComplianceSetupMutation = useMutation({
    mutationFn: async (data: ComplianceSetupFormData) => {
      const response = await apiRequest('POST', '/api/compliance-setups', {
        ...data,
        companyId: user?.companyId,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/compliance-setups'] });
      form.reset();
      toast({
        title: 'Success',
        description: 'Employee compliance setup saved successfully',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to save compliance setup',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: ComplianceSetupFormData) => {
    createComplianceSetupMutation.mutate(data);
  };

  return (
    <div className="space-y-6 p-6">

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Setup Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="w-5 h-5 mr-2 text-blue-600" />
              Compliance Configuration
            </CardTitle>
            <CardDescription>
              Set up compliance parameters for individual employees
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <Label htmlFor="employeeId">Select Employee</Label>
                <Select 
                  value={form.watch('employeeId')} 
                  onValueChange={(value) => form.setValue('employeeId', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((employee: any) => (
                      <SelectItem key={employee.id} value={employee.id.toString()}>
                        {employee.firstName} {employee.lastName} ({employee.employeeId})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.employeeId && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.employeeId.message}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="basicSalary">Basic Salary</Label>
                  <Input
                    id="basicSalary"
                    type="number"
                    {...form.register('basicSalary')}
                    placeholder="Enter basic salary"
                  />
                  {form.formState.errors.basicSalary && (
                    <p className="text-red-500 text-sm mt-1">
                      {form.formState.errors.basicSalary.message}
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="grossSalary">Gross Salary</Label>
                  <Input
                    id="grossSalary"
                    type="number"
                    {...form.register('grossSalary')}
                    placeholder="Enter gross salary"
                  />
                  {form.formState.errors.grossSalary && (
                    <p className="text-red-500 text-sm mt-1">
                      {form.formState.errors.grossSalary.message}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="differenceAdjustment"
                  checked={form.watch('differenceAdjustment')}
                  onCheckedChange={(checked) => 
                    form.setValue('differenceAdjustment', checked as boolean)
                  }
                />
                <Label htmlFor="differenceAdjustment">Difference Adjustment</Label>
              </div>

              <div className="space-y-4">
                <div>
                  <Label>PF Type</Label>
                  <Select 
                    value={form.watch('pfType')} 
                    onValueChange={(value: 'exempt' | 'actual' | 'ctc') => 
                      form.setValue('pfType', value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="exempt">Exempt</SelectItem>
                      <SelectItem value="actual">Actual</SelectItem>
                      <SelectItem value="ctc">CTC</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>ESIC Type</Label>
                  <Select 
                    value={form.watch('esicType')} 
                    onValueChange={(value: 'exempt' | 'actual' | 'ctc') => 
                      form.setValue('esicType', value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="exempt">Exempt</SelectItem>
                      <SelectItem value="actual">Actual</SelectItem>
                      <SelectItem value="ctc">CTC</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Bonus Type</Label>
                  <Select 
                    value={form.watch('bonusType')} 
                    onValueChange={(value: 'exempt' | 'actual' | 'ctc') => 
                      form.setValue('bonusType', value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="exempt">Exempt</SelectItem>
                      <SelectItem value="actual">Actual</SelectItem>
                      <SelectItem value="ctc">CTC</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={createComplianceSetupMutation.isPending}
              >
                <Save className="w-4 h-4 mr-2" />
                {createComplianceSetupMutation.isPending ? 'Saving...' : 'Save Setup'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Current Setups */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <User className="w-5 h-5 mr-2 text-green-600" />
              Current Compliance Setups
            </CardTitle>
            <CardDescription>
              View existing compliance configurations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {complianceSetups.length === 0 ? (
                <p className="text-gray-500 text-center py-8">
                  No compliance setups found. Create your first setup using the form.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>Basic</TableHead>
                      <TableHead>Gross</TableHead>
                      <TableHead>PF</TableHead>
                      <TableHead>ESIC</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {complianceSetups.map((setup: any) => (
                      <TableRow key={setup.id}>
                        <TableCell className="font-medium">
                          {setup.employee?.firstName} {setup.employee?.lastName}
                        </TableCell>
                        <TableCell>₹{setup.basicSalary}</TableCell>
                        <TableCell>₹{setup.grossSalary}</TableCell>
                        <TableCell className="capitalize">{setup.pfType}</TableCell>
                        <TableCell className="capitalize">{setup.esicType}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}