import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { authService, apiRequestWithAuth } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Download } from "lucide-react";
import { ArrowLeft, User, Briefcase, MapPin, CreditCard, Clock, Users } from "lucide-react";
import { type Employee, type Department } from "@shared/schema";
import SalaryStructureForm from "@/components/SalaryStructureForm";

interface EditEmployeePageProps {
  params: { id: string };
}

export default function EditEmployeePage({ params }: EditEmployeePageProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const employeeId = parseInt(params.id);
  
  const user = authService.getUser();
  const companyId = user?.companyId;
  
  // Month/Year selector state for salary structure
  const currentDate = new Date();
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);
  
  // PDF download state
  const [downloadingPDF, setDownloadingPDF] = useState(false);
  
  // All month names for reference
  const allMonthOptions = [
    { value: 1, label: 'January' },
    { value: 2, label: 'February' },
    { value: 3, label: 'March' },
    { value: 4, label: 'April' },
    { value: 5, label: 'May' },
    { value: 6, label: 'June' },
    { value: 7, label: 'July' },
    { value: 8, label: 'August' },
    { value: 9, label: 'September' },
    { value: 10, label: 'October' },
    { value: 11, label: 'November' },
    { value: 12, label: 'December' }
  ];
  
  // Fetch employee data with payroll
  const { data: employee, isLoading: employeeLoading } = useQuery<any>({
    queryKey: [`/api/employees/${companyId}/${employeeId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/employees/${companyId}/${employeeId}?_t=${Date.now()}`);
      return response.json();
    },
    enabled: !!companyId && !!employeeId,
    staleTime: 0, // Always consider data stale
    gcTime: 0, // Don't cache the data
  });

  // Generate year and month options based on employee's joining date
  const getPayrollPeriodOptions = () => {
    if (!employee?.hireDate) {
      // Fallback if no hire date available
      return {
        yearOptions: [currentDate.getFullYear()],
        monthOptions: allMonthOptions
      };
    }
    
    const hireDate = new Date(employee.hireDate);
    const hireYear = hireDate.getFullYear();
    const hireMonth = hireDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth() + 1;
    
    // Generate year options from hire year to current year
    const yearOptions = [];
    for (let year = hireYear; year <= currentYear; year++) {
      yearOptions.push(year);
    }
    
    // Generate month options based on selected year
    let monthOptions = [...allMonthOptions];
    
    if (selectedYear === hireYear && selectedYear === currentYear) {
      // Same year as hire and current: show from hire month to current month
      monthOptions = allMonthOptions.filter(m => m.value >= hireMonth && m.value <= currentMonth);
    } else if (selectedYear === hireYear) {
      // Hire year but not current: show from hire month to December
      monthOptions = allMonthOptions.filter(m => m.value >= hireMonth);
    } else if (selectedYear === currentYear) {
      // Current year but not hire: show from January to current month
      monthOptions = allMonthOptions.filter(m => m.value <= currentMonth);
    }
    // For other years (between hire and current), show all months
    
    return { yearOptions, monthOptions };
  };
  
  const { yearOptions, monthOptions } = getPayrollPeriodOptions();
  
  // Ensure selectedMonth is valid when year changes or employee data loads
  useEffect(() => {
    if (monthOptions.length > 0) {
      const validMonthValues = monthOptions.map(m => m.value);
      if (!validMonthValues.includes(selectedMonth)) {
        // Set to the closest valid month (first available or current month if available)
        const currentMonth = currentDate.getMonth() + 1;
        const preferredMonth = validMonthValues.includes(currentMonth) ? currentMonth : validMonthValues[0];
        setSelectedMonth(preferredMonth);
      }
    }
  }, [employee, selectedYear, monthOptions.length]);

  // Fetch salary structure for selected month/year
  const { data: salaryStructure, isLoading: salaryStructureLoading } = useQuery({
    queryKey: ['/api/employee-salary-structure', employeeId, selectedYear, selectedMonth],
    queryFn: async () => {
      try {
        const response = await apiRequestWithAuth('GET', `/api/employee-salary-structure/${employeeId}/${selectedYear}/${selectedMonth}`);
        if (response.ok) {
          return response.json();
        }
        return null; // No data for this month
      } catch (error) {
        return null; // No data for this month
      }
    },
    enabled: !!employeeId && !!selectedYear && !!selectedMonth,
    staleTime: 0,
    gcTime: 0,
  });

  // Fetch departments
  const { data: departments = [] } = useQuery<Department[]>({
    queryKey: [`/api/departments/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/departments/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    employeeId: '',
    position: '',
    departmentId: '',
    address: '',
    dateOfBirth: '',
    hireDate: '',
    salary: '',
    status: 'active' as 'active' | 'inactive' | 'probation' | 'terminated',
    emergencyContact: '',
    emergencyPhone: '',
    // Time Office Policy fields
    dutyTimingFrom: '',
    dutyTimingTo: '',
    lateArrivalAllowed: '',
    permissibleFlexibility: '',
    weeklyOff1: '',
    weeklyOff2: '',
    overtimeApplicable: false,
    // Payroll fields
    epfEnabled: false,
    employeePfLimit: false,
    employerPfLimit: false,
    esicEnabled: false,
    lwfEnabled: false,
    otEnabled: false,
    doubleOt: false,
    vpfEnabled: false,
    vpfAmount: '',
    tdsEnabled: false,
    tdsAmount: '',
    ptEnabled: false,
    ptAmount: '',
    bonusEnabled: false,
    bonusMonthlyPayment: false,
    entryType: 'gross' as 'ctc' | 'gross' | 'earning_heads',
    ctcValue: '',
    grossValue: '',
    earningHead1: '', // Basic Salary
    earningHead2: '', // HRA
    earningHead3: '', // Conveyance Allowance
    earningHead4: '', // Other Allowances
    epfEmployeeAmount: '',
    esicEmployeeAmount: '',
    lwfEmployeeAmount: ''
  });

  // Payroll calculation functions with corrected earning heads logic
  const calculateEarningHeads = (grossAmount: number) => {
    let basicSalary = 0;
    let hra = 0;
    let conveyanceAllowance = 0;
    let otherAllowances = 0;

    if (grossAmount < 15000) {
      // For salaries < ₹15,000: Basic = full gross salary
      basicSalary = grossAmount;
      hra = 0;
      conveyanceAllowance = 0;
      otherAllowances = 0;
    } else if (grossAmount < 22500) {
      // For salaries ₹15,000 to ₹22,500: Basic = ₹15,000, HRA = remainder
      basicSalary = 15000;
      hra = grossAmount - 15000;
      conveyanceAllowance = 0;
      otherAllowances = 0;
    } else if (grossAmount < 25000) {
      // For salaries ₹22,500 to ₹25,000: Basic = ₹15,000, HRA = ₹7,500, Conv = Gross-Basic-HRA
      basicSalary = 15000;              // Fixed ₹15,000
      hra = 7500;                       // Fixed ₹7,500
      conveyanceAllowance = grossAmount - basicSalary - hra;  // Remainder
      otherAllowances = 0;
    } else if (grossAmount <= 100000) {
      // For salaries ₹25,000 to ₹1,00,000: Basic = 60%, HRA = 30%, Conveyance = 10%, Other = 0%
      basicSalary = grossAmount * 0.6;  // 60%
      hra = grossAmount * 0.3;          // 30%
      conveyanceAllowance = grossAmount * 0.1;  // 10%
      otherAllowances = 0;              // Must be 0
    } else {
      // For salaries > ₹1,00,000: Basic = 60%, HRA = 30%, Conveyance = 6%, Other = 4%
      basicSalary = grossAmount * 0.6;  // 60%
      hra = grossAmount * 0.3;          // 30%
      conveyanceAllowance = grossAmount * 0.06; // 6%
      otherAllowances = grossAmount * 0.04;     // 4%
    }
    
    return {
      basicSalary: Math.round(basicSalary),
      hra: Math.round(hra),
      conveyanceAllowance: Math.round(conveyanceAllowance),
      otherAllowances: Math.round(otherAllowances)
    };
  };

  // Populate form when employee data loads or month/year changes
  useEffect(() => {
    if (employee) {
      console.log('Loading employee data:', employee);
      console.log('Employee payroll data:', employee.payroll);
      console.log('Salary structure data:', salaryStructure);
      
      // Prefer salary structure data for the selected month, fallback to current payroll data
      const payrollData = salaryStructure || employee.payroll;
      
      setFormData({
        firstName: employee.firstName || '',
        lastName: employee.lastName || '',
        email: employee.email || '',
        phone: employee.phone || '',
        employeeId: employee.employeeId || '',
        position: employee.position || '',
        departmentId: employee.departmentId?.toString() || '',
        address: employee.address || '',
        dateOfBirth: employee.dateOfBirth ? new Date(employee.dateOfBirth).toISOString().split('T')[0] : '',
        hireDate: employee.hireDate ? new Date(employee.hireDate).toISOString().split('T')[0] : '',
        salary: employee.salary || '',
        status: employee.status || 'active',
        emergencyContact: employee.emergencyContact || '',
        emergencyPhone: employee.emergencyPhone || '',
        // Time Office Policy fields (placeholder values for now)
        dutyTimingFrom: '09:00',
        dutyTimingTo: '18:00',
        lateArrivalAllowed: '15',
        permissibleFlexibility: '30',
        weeklyOff1: 'saturday',
        weeklyOff2: 'sunday',
        overtimeApplicable: false,
        // Payroll fields - load from salary structure (priority) or current payroll data (fallback)
        epfEnabled: payrollData?.epfEnabled ?? false,
        employeePfLimit: payrollData?.employeePfLimit ?? false,
        employerPfLimit: payrollData?.employerPfLimit ?? false,
        esicEnabled: payrollData?.esicEnabled ?? false,
        lwfEnabled: payrollData?.lwfEnabled ?? false,
        otEnabled: payrollData?.otEnabled ?? false,
        doubleOt: payrollData?.doubleOt ?? false,
        vpfEnabled: payrollData?.vpfEnabled ?? false,
        vpfAmount: payrollData?.vpfAmount?.toString() || '',
        tdsEnabled: payrollData?.tdsEnabled ?? false,
        tdsAmount: payrollData?.tdsAmount?.toString() || '',
        ptEnabled: payrollData?.ptEnabled ?? false,
        ptAmount: payrollData?.ptAmount?.toString() || '',
        bonusEnabled: payrollData?.bonusEnabled ?? false,
        bonusMonthlyPayment: payrollData?.bonusMonthlyPayment ?? false,
        entryType: (payrollData?.entryType as 'ctc' | 'gross' | 'earning_heads') || 'gross',
        ctcValue: payrollData?.ctcValue?.toString() || '',
        grossValue: payrollData?.grossValue?.toString() || employee.salary || '',
        earningHead1: payrollData?.earningHead1?.toString() || '',
        earningHead2: payrollData?.earningHead2?.toString() || '',
        earningHead3: payrollData?.earningHead3?.toString() || '',
        earningHead4: payrollData?.earningHead4?.toString() || '',
        epfEmployeeAmount: payrollData?.epfEmployeeAmount?.toString() || '',
        esicEmployeeAmount: payrollData?.esicEmployeeAmount?.toString() || '',
        lwfEmployeeAmount: payrollData?.lwfEmployeeAmount?.toString() || ''
      });
      
      console.log('Form data set with payroll values:', {
        epfEnabled: employee.payroll?.epfEnabled,
        esicEnabled: employee.payroll?.esicEnabled,
        lwfEnabled: employee.payroll?.lwfEnabled,
        bonusEnabled: employee.payroll?.bonusEnabled
      });
      
      // Recalculate CTC when form loads with existing data
      if (payrollData?.entryType === 'gross' || employee.salary) {
        const grossAmount = parseFloat(payrollData?.grossValue || employee.salary || '0');
        if (grossAmount > 0) {
          const calculatedCTC = calculateCTC(grossAmount);
          console.log('Recalculated CTC on form load:', {
            gross: grossAmount,
            calculatedCTC: calculatedCTC,
            epfEnabled: payrollData?.epfEnabled,
            employerPfLimit: payrollData?.employerPfLimit,
            esicEnabled: payrollData?.esicEnabled,
            originalCTC: payrollData?.ctcValue
          });
          
          // Update form data with correct CTC
          setTimeout(() => {
            setFormData(prev => ({
              ...prev,
              ctcValue: calculatedCTC.toFixed(2)
            }));
          }, 200);
        }
      }
      
      // Only auto-calculate earning heads if none are saved in the database
      const earningHeads = [
        payrollData?.earningHead1,
        payrollData?.earningHead2,
        payrollData?.earningHead3,
        payrollData?.earningHead4
      ];
      const hasSavedEarningHeads = earningHeads.some(v => v !== undefined && v !== null && v !== '');
      
      if (!hasSavedEarningHeads) {
        setTimeout(() => {
          const grossAmount = parseFloat(payrollData?.grossValue || employee.salary || '0');
          if (grossAmount > 0) {
            const earningHeads = calculateEarningHeads(grossAmount);
            setFormData(prev => ({
              ...prev,
              earningHead1: earningHeads.basicSalary.toString(),
              earningHead2: earningHeads.hra.toString(),
              earningHead3: earningHeads.conveyanceAllowance.toString(),
              earningHead4: earningHeads.otherAllowances.toString()
            }));
          }
        }, 100);
      }
    }
  }, [employee, salaryStructure, selectedYear, selectedMonth]);

  // Auto-recalculate CTC when relevant fields change
  useEffect(() => {
    if (formData.entryType === 'gross' && formData.grossValue) {
      const grossAmount = parseFloat(formData.grossValue);
      if (grossAmount > 0) {
        const calculatedCTC = calculateCTC(grossAmount);
        const newCtcValue = calculatedCTC.toFixed(2);
        
        if (newCtcValue !== formData.ctcValue) {
          console.log('Auto-recalculating CTC:', {
            gross: grossAmount,
            oldCTC: formData.ctcValue,
            newCTC: newCtcValue,
            epfEnabled: formData.epfEnabled,
            employerPfLimit: formData.employerPfLimit,
            esicEnabled: formData.esicEnabled,
            lwfEnabled: formData.lwfEnabled
          });
          
          setFormData(prev => ({
            ...prev,
            ctcValue: newCtcValue
          }));
        }
      }
    }
  }, [
    formData.grossValue,
    formData.entryType,
    formData.epfEnabled,
    formData.employerPfLimit,
    formData.esicEnabled,
    formData.lwfEnabled,
    formData.bonusEnabled,
    formData.bonusMonthlyPayment,
    formData.earningHead1 // Basic salary affects PF calculation
  ]);

  const updateEmployeeMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const updateData = {
        ...data,
        departmentId: data.departmentId ? parseInt(data.departmentId) : null,
        dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth).toISOString() : null,
        hireDate: data.hireDate ? new Date(data.hireDate).toISOString() : null,
      };
      
      const response = await apiRequestWithAuth('PUT', `/api/employees/${employeeId}`, updateData);
      return response.json();
    },
    onSuccess: (data, variables) => {
      // Immediately update form state with the submitted values
      setFormData(prev => ({
        ...prev,
        earningHead1: variables.earningHead1,
        earningHead2: variables.earningHead2,
        earningHead3: variables.earningHead3,
        earningHead4: variables.earningHead4,
        grossValue: variables.grossValue,
        ctcValue: variables.ctcValue
      }));
      
      // Clear all cache and force fresh data
      queryClient.clear();
      
      // Refetch with cache busting
      setTimeout(() => {
        queryClient.refetchQueries({ queryKey: [`/api/employees/${companyId}/${employeeId}`] });
      }, 100);
      
      toast({
        title: "Success",
        description: "Employee updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update employee",
        variant: "destructive",
      });
    },
  });
  
  // Comprehensive cascading salary structure save mutation 
  const saveSalaryStructureMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const structureData = {
        // Payroll toggles
        epfEnabled: data.epfEnabled,
        employeePfLimit: data.employeePfLimit,
        employerPfLimit: data.employerPfLimit,
        esicEnabled: data.esicEnabled,
        lwfEnabled: data.lwfEnabled,
        otEnabled: data.otEnabled,
        doubleOt: data.doubleOt,
        vpfEnabled: data.vpfEnabled,
        vpfAmount: data.vpfAmount,
        tdsEnabled: data.tdsEnabled,
        tdsAmount: data.tdsAmount,
        ptEnabled: data.ptEnabled,
        ptAmount: data.ptAmount,
        bonusEnabled: data.bonusEnabled,
        bonusMonthlyPayment: data.bonusMonthlyPayment,
        // Salary structure
        entryType: data.entryType,
        ctcValue: data.ctcValue,
        grossValue: data.grossValue,
        earningHead1: data.earningHead1,
        earningHead2: data.earningHead2,
        earningHead3: data.earningHead3,
        earningHead4: data.earningHead4,
        epfEmployeeAmount: data.epfEmployeeAmount,
        esicEmployeeAmount: data.esicEmployeeAmount,
        lwfEmployeeAmount: data.lwfEmployeeAmount
      };
      
      // First save the current month
      const response = await apiRequestWithAuth('PUT', `/api/employee-salary-structure/${employeeId}/${selectedYear}/${selectedMonth}`, structureData);
      const result = await response.json();
      
      // Then cascade to all future months
      try {
        const cascadeResponse = await apiRequestWithAuth('POST', `/api/employee-salary-structure/${employeeId}/${selectedYear}/${selectedMonth}/cascade`, structureData);
        const cascadeResult = await cascadeResponse.json();
        
        return {
          ...result,
          cascadeInfo: cascadeResult
        };
      } catch (cascadeError) {
        console.warn('Cascade update failed:', cascadeError);
        // Return the main result even if cascade fails
        return {
          ...result,
          cascadeInfo: null,
          cascadeError: cascadeError.message
        };
      }
    },
    onSuccess: (data) => {
      // Invalidate all salary structure caches since we updated multiple months
      queryClient.invalidateQueries({ queryKey: ['/api/employee-salary-structure'] });
      
      const monthName = allMonthOptions.find(m => m.value === selectedMonth)?.label;
      let description = `Salary structure saved for ${monthName} ${selectedYear}`;
      
      if (data.cascadeInfo?.updatedMonths?.length > 0) {
        description += ` and cascaded to ${data.cascadeInfo.updatedMonths.length} future months`;
      } else if (data.cascadeError) {
        description += ` (cascade to future months failed)`;
      }
      
      toast({
        title: "Success",
        description,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save salary structure",
        variant: "destructive",
      });
    },
  });
  
  // Handle PDF download
  const handleDownloadSalaryHistory = async () => {
    if (!employeeId) return;
    
    setDownloadingPDF(true);
    
    try {
      // Get the JWT token for authentication
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('Not authenticated');
      }
      
      // Use direct fetch for binary PDF data (don't use apiRequestWithAuth which expects JSON)
      const response = await fetch(`/api/employee-salary-structure/${employeeId}/pdf?limit=12`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to generate PDF');
      }
      
      // Get the PDF blob
      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      
      // Set filename from Content-Disposition header or use default
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = 'salary_history.pdf';
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="(.+)"/);
        if (filenameMatch) {
          filename = filenameMatch[1];
        }
      }
      
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      
      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Success",
        description: "Salary history PDF downloaded successfully",
      });
      
    } catch (error: any) {
      console.error('Error downloading PDF:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to download salary history PDF",
        variant: "destructive",
      });
    } finally {
      setDownloadingPDF(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Always recalculate earning heads based on current gross value before submitting
    const grossAmount = parseFloat(formData.grossValue || '0');
    let submissionData = { ...formData };
    
    if (grossAmount > 0) {
      const calculatedEarnings = calculateEarningHeads(grossAmount);
      submissionData = {
        ...formData,
        earningHead1: calculatedEarnings.basicSalary.toString(),
        earningHead2: calculatedEarnings.hra.toString(),
        earningHead3: calculatedEarnings.conveyanceAllowance.toString(),
        earningHead4: calculatedEarnings.otherAllowances.toString()
      };
    }
    
    // Only update global employee payroll if editing current month, otherwise only save month-specific structure
    const isCurrentMonth = selectedYear === currentDate.getFullYear() && selectedMonth === (currentDate.getMonth() + 1);
    
    if (isCurrentMonth) {
      // Save to both global payroll and month-specific structure for current month
      updateEmployeeMutation.mutate(submissionData);
      saveSalaryStructureMutation.mutate(submissionData);
      
      // Auto-update future months with the same structure
      autoUpdateFutureMonthsMutation.mutate(submissionData);
    } else {
      // Only save to month-specific structure for historical/future months
      saveSalaryStructureMutation.mutate(submissionData);
    }
  };

  const handleInputChange = (field: keyof typeof formData, value: string | boolean) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Auto-calculate employee amounts when components are enabled
      if (field === 'epfEnabled') {
        if (value === true) {
          // Calculate PF base: All earning heads except HRA
          const pfBase = (parseFloat(newData.earningHead1 || '0') + 
                          parseFloat(newData.earningHead3 || '0') + 
                          parseFloat(newData.earningHead4 || '0'));
          let epfAmount = pfBase * 0.12; // 12% of PF Base (excluding HRA)
          
          // Apply Employee PF Limit: Maximum deduction of 1800 when enabled
          if (newData.employeePfLimit && epfAmount > 1800) {
            epfAmount = 1800;
          }
          
          newData.epfEmployeeAmount = epfAmount.toFixed(2);
        } else {
          // Clear EPF amount when EPF is disabled
          newData.epfEmployeeAmount = '0.00';
        }
      } else if (field === 'esicEnabled') {
        if (value === true) {
          const grossAmount = parseFloat(newData.grossValue || '0');
          
          // Apply ESIC Ceiling: Zero ESIC when gross > 21000
          let esicAmount = 0;
          if (grossAmount <= 21000) {
            esicAmount = grossAmount * 0.0075; // 0.75% of Gross
          }
          
          newData.esicEmployeeAmount = esicAmount.toFixed(2);
        } else {
          // Clear ESIC amount when ESIC is disabled
          newData.esicEmployeeAmount = '0.00';
        }
      } else if (field === 'lwfEnabled') {
        if (value === true) {
          newData.lwfEmployeeAmount = '10.00'; // Fixed amount for employee
        } else {
          // Clear LWF amount when LWF is disabled
          newData.lwfEmployeeAmount = '0.00';
        }
      } else if (field === 'employeePfLimit') {
        // Recalculate EPF amount when PF limit toggle changes
        if (newData.epfEnabled) {
          // Calculate PF base: All earning heads except HRA
          const pfBase = (parseFloat(newData.earningHead1 || '0') + 
                          parseFloat(newData.earningHead3 || '0') + 
                          parseFloat(newData.earningHead4 || '0'));
          let epfAmount = pfBase * 0.12; // 12% of PF Base (excluding HRA)
          
          // Apply Employee PF Limit: Maximum deduction of 1800 when enabled
          if (value === true && epfAmount > 1800) {
            epfAmount = 1800;
          }
          
          newData.epfEmployeeAmount = epfAmount.toFixed(2);
        }
      }
      
      // Recalculate employee amounts when earning heads change (any earning head affects PF except HRA)
      if ((field === 'earningHead1' || field === 'earningHead3' || field === 'earningHead4') && newData.epfEnabled) {
        // Calculate PF base: All earning heads except HRA (earningHead2)
        const pfBase = (parseFloat(newData.earningHead1 || '0') + 
                        parseFloat(newData.earningHead3 || '0') + 
                        parseFloat(newData.earningHead4 || '0'));
        let epfAmount = pfBase * 0.12; // 12% of PF Base (excluding HRA)
        
        // Apply Employee PF Limit: Maximum deduction of 1800 when enabled
        if (newData.employeePfLimit && epfAmount > 1800) {
          epfAmount = 1800;
        }
        
        newData.epfEmployeeAmount = epfAmount.toFixed(2);
      }
      
      if ((field === 'grossValue' || field.startsWith('earningHead')) && newData.esicEnabled) {
        const grossAmount = field === 'grossValue' ? parseFloat(value as string || '0') : parseFloat(newData.grossValue || '0');
        
        // Apply ESIC Ceiling: Zero ESIC when gross > 21000
        let esicAmount = 0;
        if (grossAmount <= 21000) {
          esicAmount = grossAmount * 0.0075; // 0.75% of Gross
        }
        
        newData.esicEmployeeAmount = esicAmount.toFixed(2);
      }
      
      return newData;
    });
  };

  const calculateGross = () => {
    const earning1 = parseFloat(formData.earningHead1) || 0;
    const earning2 = parseFloat(formData.earningHead2) || 0;
    const earning3 = parseFloat(formData.earningHead3) || 0;
    const earning4 = parseFloat(formData.earningHead4) || 0;
    return earning1 + earning2 + earning3 + earning4;
  };

  // Calculate PF base: All earning heads except HRA (earningHead2)
  const calculatePFBase = () => {
    const earning1 = parseFloat(formData.earningHead1) || 0; // Basic Salary
    const earning3 = parseFloat(formData.earningHead3) || 0; // Other allowances
    const earning4 = parseFloat(formData.earningHead4) || 0; // Other allowances
    // Note: earningHead2 (HRA) is excluded from PF calculation
    return earning1 + earning3 + earning4;
  };

  const calculateCTC = (grossAmount: number) => {
    // Get PF base for PF calculations - all earning heads except HRA
    const pfBase = calculatePFBase();
    
    // CTC = Gross + Employer Contributions
    let employerPF = formData.epfEnabled ? pfBase * 0.12 : 0; // 12% of PF Base (excluding HRA)
    let adminCharges = formData.epfEnabled ? pfBase * 0.01 : 0; // 1% of PF Base (excluding HRA)
    
    // Apply Employer PF Limit: Maximum contribution of 1800 + fixed admin charges of 150 when enabled
    if (formData.employerPfLimit && formData.epfEnabled) {
      if (employerPF > 1800) {
        employerPF = 1800;
      }
      adminCharges = 150; // Fixed amount when limit is enabled
    }
    
    // Apply ESIC Ceiling: Zero ESIC when gross > 21000
    let employerESIC = 0;
    if (formData.esicEnabled && grossAmount <= 21000) {
      employerESIC = grossAmount * 0.0325; // 3.25% of Gross
    }
    
    const employerLWF = formData.lwfEnabled ? 20 : 0; // Fixed amount
    const bonus = formData.bonusEnabled ? grossAmount * 0.0833 : 0; // 8.33% of Gross (always include when enabled)
    
    return grossAmount + employerPF + adminCharges + employerESIC + employerLWF + bonus;
  };

  const calculateGrossFromCTC = (ctcAmount: number) => {
    // Reverse calculation approximation
    const estimatedMultiplier = 1.25; // Approximate multiplier
    return ctcAmount / estimatedMultiplier;
  };

  // Handle entry type changes and auto-calculations
  const handleEntryTypeChange = (entryType: string) => {
    setFormData(prev => {
      const newData = { ...prev, entryType: entryType as 'ctc' | 'gross' | 'earning_heads' };
      
      if (entryType === 'ctc' && prev.ctcValue) {
        const grossCalculated = calculateGrossFromCTC(parseFloat(prev.ctcValue));
        newData.grossValue = grossCalculated.toFixed(2);
      } else if (entryType === 'gross' && prev.grossValue) {
        const ctcCalculated = calculateCTC(parseFloat(prev.grossValue));
        newData.ctcValue = ctcCalculated.toFixed(2);
      } else if (entryType === 'earning_heads') {
        // Auto-calculate earning heads when switching to this mode
        if (prev.grossValue) {
          const grossAmount = parseFloat(prev.grossValue);
          const earningHeads = calculateEarningHeads(grossAmount);
          newData.earningHead1 = earningHeads.basicSalary.toString();
          newData.earningHead2 = earningHeads.hra.toString();
          newData.earningHead3 = earningHeads.conveyanceAllowance.toString();
          newData.earningHead4 = earningHeads.otherAllowances.toString();
        }
        const grossCalculated = calculateGross();
        const ctcCalculated = calculateCTC(grossCalculated);
        newData.grossValue = grossCalculated.toFixed(2);
        newData.ctcValue = ctcCalculated.toFixed(2);
      }
      
      return newData;
    });
  };

  const handleSalaryValueChange = (field: string, value: string) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      if (field === 'ctcValue' && prev.entryType === 'ctc') {
        const grossCalculated = calculateGrossFromCTC(parseFloat(value) || 0);
        newData.grossValue = grossCalculated.toFixed(2);
      } else if (field === 'grossValue' && prev.entryType === 'gross') {
        const ctcCalculated = calculateCTC(parseFloat(value) || 0);
        newData.ctcValue = ctcCalculated.toFixed(2);
      } else if (field.startsWith('earningHead')) {
        // Allow direct earning head updates regardless of entry type
        // Only recalculate gross/CTC when entry type is earning_heads
        if (prev.entryType === 'earning_heads') {
          setTimeout(() => {
            const grossCalculated = calculateGross();
            const ctcCalculated = calculateCTC(grossCalculated);
            setFormData(current => ({
              ...current,
              grossValue: grossCalculated.toFixed(2),
              ctcValue: ctcCalculated.toFixed(2)
            }));
          }, 0);
        }
      }
      
      return newData;
    });
  };

  if (employeeLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Employee Not Found</h2>
          <p className="text-gray-600 mb-4">The employee you're looking for doesn't exist.</p>
          <Button onClick={() => setLocation('/admin/employees')}>
            Back to Employees
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLocation('/admin/employees')}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Employees
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Edit Employee</h1>
          <p className="text-muted-foreground">Update employee information</p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="personal" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Personal
            </TabsTrigger>
            <TabsTrigger value="employment" className="flex items-center gap-2">
              <Briefcase className="h-4 w-4" />
              Employment
            </TabsTrigger>
            <TabsTrigger value="contact" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Contact
            </TabsTrigger>
            <TabsTrigger value="payroll" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Payroll
            </TabsTrigger>
            <TabsTrigger value="time" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Time Office
            </TabsTrigger>
            <TabsTrigger value="emergency" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Emergency
            </TabsTrigger>
          </TabsList>

          {/* Personal Information */}
          <TabsContent value="personal">
            <Card>
              <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
                <CardTitle className="text-blue-700 dark:text-blue-300">Personal Information</CardTitle>
                <CardDescription>Basic employee details and identification</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange('firstName', e.target.value)}
                      placeholder="Enter first name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange('lastName', e.target.value)}
                      placeholder="Enter last name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="employeeId">Employee ID *</Label>
                    <Input
                      id="employeeId"
                      value={formData.employeeId}
                      onChange={(e) => handleInputChange('employeeId', e.target.value)}
                      placeholder="Enter employee ID"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="Enter email address"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="Enter phone number"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Date of Birth</Label>
                    <Input
                      id="dateOfBirth"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Employment Information */}
          <TabsContent value="employment">
            <Card>
              <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950">
                <CardTitle className="text-green-700 dark:text-green-300">Employment Information</CardTitle>
                <CardDescription>Job role and department details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="position">Position</Label>
                    <Input
                      id="position"
                      value={formData.position}
                      onChange={(e) => handleInputChange('position', e.target.value)}
                      placeholder="Enter position/designation"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="departmentId">Department</Label>
                    <Select
                      value={formData.departmentId}
                      onValueChange={(value) => handleInputChange('departmentId', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((dept) => (
                          <SelectItem key={dept.id} value={dept.id.toString()}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hireDate">Hire Date</Label>
                    <Input
                      id="hireDate"
                      type="date"
                      value={formData.hireDate}
                      onChange={(e) => handleInputChange('hireDate', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => handleInputChange('status', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                        <SelectItem value="probation">Probation</SelectItem>
                        <SelectItem value="terminated">Terminated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Contact Information */}
          <TabsContent value="contact">
            <Card>
              <CardHeader className="bg-gradient-to-r from-purple-50 to-violet-50 dark:from-purple-950 dark:to-violet-950">
                <CardTitle className="text-purple-700 dark:text-purple-300">Contact Information</CardTitle>
                <CardDescription>Address and location details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Textarea
                    id="address"
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    placeholder="Enter complete address"
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payroll Information */}
          <TabsContent value="payroll">
            <div className="space-y-6">
              {/* Month/Year Selector for Historical Salary Structure */}
              <Card>
                <CardHeader className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950 dark:to-orange-950">
                  <CardTitle className="text-yellow-700 dark:text-yellow-300">Payroll Information</CardTitle>
                  <CardDescription>Complete payroll setup with automatic calculations</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-300">Salary Structure Period</h3>
                    {salaryStructureLoading && (
                      <div className="text-sm text-gray-500">Loading...</div>
                    )}
                    {salaryStructure && (
                      <div className="text-sm text-green-600 font-medium">✓ Data found for this period</div>
                    )}
                    {!salaryStructureLoading && !salaryStructure && (selectedYear !== currentDate.getFullYear() || selectedMonth !== (currentDate.getMonth() + 1)) && (
                      <div className="text-sm text-gray-500">No data for this period - will use current payroll as template</div>
                    )}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="salary-year">Year</Label>
                      <Select
                        value={selectedYear.toString()}
                        onValueChange={(value) => setSelectedYear(parseInt(value))}
                      >
                        <SelectTrigger id="salary-year" data-testid="select-year">
                          <SelectValue placeholder="Select year" />
                        </SelectTrigger>
                        <SelectContent>
                          {yearOptions.map(year => (
                            <SelectItem key={year} value={year.toString()}>
                              {year}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="salary-month">Month</Label>
                      <Select
                        value={selectedMonth.toString()}
                        onValueChange={(value) => setSelectedMonth(parseInt(value))}
                      >
                        <SelectTrigger id="salary-month" data-testid="select-month">
                          <SelectValue placeholder="Select month" />
                        </SelectTrigger>
                        <SelectContent>
                          {monthOptions.map(month => (
                            <SelectItem key={month.value} value={month.value.toString()}>
                              {month.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  {/* PDF Download Button */}
                  <div className="mt-4 pt-4 border-t">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleDownloadSalaryHistory}
                      disabled={downloadingPDF}
                      className="flex items-center gap-2"
                    >
                      {downloadingPDF ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                          Generating PDF...
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4" />
                          Download Salary History PDF
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Modern Salary Structure Form */}
              <SalaryStructureForm
                companyId={companyId!}
                employeeId={employeeId}
                initialData={salaryStructure || employee?.payroll}
                onSave={(salaryData) => {
                  // Update form data with new salary structure
                  setFormData(prev => ({
                    ...prev,
                    ...salaryData
                  }));
                  
                  // Save salary structure for the selected month
                  const isCurrentMonth = selectedYear === currentDate.getFullYear() && selectedMonth === (currentDate.getMonth() + 1);
                  
                  if (isCurrentMonth) {
                    // Save to both global payroll and month-specific structure for current month
                    updateEmployeeMutation.mutate({ ...formData, ...salaryData });
                    saveSalaryStructureMutation.mutate(salaryData);
                    
                    // Auto-update future months with the same structure
                    autoUpdateFutureMonthsMutation.mutate(salaryData);
                  } else {
                    // Only save to month-specific structure for historical/future months
                    saveSalaryStructureMutation.mutate(salaryData);
                  }
                }}
              />
            </div>
          </TabsContent>

          {/* Time Office Policy */}
          <TabsContent value="time">
            <Card>
              <CardHeader className="bg-gradient-to-r from-teal-50 to-cyan-50 dark:from-teal-950 dark:to-cyan-950">
                <CardTitle className="text-teal-700 dark:text-teal-300">Time Office Policy</CardTitle>
                <CardDescription>Working hours and attendance policies</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="dutyTimingFrom">Duty Timing From</Label>
                    <Input
                      id="dutyTimingFrom"
                      type="time"
                      value={formData.dutyTimingFrom}
                      onChange={(e) => handleInputChange('dutyTimingFrom', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dutyTimingTo">Duty Timing To</Label>
                    <Input
                      id="dutyTimingTo"
                      type="time"
                      value={formData.dutyTimingTo}
                      onChange={(e) => handleInputChange('dutyTimingTo', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lateArrivalAllowed">Late Arrival Allowed (minutes)</Label>
                    <Input
                      id="lateArrivalAllowed"
                      type="number"
                      value={formData.lateArrivalAllowed}
                      onChange={(e) => handleInputChange('lateArrivalAllowed', e.target.value)}
                      placeholder="Minutes"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="earlyDepartureAllowed">Early Departure Allowed (minutes)</Label>
                    <Input
                      id="earlyDepartureAllowed"
                      type="number"
                      value={formData.earlyDepartureAllowed}
                      onChange={(e) => handleInputChange('earlyDepartureAllowed', e.target.value)}
                      placeholder="Minutes"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </form>
    </div>
  );
}
