import { useQuery } from "@tanstack/react-query";
import { authService, apiRequestWithAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, User, Briefcase, MapPin, CreditCard, Clock, Users, Edit, Phone, Mail } from "lucide-react";
import { type Employee, type Department } from "@shared/schema";

interface ViewEmployeePageProps {
  params: { id: string };
}

export default function ViewEmployeePage({ params }: ViewEmployeePageProps) {
  const [, setLocation] = useLocation();
  const employeeId = parseInt(params.id);
  
  const user = authService.getUser();
  const companyId = user?.companyId;

  // Fetch employee data
  const { data: employee, isLoading: employeeLoading } = useQuery<Employee>({
    queryKey: [`/api/employees/${companyId}/${employeeId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/employees/${companyId}/${employeeId}`);
      return response.json();
    },
    enabled: !!companyId && !!employeeId,
  });

  // Fetch departments
  const { data: departments = [] } = useQuery<Department[]>({
    queryKey: [`/api/departments/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/departments/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  const getDepartmentName = (departmentId: number | null) => {
    if (!departmentId) return 'Not assigned';
    const department = departments.find(d => d.id === departmentId);
    return department?.name || 'Unknown Department';
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { label: 'Active', className: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' },
      inactive: { label: 'Inactive', className: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200' },
      probation: { label: 'Probation', className: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' },
      terminated: { label: 'Terminated', className: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.inactive;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'Not specified';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (employeeLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Employee Not Found</h2>
          <p className="text-gray-600 mb-4">The employee you're looking for doesn't exist.</p>
          <Button onClick={() => setLocation('/admin/employees')}>
            Back to Employees
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/admin/employees')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Employees
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              {employee.firstName} {employee.lastName}
            </h1>
            <div className="flex items-center gap-3 mt-1">
              <p className="text-muted-foreground">Employee ID: {employee.employeeId}</p>
              {getStatusBadge(employee.status)}
            </div>
          </div>
        </div>
        <Button
          onClick={() => setLocation(`/admin/employees/${employeeId}/edit`)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
        >
          <Edit className="h-4 w-4" />
          Edit Employee
        </Button>
      </div>

      {/* Employee Details */}
      <Tabs defaultValue="personal" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="personal" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Personal
          </TabsTrigger>
          <TabsTrigger value="employment" className="flex items-center gap-2">
            <Briefcase className="h-4 w-4" />
            Employment
          </TabsTrigger>
          <TabsTrigger value="contact" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Contact
          </TabsTrigger>
          <TabsTrigger value="payroll" className="flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            Payroll
          </TabsTrigger>
          <TabsTrigger value="time" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Time Office
          </TabsTrigger>
          <TabsTrigger value="emergency" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Emergency
          </TabsTrigger>
        </TabsList>

        {/* Personal Information */}
        <TabsContent value="personal">
          <Card>
            <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
              <CardTitle className="text-blue-700 dark:text-blue-300">Personal Information</CardTitle>
              <CardDescription>Basic employee details and identification</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">First Name</h4>
                  <p className="text-lg font-medium">{employee.firstName}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Last Name</h4>
                  <p className="text-lg font-medium">{employee.lastName}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Employee ID</h4>
                  <p className="text-lg font-medium">{employee.employeeId}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Email</h4>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-gray-400" />
                    <p className="text-lg">{employee.email}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Phone</h4>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <p className="text-lg">{employee.phone || 'Not provided'}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Date of Birth</h4>
                  <p className="text-lg">{formatDate(employee.dateOfBirth)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Employment Information */}
        <TabsContent value="employment">
          <Card>
            <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950">
              <CardTitle className="text-green-700 dark:text-green-300">Employment Information</CardTitle>
              <CardDescription>Job role and department details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Position</h4>
                  <p className="text-lg font-medium">{employee.position || 'Not specified'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Department</h4>
                  <p className="text-lg">{getDepartmentName(employee.departmentId)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Status</h4>
                  <div>{getStatusBadge(employee.status)}</div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Hire Date</h4>
                  <p className="text-lg">{formatDate(employee.hireDate)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Manager</h4>
                  <p className="text-lg">{employee.managerId ? 'Assigned' : 'Not assigned'}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contact Information */}
        <TabsContent value="contact">
          <Card>
            <CardHeader className="bg-gradient-to-r from-purple-50 to-violet-50 dark:from-purple-950 dark:to-violet-950">
              <CardTitle className="text-purple-700 dark:text-purple-300">Contact Information</CardTitle>
              <CardDescription>Address and location details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Address</h4>
                <p className="text-lg whitespace-pre-line">{employee.address || 'Not provided'}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payroll Information */}
        <TabsContent value="payroll">
          <Card>
            <CardHeader className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950 dark:to-orange-950">
              <CardTitle className="text-yellow-700 dark:text-yellow-300">Payroll Information</CardTitle>
              <CardDescription>Salary and compensation details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Salary</h4>
                  <p className="text-lg font-medium">
                    {employee.salary ? `$${parseFloat(employee.salary).toLocaleString()}` : 'Not specified'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Time Office Policy */}
        <TabsContent value="time">
          <Card>
            <CardHeader className="bg-gradient-to-r from-teal-50 to-cyan-50 dark:from-teal-950 dark:to-cyan-950">
              <CardTitle className="text-teal-700 dark:text-teal-300">Time Office Policy</CardTitle>
              <CardDescription>Working hours and attendance policies</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Duty Timing</h4>
                  <p className="text-lg font-medium">09:00 AM - 06:00 PM</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Late Arrival Allowed</h4>
                  <p className="text-lg">15 minutes</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Permissible Flexibility</h4>
                  <p className="text-lg">30 minutes</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Weekly Offs</h4>
                  <p className="text-lg">Saturday, Sunday</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Overtime</h4>
                  <p className="text-lg">Not Applicable</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Emergency Contact */}
        <TabsContent value="emergency">
          <Card>
            <CardHeader className="bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-950 dark:to-pink-950">
              <CardTitle className="text-red-700 dark:text-red-300">Emergency Contact</CardTitle>
              <CardDescription>Emergency contact information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Emergency Contact Name</h4>
                  <p className="text-lg">{employee.emergencyContact || 'Not provided'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Emergency Contact Phone</h4>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <p className="text-lg">{employee.emergencyPhone || 'Not provided'}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}