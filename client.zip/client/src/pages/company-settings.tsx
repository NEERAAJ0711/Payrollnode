import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { authService, apiRequestWithAuth, usePermission } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  Building2, 
  Users, 
  MapPin, 
  Clock, 
  DollarSign, 
  Fingerprint, 
  Calendar, 
  FileText,
  Plus,
  Edit,
  Trash2,
  MoreVertical
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

interface Department {
  id: number;
  name: string;
  description: string;
  headOfDepartment: string;
  createdAt: Date;
}

interface Designation {
  id: number;
  title: string;
  departmentId: number;
  level: string;
  description: string;
}

interface Branch {
  id: number;
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  manager: string;
}

interface Location {
  id: number;
  name: string;
  address: string;
  branchId: number;
  capacity: number;
}

interface CostCenter {
  id: number;
  code: string;
  name: string;
  description: string;
  budget: string;
  manager: string;
}

interface BiometricMachine {
  id: number;
  serialNumber: string;
  ipAddress: string;
  port: number;
  location: string;
  model: string;
  status: 'active' | 'inactive' | 'maintenance';
  lastSync: Date;
}

interface Holiday {
  id: number;
  name: string;
  date: Date;
  type: 'national' | 'regional' | 'company';
  description: string;
  mandatory: boolean;
}

interface LeavePolicy {
  id: number;
  name: string;
  type: 'annual' | 'sick' | 'maternity' | 'paternity' | 'personal' | 'emergency';
  allowedDays: number;
  carryForward: boolean;
  description: string;
}

export default function CompanySettings() {
  const { toast } = useToast();
  const user = authService.getUser();
  const companyId = user?.companyId;
  
  // State for active tab and dialogs
  const [activeTab, setActiveTab] = useState("departments");
  const [showDialog, setShowDialog] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const [selectedItem, setSelectedItem] = useState<any>(null);

  // Form states
  const [formData, setFormData] = useState<any>({});

  // Permission check for company settings access
  const { hasPermission: canAccessSettings, loading: permissionLoading } = usePermission('company_settings');

  // Fetch company data
  const { data: company } = useQuery({
    queryKey: [`/api/companies/${companyId}`],
    enabled: !!companyId,
  });

  // Fetch departments
  const { data: departments = [] } = useQuery<Department[]>({
    queryKey: [`/api/departments/${companyId}`],
    enabled: !!companyId,
  });

  // Fetch all company settings data
  const { data: designations = [] } = useQuery<Designation[]>({
    queryKey: [`/api/designations/${companyId}`],
    enabled: !!companyId,
  });

  const { data: branches = [] } = useQuery<Branch[]>({
    queryKey: [`/api/branches/${companyId}`],
    enabled: !!companyId,
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/locations/${companyId}`],
    enabled: !!companyId,
  });

  const { data: costCenters = [] } = useQuery<CostCenter[]>({
    queryKey: [`/api/cost-centers/${companyId}`],
    enabled: !!companyId,
  });

  const { data: biometricMachines = [] } = useQuery<BiometricMachine[]>({
    queryKey: [`/api/biometric-machines/${companyId}`],
    enabled: !!companyId,
  });

  const { data: holidays = [] } = useQuery<Holiday[]>({
    queryKey: [`/api/holidays/${companyId}`],
    enabled: !!companyId,
  });

  const { data: leavePolicies = [] } = useQuery<LeavePolicy[]>({
    queryKey: [`/api/leave-policies/${companyId}`],
    enabled: !!companyId,
  });

  // Department mutation
  const departmentMutation = useMutation({
    mutationFn: async (data: any) => {
      const method = selectedItem ? 'PUT' : 'POST';
      const url = selectedItem ? `/api/departments/${selectedItem.id}` : '/api/departments';
      const response = await apiRequestWithAuth(method, url, { ...data, companyId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/departments/${companyId}`] });
      setShowDialog(false);
      setFormData({});
      toast({
        title: "Success",
        description: `Department ${selectedItem ? 'updated' : 'created'} successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save department",
        variant: "destructive",
      });
    },
  });

  // Designation mutation
  const designationMutation = useMutation({
    mutationFn: async (data: any) => {
      const method = selectedItem ? 'PUT' : 'POST';
      const url = selectedItem ? `/api/designations/${selectedItem.id}` : '/api/designations';
      const response = await apiRequestWithAuth(method, url, { ...data, companyId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/designations/${companyId}`] });
      setShowDialog(false);
      setFormData({});
      toast({
        title: "Success",
        description: `Designation ${selectedItem ? 'updated' : 'created'} successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save designation",
        variant: "destructive",
      });
    },
  });

  // Biometric Machine mutation
  const biometricMachineMutation = useMutation({
    mutationFn: async (data: any) => {
      const method = selectedItem ? 'PUT' : 'POST';
      const url = selectedItem ? `/api/biometric-machines/${selectedItem.id}` : '/api/biometric-machines';
      const response = await apiRequestWithAuth(method, url, { ...data, companyId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/biometric-machines/${companyId}`] });
      setShowDialog(false);
      setFormData({});
      toast({
        title: "Success",
        description: `Biometric Machine ${selectedItem ? 'updated' : 'created'} successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save biometric machine",
        variant: "destructive",
      });
    },
  });

  // Permission checks after all hooks
  if (permissionLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Checking permissions...</p>
        </div>
      </div>
    );
  }
  
  if (!canAccessSettings) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Building2 className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-red-600 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">You don't have permission to access company settings.</p>
          <p className="text-sm text-gray-500">Request 'company_settings' permission from your administrator.</p>
        </div>
      </div>
    );
  }

  const handleOpenDialog = (type: string, item?: any) => {
    setDialogType(type);
    setSelectedItem(item);
    setFormData(item || {});
    setShowDialog(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    switch (dialogType) {
      case 'department':
        departmentMutation.mutate(formData);
        break;
      case 'designation':
        designationMutation.mutate(formData);
        break;
      case 'biometricMachine':
        biometricMachineMutation.mutate(formData);
        break;
      // Add other cases as needed
      default:
        toast({
          title: "Success",
          description: `${dialogType} ${selectedItem ? 'updated' : 'created'} successfully`,
        });
        setShowDialog(false);
    }
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString();
  };

  const renderDepartments = () => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Departments</CardTitle>
          <CardDescription>Manage organizational departments</CardDescription>
        </div>
        <Button onClick={() => handleOpenDialog('department')} className="bg-hr-primary hover:bg-hr-primary/90">
          <Plus className="mr-2 h-4 w-4" />
          Add Department
        </Button>
      </CardHeader>
      <CardContent>
        {departments.length === 0 ? (
          <div className="text-center py-8">
            <Building2 className="mx-auto h-12 w-12 text-gray-400" />
            <p className="mt-4 text-gray-600">No departments found</p>
            <Button onClick={() => handleOpenDialog('department')} className="mt-4">
              Create First Department
            </Button>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Department Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Head of Department</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {departments.map((dept) => (
                <TableRow key={dept.id}>
                  <TableCell className="font-medium">{dept.name}</TableCell>
                  <TableCell>{dept.description}</TableCell>
                  <TableCell>{dept.headOfDepartment}</TableCell>
                  <TableCell>{formatDate(dept.createdAt)}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleOpenDialog('department', dept)}>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );

  const renderGenericTable = (
    title: string, 
    description: string, 
    data: any[], 
    columns: { key: string, label: string, render?: (value: any, item: any) => React.ReactNode }[],
    type: string,
    icon: React.ReactNode
  ) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            {icon}
            {title}
          </CardTitle>
          <CardDescription>{description}</CardDescription>
        </div>
        <Button onClick={() => handleOpenDialog(type)} className="bg-hr-primary hover:bg-hr-primary/90">
          <Plus className="mr-2 h-4 w-4" />
          Add {title.slice(0, -1)}
        </Button>
      </CardHeader>
      <CardContent>
        {data.length === 0 ? (
          <div className="text-center py-8">
            <div className="mx-auto h-12 w-12 text-gray-400 mb-4">{icon}</div>
            <p className="text-gray-600">No {title.toLowerCase()} found</p>
            <Button onClick={() => handleOpenDialog(type)} className="mt-4">
              Create First {title.slice(0, -1)}
            </Button>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                {columns.map((col) => (
                  <TableHead key={col.key}>{col.label}</TableHead>
                ))}
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((item) => (
                <TableRow key={item.id}>
                  {columns.map((col) => (
                    <TableCell key={col.key}>
                      {col.render ? col.render(item[col.key], item) : item[col.key]}
                    </TableCell>
                  ))}
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleOpenDialog(type, item)}>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );

  const renderFormFields = () => {
    switch (dialogType) {
      case 'department':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="name">Department Name</Label>
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Enter department name"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Enter department description"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="headOfDepartment">Head of Department</Label>
              <Input
                id="headOfDepartment"
                value={formData.headOfDepartment || ''}
                onChange={(e) => setFormData({...formData, headOfDepartment: e.target.value})}
                placeholder="Enter head of department"
              />
            </div>
          </>
        );
      
      case 'designation':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="title">Job Title</Label>
              <Input
                id="title"
                value={formData.title || ''}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                placeholder="Enter job title"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="departmentId">Department</Label>
              <Select value={formData.departmentId?.toString()} onValueChange={(value) => setFormData({...formData, departmentId: parseInt(value)})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id.toString()}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="level">Level</Label>
              <Select value={formData.level} onValueChange={(value) => setFormData({...formData, level: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Junior">Junior</SelectItem>
                  <SelectItem value="Mid">Mid</SelectItem>
                  <SelectItem value="Senior">Senior</SelectItem>
                  <SelectItem value="Lead">Lead</SelectItem>
                  <SelectItem value="Manager">Manager</SelectItem>
                  <SelectItem value="Director">Director</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Enter job description"
              />
            </div>
          </>
        );

      case 'branch':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Branch Name</Label>
                <Input
                  id="name"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Enter branch name"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manager">Manager</Label>
                <Input
                  id="manager"
                  value={formData.manager || ''}
                  onChange={(e) => setFormData({...formData, manager: e.target.value})}
                  placeholder="Enter manager name"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                value={formData.address || ''}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="Enter full address"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={formData.city || ''}
                  onChange={(e) => setFormData({...formData, city: e.target.value})}
                  placeholder="City"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="state">State</Label>
                <Input
                  id="state"
                  value={formData.state || ''}
                  onChange={(e) => setFormData({...formData, state: e.target.value})}
                  placeholder="State"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="zipCode">ZIP Code</Label>
                <Input
                  id="zipCode"
                  value={formData.zipCode || ''}
                  onChange={(e) => setFormData({...formData, zipCode: e.target.value})}
                  placeholder="ZIP"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={formData.phone || ''}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                placeholder="Enter phone number"
              />
            </div>
          </>
        );

      case 'biometricMachine':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="serialNumber">Serial Number</Label>
                <Input
                  id="serialNumber"
                  value={formData.serialNumber || ''}
                  onChange={(e) => setFormData({...formData, serialNumber: e.target.value})}
                  placeholder="Enter serial number"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="model">Model</Label>
                <Input
                  id="model"
                  value={formData.model || ''}
                  onChange={(e) => setFormData({...formData, model: e.target.value})}
                  placeholder="Enter model name"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ipAddress">IP Address</Label>
                <Input
                  id="ipAddress"
                  value={formData.ipAddress || ''}
                  onChange={(e) => setFormData({...formData, ipAddress: e.target.value})}
                  placeholder="192.168.1.100"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="port">Port</Label>
                <Input
                  id="port"
                  type="number"
                  value={formData.port || ''}
                  onChange={(e) => setFormData({...formData, port: parseInt(e.target.value) || ''})}
                  placeholder="4370"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={formData.location || ''}
                onChange={(e) => setFormData({...formData, location: e.target.value})}
                placeholder="Main Entrance, Floor 2, etc."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </>
        );

      case 'holiday':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="name">Holiday Name</Label>
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="New Year's Day, Christmas, etc."
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={formData.date || ''}
                onChange={(e) => setFormData({...formData, date: e.target.value})}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Type</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="national">National Holiday</SelectItem>
                  <SelectItem value="regional">Regional Holiday</SelectItem>
                  <SelectItem value="company">Company Holiday</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Optional description"
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="mandatory"
                checked={formData.mandatory || false}
                onChange={(e) => setFormData({...formData, mandatory: e.target.checked})}
              />
              <Label htmlFor="mandatory">Mandatory Holiday</Label>
            </div>
          </>
        );

      case 'leavePolicy':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="name">Policy Name</Label>
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Annual Leave, Sick Leave, etc."
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Leave Type</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select leave type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="annual">Annual Leave</SelectItem>
                  <SelectItem value="sick">Sick Leave</SelectItem>
                  <SelectItem value="maternity">Maternity Leave</SelectItem>
                  <SelectItem value="paternity">Paternity Leave</SelectItem>
                  <SelectItem value="personal">Personal Leave</SelectItem>
                  <SelectItem value="emergency">Emergency Leave</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="allowedDays">Allowed Days per Year</Label>
              <Input
                id="allowedDays"
                type="number"
                value={formData.allowedDays || ''}
                onChange={(e) => setFormData({...formData, allowedDays: parseInt(e.target.value) || ''})}
                placeholder="21"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Policy description and rules"
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="carryForward"
                checked={formData.carryForward || false}
                onChange={(e) => setFormData({...formData, carryForward: e.target.checked})}
              />
              <Label htmlFor="carryForward">Allow Carry Forward to Next Year</Label>
            </div>
          </>
        );

      case 'location':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Location Name</Label>
                <Input
                  id="name"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Conference Room A, Parking Lot, etc."
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="branchId">Branch</Label>
                <Select value={formData.branchId?.toString()} onValueChange={(value) => setFormData({...formData, branchId: parseInt(value)})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select branch" />
                  </SelectTrigger>
                  <SelectContent>
                    {branches.map((branch) => (
                      <SelectItem key={branch.id} value={branch.id.toString()}>{branch.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                value={formData.address || ''}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="Detailed address of the location"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="capacity">Capacity</Label>
              <Input
                id="capacity"
                type="number"
                value={formData.capacity || ''}
                onChange={(e) => setFormData({...formData, capacity: parseInt(e.target.value) || ''})}
                placeholder="50"
              />
            </div>
          </>
        );

      case 'costCenter':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="code">Cost Center Code</Label>
                <Input
                  id="code"
                  value={formData.code || ''}
                  onChange={(e) => setFormData({...formData, code: e.target.value})}
                  placeholder="CC001, IT-001, etc."
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="IT Department, Marketing, etc."
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="budget">Budget</Label>
                <Input
                  id="budget"
                  value={formData.budget || ''}
                  onChange={(e) => setFormData({...formData, budget: e.target.value})}
                  placeholder="$50,000"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manager">Manager</Label>
                <Input
                  id="manager"
                  value={formData.manager || ''}
                  onChange={(e) => setFormData({...formData, manager: e.target.value})}
                  placeholder="John Doe"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Purpose and scope of this cost center"
              />
            </div>
          </>
        );

      default:
        return (
          <div className="space-y-4">
            <p className="text-gray-600">Form fields for {dialogType} will be implemented based on requirements.</p>
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Company Settings</h1>
          <p className="text-muted-foreground">Manage organizational structure and configuration</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="designations">Designations</TabsTrigger>
          <TabsTrigger value="locations">Locations</TabsTrigger>
          <TabsTrigger value="systems">Systems</TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="departments">
            {renderDepartments()}
          </TabsContent>

          <TabsContent value="designations">
            <div className="space-y-6">
              {renderGenericTable(
                "Designations",
                "Manage job titles and positions",
                designations,
                [
                  { key: "title", label: "Job Title" },
                  { 
                    key: "departmentId", 
                    label: "Department", 
                    render: (value) => departments.find(d => d.id === value)?.name || 'N/A'
                  },
                  { key: "level", label: "Level", render: (value) => <Badge variant="outline">{value}</Badge> },
                  { key: "description", label: "Description" }
                ],
                "designation",
                <Users className="h-5 w-5" />
              )}
            </div>
          </TabsContent>

          <TabsContent value="locations">
            <div className="space-y-6">
              {renderGenericTable(
                "Branches",
                "Manage office branches and locations",
                branches,
                [
                  { key: "name", label: "Branch Name" },
                  { key: "city", label: "City" },
                  { key: "state", label: "State" },
                  { key: "manager", label: "Manager" },
                  { key: "phone", label: "Contact" }
                ],
                "branch",
                <Building2 className="h-5 w-5" />
              )}
              
              {renderGenericTable(
                "Locations",
                "Manage specific locations within branches",
                locations,
                [
                  { key: "name", label: "Location Name" },
                  { key: "address", label: "Address" },
                  { 
                    key: "branchId", 
                    label: "Branch", 
                    render: (value) => branches.find(b => b.id === value)?.name || 'N/A'
                  },
                  { key: "capacity", label: "Capacity", render: (value) => `${value} people` }
                ],
                "location",
                <MapPin className="h-5 w-5" />
              )}
              
              {renderGenericTable(
                "Cost Centers",
                "Manage budget allocation and cost tracking",
                costCenters,
                [
                  { key: "code", label: "Code", render: (value) => <Badge variant="secondary">{value}</Badge> },
                  { key: "name", label: "Name" },
                  { key: "budget", label: "Budget" },
                  { key: "manager", label: "Manager" },
                  { key: "description", label: "Description" }
                ],
                "costCenter",
                <DollarSign className="h-5 w-5" />
              )}
            </div>
          </TabsContent>

          <TabsContent value="systems">
            <div className="space-y-6">
              {renderGenericTable(
                "Biometric Machines",
                "Manage attendance tracking devices with IP and port configuration",
                biometricMachines,
                [
                  { key: "serialNumber", label: "Serial Number", render: (value) => <Badge variant="outline">{value}</Badge> },
                  { key: "ipAddress", label: "IP Address", render: (value) => <code className="bg-gray-100 px-2 py-1 rounded text-sm">{value}</code> },
                  { key: "port", label: "Port", render: (value) => <Badge variant="secondary">{value}</Badge> },
                  { key: "location", label: "Location" },
                  { key: "model", label: "Model" },
                  { 
                    key: "status", 
                    label: "Status", 
                    render: (value) => (
                      <Badge variant={value === 'active' ? 'default' : value === 'inactive' ? 'secondary' : 'destructive'}>
                        {value}
                      </Badge>
                    )
                  }
                ],
                "biometricMachine",
                <Fingerprint className="h-5 w-5" />
              )}
              
              {renderGenericTable(
                "Holidays",
                "Manage company and national holidays",
                holidays,
                [
                  { key: "name", label: "Holiday Name" },
                  { key: "date", label: "Date", render: (value) => formatDate(value) },
                  { 
                    key: "type", 
                    label: "Type", 
                    render: (value) => (
                      <Badge variant={value === 'national' ? 'default' : value === 'regional' ? 'secondary' : 'outline'}>
                        {value}
                      </Badge>
                    )
                  },
                  { 
                    key: "mandatory", 
                    label: "Mandatory", 
                    render: (value) => value ? <Badge variant="default">Yes</Badge> : <Badge variant="secondary">No</Badge>
                  }
                ],
                "holiday",
                <Calendar className="h-5 w-5" />
              )}
              
              {renderGenericTable(
                "Leave Policies",
                "Manage employee leave policies and allowances",
                leavePolicies,
                [
                  { key: "name", label: "Policy Name" },
                  { 
                    key: "type", 
                    label: "Type", 
                    render: (value) => <Badge variant="outline">{value}</Badge>
                  },
                  { key: "allowedDays", label: "Allowed Days", render: (value) => `${value} days/year` },
                  { 
                    key: "carryForward", 
                    label: "Carry Forward", 
                    render: (value) => value ? <Badge variant="default">Yes</Badge> : <Badge variant="secondary">No</Badge>
                  }
                ],
                "leavePolicy",
                <Clock className="h-5 w-5" />
              )}
            </div>
          </TabsContent>
        </div>
      </Tabs>

      {/* Generic Dialog for Forms */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedItem ? `Edit ${dialogType}` : `Add New ${dialogType}`}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            {renderFormFields()}
            <div className="flex justify-end space-x-2 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-hr-primary hover:bg-hr-primary/90"
                disabled={departmentMutation.isPending}
              >
                {departmentMutation.isPending ? 'Saving...' : (selectedItem ? 'Update' : 'Create')}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}