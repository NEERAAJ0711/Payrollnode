import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { 
  Edit, Save, User, MapPin, Phone, Mail, Briefcase, Calendar, Building, 
  Camera, Upload, X, Check, Star, Award, GraduationCap, Clock, DollarSign,
  FileText, Shield, CreditCard, Users, Home, Settings, Eye, Search
} from "lucide-react";
import { useAuth, apiRequestWithAuth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import React, { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import type { EmployeeProfile, Job, JobApplication, KycDetails } from "@shared/schema";

const profileSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  fatherName: z.string().optional(),
  presentAddress: z.string().optional(),
  permanentAddress: z.string().optional(),
  currentSalary: z.string().optional(),
  expectedSalary: z.string().optional(),
  noticePeriod: z.string().optional(),
  primaryContact: z.string().optional(),
  alternativeContact: z.string().optional(),
  totalExperience: z.string().optional(),
  speciality: z.string().optional(),
  skills: z.string().optional(),
  experience: z.string().optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
});

const kycSchema = z.object({
  aadharNo: z.string().optional(),
  panNo: z.string().optional(),
  bankAccountNo: z.string().optional(),
  ifscCode: z.string().optional(),
  uanNo: z.string().optional(),
  esicNo: z.string().optional(),
});

type ProfileData = z.infer<typeof profileSchema>;
type KycData = z.infer<typeof kycSchema>;

export default function EmployeeProfile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isEditingKyc, setIsEditingKyc] = useState(false);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: profile, isLoading } = useQuery<EmployeeProfile>({
    queryKey: ['/api/employee/profile'],
    enabled: !!user?.id,
    staleTime: 0, // Always fetch fresh data to get latest profile info
    refetchOnMount: true,
  });

  const { data: availableJobs = [] } = useQuery<Job[]>({
    queryKey: ['/api/jobs/public'],
  });

  const { data: myApplications = [] } = useQuery<JobApplication[]>({
    queryKey: ['/api/job-applications/my'],
    enabled: !!user?.id,
  });

  const { data: kycDetails } = useQuery<KycDetails>({
    queryKey: ['/api/employee/kyc'],
    enabled: !!profile?.id,
    staleTime: 0, // Always fetch fresh KYC data including Aadhaar info
    refetchOnMount: true,
  });

  const form = useForm<ProfileData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: profile?.firstName || '',
      lastName: profile?.lastName || '',
      fatherName: profile?.fatherName || '',
      presentAddress: profile?.presentAddress || '',
      permanentAddress: profile?.permanentAddress || '',
      currentSalary: profile?.currentSalary || '',
      expectedSalary: profile?.expectedSalary || '',
      noticePeriod: profile?.noticePeriod || '',
      primaryContact: profile?.primaryContact || '',
      alternativeContact: profile?.alternativeContact || '',
      totalExperience: profile?.totalExperience || '',
      speciality: profile?.speciality || '',
      skills: profile?.skills || '',
      experience: profile?.experience || '',
      phone: profile?.phone || '',
      address: profile?.address || '',
    },
  });

  // Reset form when profile data changes
  React.useEffect(() => {
    if (profile) {
      console.log('Profile data loaded for prefilling:', profile);
      const formData = {
        firstName: profile.firstName || '',
        lastName: profile.lastName || '',
        fatherName: profile.fatherName || '',
        presentAddress: profile.presentAddress || '',
        permanentAddress: profile.permanentAddress || '',
        currentSalary: profile.currentSalary || '',
        expectedSalary: profile.expectedSalary || '',
        noticePeriod: profile.noticePeriod || '',
        primaryContact: profile.primaryContact || '',
        alternativeContact: profile.alternativeContact || '',
        totalExperience: profile.totalExperience || '',
        speciality: profile.speciality || '',
        skills: profile.skills || '',
        experience: profile.experience || '',
        phone: profile.phone || '',
        address: profile.address || '',
      };
      console.log('Form data being set:', formData);
      form.reset(formData);
    }
  }, [profile, form]);

  const kycForm = useForm<KycData>({
    resolver: zodResolver(kycSchema),
    defaultValues: {
      aadharNo: kycDetails?.aadharNo || '',
      panNo: kycDetails?.panNo || '',
      bankAccountNo: kycDetails?.bankAccountNo || '',
      ifscCode: kycDetails?.ifscCode || '',
      uanNo: kycDetails?.uanNo || '',
      esicNo: kycDetails?.esicNo || '',
    },
  });

  // Reset KYC form when data changes
  React.useEffect(() => {
    if (kycDetails) {
      console.log('KYC data loaded for prefilling:', kycDetails);
      const kycFormData = {
        aadharNo: kycDetails.aadharNo || '',
        panNo: kycDetails.panNo || '',
        bankAccountNo: kycDetails.bankAccountNo || '',
        ifscCode: kycDetails.ifscCode || '',
        uanNo: kycDetails.uanNo || '',
        esicNo: kycDetails.esicNo || '',
      };
      console.log('KYC form data being set:', kycFormData);
      kycForm.reset(kycFormData);
    }
  }, [kycDetails, kycForm]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileData) => {
      const response = await apiRequestWithAuth('PUT', '/api/employee/profile', data);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({ title: "Profile updated successfully!" });
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ['/api/employee/profile'] });
    },
    onError: (error: any) => {
      console.error('Profile update error:', error);
      toast({ 
        title: "Failed to update profile", 
        description: error.message || "Unknown error occurred",
        variant: "destructive" 
      });
    },
  });

  const applyToJobMutation = useMutation({
    mutationFn: async (jobId: number) => {
      return await apiRequest('POST', '/api/job-applications', {
        jobId,
        applicantName: `${profile?.firstName} ${profile?.lastName}`,
        applicantEmail: user?.email,
        applicantPhone: profile?.phone || '',
        coverLetter: 'Applied through employee portal',
      });
    },
    onSuccess: () => {
      toast({ title: "Application submitted successfully!" });
      queryClient.invalidateQueries({ queryKey: ['/api/job-applications/my'] });
    },
    onError: () => {
      toast({ 
        title: "Failed to submit application", 
        variant: "destructive" 
      });
    },
  });

  const updateKycMutation = useMutation({
    mutationFn: async (data: KycData) => {
      return await apiRequest('PUT', '/api/employee/kyc', data);
    },
    onSuccess: () => {
      toast({ title: "KYC details updated successfully!" });
      setIsEditingKyc(false);
      queryClient.invalidateQueries({ queryKey: ['/api/employee/kyc'] });
    },
    onError: () => {
      toast({ 
        title: "Failed to update KYC details", 
        variant: "destructive" 
      });
    },
  });

  const onSubmit = (data: ProfileData) => {
    updateProfileMutation.mutate(data);
  };

  const onKycSubmit = (data: KycData) => {
    updateKycMutation.mutate(data);
  };

  // Handle profile image upload
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      toast({
        title: "Error",
        description: "Image size should be less than 5MB",
        variant: "destructive",
      });
      return;
    }

    setIsUploadingImage(true);
    try {
      // Create a data URL for the image preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
      
      toast({
        title: "Success",
        description: "Profile photo updated successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload image",
        variant: "destructive",
      });
    } finally {
      setIsUploadingImage(false);
    }
  };

  const removeProfileImage = () => {
    setProfileImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    return `${firstName?.charAt(0) || ''}${lastName?.charAt(0) || ''}`.toUpperCase();
  };

  const getProfileCompleteness = () => {
    if (!profile) return 0;
    const fields = [
      profile.firstName,
      profile.lastName,
      profile.phone,
      profile.address,
      profile.skills,
      profile.experience,
      kycDetails?.aadharNo,
      kycDetails?.panNo,
    ];
    const filledFields = fields.filter(field => field && field.trim() !== '').length;
    return Math.round((filledFields / fields.length) * 100);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };



  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading your profile...</p>
        </div>
      </div>
    );
  }

  const completeness = getProfileCompleteness();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header Section */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="flex flex-col lg:flex-row items-center lg:items-start gap-8">
            {/* Profile Photo Section */}
            <div className="relative group">
              <div className="relative">
                <Avatar className="w-32 h-32 border-4 border-white shadow-lg">
                  {profileImage ? (
                    <AvatarImage src={profileImage} alt="Profile" />
                  ) : (
                    <AvatarFallback className="text-2xl font-semibold bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                      {getInitials(profile?.firstName, profile?.lastName)}
                    </AvatarFallback>
                  )}
                </Avatar>
                
                {/* Upload Button */}
                <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                  <Button
                    size="sm"
                    variant="secondary"
                    className="bg-white bg-opacity-90 hover:bg-opacity-100"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploadingImage}
                  >
                    {isUploadingImage ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600" />
                    ) : (
                      <Camera className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                
                {/* Remove Image Button */}
                {profileImage && (
                  <Button
                    size="sm"
                    variant="destructive"
                    className="absolute -top-2 -right-2 rounded-full h-8 w-8 p-0"
                    onClick={removeProfileImage}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>

            {/* Profile Info */}
            <div className="flex-1 text-center lg:text-left">
              <div className="mb-4">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  {profile?.firstName} {profile?.lastName}
                </h1>
                <p className="text-lg text-gray-600 mb-3">
                  {profile?.speciality || 'Software Professional'} 
                </p>
                
                {/* Contact Info */}
                <div className="flex flex-wrap justify-center lg:justify-start gap-4 text-sm text-gray-500">
                  {user?.email && (
                    <div className="flex items-center gap-1">
                      <Mail className="h-4 w-4" />
                      <span>{user.email}</span>
                    </div>
                  )}
                  {profile?.phone && (
                    <div className="flex items-center gap-1">
                      <Phone className="h-4 w-4" />
                      <span>{profile.phone}</span>
                    </div>
                  )}
                  {profile?.address && (
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>{profile.address}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Profile Completeness */}
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Profile Completeness</span>
                  <span className="text-sm font-semibold text-gray-900">{completeness}%</span>
                </div>
                <Progress value={completeness} className="h-2" />
                <p className="text-xs text-gray-500 mt-1">
                  {completeness < 100 ? "Complete your profile to increase visibility to employers" : "Your profile is complete!"}
                </p>
              </div>

              {/* Quick Stats */}
              <div className="flex justify-center lg:justify-start gap-6">
                <div className="text-center">
                  <div className="text-xl font-bold text-blue-600">{profile?.totalExperience || '0'}</div>
                  <div className="text-xs text-gray-500">Years Exp.</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-green-600">{myApplications.length}</div>
                  <div className="text-xs text-gray-500">Applications</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-purple-600">{availableJobs.length}</div>
                  <div className="text-xs text-gray-500">Open Jobs</div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-2">
              <Button onClick={() => setIsEditing(!isEditing)} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                {isEditing ? (
                  <>
                    <X className="mr-2 h-4 w-4" />
                    Cancel Edit
                  </>
                ) : (
                  <>
                    <Edit className="mr-2 h-4 w-4" />
                    Edit Profile
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={() => window.print()}>
                <FileText className="mr-2 h-4 w-4" />
                Download Resume
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-6 py-8">
        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="grid grid-cols-2 lg:grid-cols-6 w-full">
            <TabsTrigger value="personal" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">Personal</span>
            </TabsTrigger>
            <TabsTrigger value="professional" className="flex items-center gap-2">
              <Briefcase className="h-4 w-4" />
              <span className="hidden sm:inline">Professional</span>
            </TabsTrigger>
            <TabsTrigger value="documents" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Documents</span>
            </TabsTrigger>
            <TabsTrigger value="jobs" className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              <span className="hidden sm:inline">Jobs</span>
            </TabsTrigger>
            <TabsTrigger value="applications" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span className="hidden sm:inline">Applications</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Settings</span>
            </TabsTrigger>
          </TabsList>

          {/* Personal Information Tab */}
          <TabsContent value="personal">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Personal Information
                </CardTitle>
                <CardDescription className="text-blue-100">
                  Your basic personal and contact information
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {isEditing ? (
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="firstName" className="text-sm font-medium">First Name *</Label>
                        <Input
                          id="firstName"
                          {...form.register("firstName")}
                          className="h-12"
                          placeholder="Enter your first name"
                        />
                        {form.formState.errors.firstName && (
                          <p className="text-sm text-red-600">{form.formState.errors.firstName.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="lastName" className="text-sm font-medium">Last Name *</Label>
                        <Input
                          id="lastName"
                          {...form.register("lastName")}
                          className="h-12"
                          placeholder="Enter your last name"
                        />
                        {form.formState.errors.lastName && (
                          <p className="text-sm text-red-600">{form.formState.errors.lastName.message}</p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="fatherName" className="text-sm font-medium">Father's Name</Label>
                        <Input
                          id="fatherName"
                          {...form.register("fatherName")}
                          className="h-12"
                          placeholder="Enter your father's name"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-sm font-medium">Phone Number</Label>
                        <Input
                          id="phone"
                          {...form.register("phone")}
                          className="h-12"
                          placeholder="Enter your phone number"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="presentAddress" className="text-sm font-medium">Present Address</Label>
                        <Textarea
                          id="presentAddress"
                          {...form.register("presentAddress")}
                          className="min-h-[100px]"
                          placeholder="Enter your current address"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="permanentAddress" className="text-sm font-medium">Permanent Address</Label>
                        <Textarea
                          id="permanentAddress"
                          {...form.register("permanentAddress")}
                          className="min-h-[100px]"
                          placeholder="Enter your permanent address"
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        type="submit" 
                        disabled={updateProfileMutation.isPending}
                        className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                      >
                        {updateProfileMutation.isPending ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        ) : (
                          <Save className="mr-2 h-4 w-4" />
                        )}
                        Save Changes
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                        <X className="mr-2 h-4 w-4" />
                        Cancel
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">First Name</Label>
                          <p className="text-lg font-medium">{profile?.firstName || 'Not provided'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Father's Name</Label>
                          <p className="text-lg font-medium">{profile?.fatherName || 'Not provided'}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Last Name</Label>
                          <p className="text-lg font-medium">{profile?.lastName || 'Not provided'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Phone Number</Label>
                          <p className="text-lg font-medium">{profile?.phone || 'Not provided'}</p>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Present Address</Label>
                          <p className="text-lg">{profile?.presentAddress || 'Not provided'}</p>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Permanent Address</Label>
                          <p className="text-lg">{profile?.permanentAddress || 'Not provided'}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Professional Information Tab */}
          <TabsContent value="professional">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5" />
                  Professional Information
                </CardTitle>
                <CardDescription className="text-purple-100">
                  Your career and work-related details
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {isEditing ? (
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="speciality" className="text-sm font-medium">Specialization</Label>
                        <Input
                          id="speciality"
                          {...form.register("speciality")}
                          className="h-12"
                          placeholder="e.g., Software Engineer, Data Analyst"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="totalExperience" className="text-sm font-medium">Total Experience (Years)</Label>
                        <Input
                          id="totalExperience"
                          {...form.register("totalExperience")}
                          className="h-12"
                          placeholder="e.g., 2.5"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="currentSalary" className="text-sm font-medium">Current Salary (LPA)</Label>
                        <Input
                          id="currentSalary"
                          {...form.register("currentSalary")}
                          className="h-12"
                          placeholder="e.g., 8.5"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="expectedSalary" className="text-sm font-medium">Expected Salary (LPA)</Label>
                        <Input
                          id="expectedSalary"
                          {...form.register("expectedSalary")}
                          className="h-12"
                          placeholder="e.g., 12.0"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="noticePeriod" className="text-sm font-medium">Notice Period</Label>
                        <Input
                          id="noticePeriod"
                          {...form.register("noticePeriod")}
                          className="h-12"
                          placeholder="e.g., 30 days, Immediate"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="primaryContact" className="text-sm font-medium">Primary Contact</Label>
                        <Input
                          id="primaryContact"
                          {...form.register("primaryContact")}
                          className="h-12"
                          placeholder="Alternative contact number"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="skills" className="text-sm font-medium">Skills</Label>
                        <Textarea
                          id="skills"
                          {...form.register("skills")}
                          className="min-h-[100px]"
                          placeholder="e.g., React, Node.js, Python, SQL, AWS"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="experience" className="text-sm font-medium">Work Experience</Label>
                        <Textarea
                          id="experience"
                          {...form.register("experience")}
                          className="min-h-[120px]"
                          placeholder="Describe your work experience, projects, and achievements"
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        type="submit" 
                        disabled={updateProfileMutation.isPending}
                        className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                      >
                        {updateProfileMutation.isPending ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        ) : (
                          <Save className="mr-2 h-4 w-4" />
                        )}
                        Save Changes
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                        <X className="mr-2 h-4 w-4" />
                        Cancel
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Specialization</Label>
                          <p className="text-lg font-medium">{profile?.speciality || 'Not specified'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Current Salary</Label>
                          <p className="text-lg font-medium">{profile?.currentSalary ? `₹${profile.currentSalary} LPA` : 'Not provided'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Notice Period</Label>
                          <p className="text-lg font-medium">{profile?.noticePeriod || 'Not specified'}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Total Experience</Label>
                          <p className="text-lg font-medium">{profile?.totalExperience ? `${profile.totalExperience} years` : 'Not specified'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Expected Salary</Label>
                          <p className="text-lg font-medium">{profile?.expectedSalary ? `₹${profile.expectedSalary} LPA` : 'Not provided'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Primary Contact</Label>
                          <p className="text-lg font-medium">{profile?.primaryContact || 'Not provided'}</p>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Skills</Label>
                          <p className="text-lg">{profile?.skills || 'No skills listed'}</p>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Work Experience</Label>
                          <div className="prose max-w-none">
                            <p className="text-lg">{profile?.experience || 'No experience details provided'}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documents Tab */}
          <TabsContent value="documents">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Documents & KYC
                </CardTitle>
                <CardDescription className="text-green-100">
                  Your identification and compliance documents
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {isEditingKyc ? (
                  <form onSubmit={kycForm.handleSubmit(onKycSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="aadharNo" className="text-sm font-medium">Aadhaar Number</Label>
                        <Input
                          id="aadharNo"
                          {...kycForm.register("aadharNo")}
                          className="h-12"
                          placeholder="1234 5678 9012"
                          maxLength={12}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="panNo" className="text-sm font-medium">PAN Number</Label>
                        <Input
                          id="panNo"
                          {...kycForm.register("panNo")}
                          className="h-12"
                          placeholder="ABCDE1234F"
                          maxLength={10}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bankAccountNo" className="text-sm font-medium">Bank Account Number</Label>
                        <Input
                          id="bankAccountNo"
                          {...kycForm.register("bankAccountNo")}
                          className="h-12"
                          placeholder="12345678901234"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="ifscCode" className="text-sm font-medium">IFSC Code</Label>
                        <Input
                          id="ifscCode"
                          {...kycForm.register("ifscCode")}
                          className="h-12"
                          placeholder="SBIN0001234"
                          maxLength={11}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="uanNo" className="text-sm font-medium">UAN Number</Label>
                        <Input
                          id="uanNo"
                          {...kycForm.register("uanNo")}
                          className="h-12"
                          placeholder="123456789012"
                          maxLength={12}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="esicNo" className="text-sm font-medium">ESIC Number</Label>
                        <Input
                          id="esicNo"
                          {...kycForm.register("esicNo")}
                          className="h-12"
                          placeholder="1234567890"
                          maxLength={10}
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        type="submit" 
                        disabled={updateKycMutation.isPending}
                        className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                      >
                        {updateKycMutation.isPending ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        ) : (
                          <Save className="mr-2 h-4 w-4" />
                        )}
                        Save Documents
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsEditingKyc(false)}>
                        <X className="mr-2 h-4 w-4" />
                        Cancel
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div className="bg-blue-50 p-4 rounded-lg">
                          <Label className="text-sm text-blue-600 font-medium">Identity Documents</Label>
                          <div className="mt-2 space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Aadhaar Number</span>
                              <span className="font-medium">{kycDetails?.aadharNo ? `****-****-${kycDetails.aadharNo.slice(-4)}` : 'Not provided'}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">PAN Number</span>
                              <span className="font-medium">{kycDetails?.panNo || 'Not provided'}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="bg-green-50 p-4 rounded-lg">
                          <Label className="text-sm text-green-600 font-medium">Banking Details</Label>
                          <div className="mt-2 space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Account Number</span>
                              <span className="font-medium">{kycDetails?.bankAccountNo ? `****${kycDetails.bankAccountNo.slice(-4)}` : 'Not provided'}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">IFSC Code</span>
                              <span className="font-medium">{kycDetails?.ifscCode || 'Not provided'}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="md:col-span-2">
                        <div className="bg-purple-50 p-4 rounded-lg">
                          <Label className="text-sm text-purple-600 font-medium">Employment Documents</Label>
                          <div className="mt-2 grid grid-cols-2 gap-4">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">UAN Number</span>
                              <span className="font-medium">{kycDetails?.uanNo || 'Not provided'}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">ESIC Number</span>
                              <span className="font-medium">{kycDetails?.esicNo || 'Not provided'}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-center">
                      <Button onClick={() => setIsEditingKyc(true)} variant="outline">
                        <Edit className="mr-2 h-4 w-4" />
                        Edit Documents
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Jobs Tab */}
          <TabsContent value="jobs">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5" />
                  Available Jobs
                </CardTitle>
                <CardDescription className="text-orange-100">
                  Browse and apply for open positions
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {availableJobs.length > 0 ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {availableJobs.map((job: any) => (
                      <Card key={job.id} className="border border-gray-200 hover:shadow-md transition-shadow">
                        <CardHeader className="pb-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <CardTitle className="text-lg">{job.title}</CardTitle>
                              <CardDescription className="text-sm text-gray-600">
                                {job.department} • {job.location}
                              </CardDescription>
                            </div>
                            <Badge variant={job.status === 'active' ? 'default' : 'secondary'}>
                              {job.status}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="space-y-3">
                            <p className="text-sm text-gray-700 line-clamp-3">{job.description}</p>
                            
                            <div className="flex items-center gap-4 text-xs text-gray-500">
                              <div className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                <span>Posted {new Date(job.createdAt).toLocaleDateString()}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Users className="h-3 w-3" />
                                <span>{job.requirements || 'No specific requirements'}</span>
                              </div>
                            </div>

                            {job.salaryRange && (
                              <div className="flex items-center gap-1 text-sm font-medium text-green-600">
                                <DollarSign className="h-4 w-4" />
                                <span>{job.salaryRange}</span>
                              </div>
                            )}
                          </div>
                          
                          <div className="mt-4 pt-4 border-t">
                            <Button 
                              onClick={() => applyToJobMutation.mutate(job.id)}
                              disabled={applyToJobMutation.isPending}
                              className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                            >
                              {applyToJobMutation.isPending ? (
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                              ) : (
                                <Upload className="mr-2 h-4 w-4" />
                              )}
                              Apply Now
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs available</h3>
                    <p className="text-gray-500">Check back later for new opportunities.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Applications Tab */}
          <TabsContent value="applications">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-teal-500 to-cyan-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  My Applications
                </CardTitle>
                <CardDescription className="text-teal-100">
                  Track your job application status
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {myApplications.length > 0 ? (
                  <div className="space-y-4">
                    {myApplications.map((application: any) => (
                      <Card key={application.id} className="border border-gray-200">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <h4 className="font-semibold text-lg">{application.jobTitle}</h4>
                              <p className="text-sm text-gray-600 mb-2">{application.companyName}</p>
                              <div className="flex items-center gap-4 text-xs text-gray-500">
                                <div className="flex items-center gap-1">
                                  <Calendar className="h-3 w-3" />
                                  <span>Applied {new Date(application.appliedAt).toLocaleDateString()}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <User className="h-3 w-3" />
                                  <span>Application ID: #{application.id}</span>
                                </div>
                              </div>
                            </div>
                            <Badge 
                              variant={application.status === 'approved' ? 'default' : 'secondary'}
                              className={getStatusColor(application.status)}
                            >
                              {application.status}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No applications yet</h3>
                    <p className="text-gray-500 mb-4">You haven't applied to any jobs yet.</p>
                    <Button variant="outline" onClick={() => setIsEditing(false)}>
                      <Search className="mr-2 h-4 w-4" />
                      Browse Jobs
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-gray-700 to-gray-800 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Account Settings
                </CardTitle>
                <CardDescription className="text-gray-200">
                  Manage your account preferences and privacy
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-medium text-blue-900 mb-2">Profile Visibility</h4>
                    <p className="text-sm text-blue-700 mb-3">
                      Control who can see your profile information
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Make profile public</span>
                      <Button variant="outline" size="sm">
                        <Eye className="mr-2 h-4 w-4" />
                        Configure
                      </Button>
                    </div>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-medium text-green-900 mb-2">Download Data</h4>
                    <p className="text-sm text-green-700 mb-3">
                      Download your profile data and application history
                    </p>
                    <Button variant="outline" size="sm">
                      <FileText className="mr-2 h-4 w-4" />
                      Download Profile
                    </Button>
                  </div>

                  <div className="bg-red-50 p-4 rounded-lg">
                    <h4 className="font-medium text-red-900 mb-2">Account Actions</h4>
                    <p className="text-sm text-red-700 mb-3">
                      Manage your account status and data
                    </p>
                    <div className="space-y-2">
                      <Button variant="outline" size="sm" className="text-red-600 border-red-200 hover:bg-red-50">
                        <Shield className="mr-2 h-4 w-4" />
                        Change Password
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      </div>
    </div>
  );
}
