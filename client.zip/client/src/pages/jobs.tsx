import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { authService, apiRequestWithAuth } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";

import JobForm from "@/components/forms/job-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Clock, DollarSign, Eye, Edit, MoreVertical, Trash2, Users } from "lucide-react";
import { type Job } from "@shared/schema";

export default function JobsPage() {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  const user = authService.getUser();
  const companyId = user?.companyId;

  // Fetch jobs
  const { data: jobs = [], isLoading } = useQuery<Job[]>({
    queryKey: [`/api/jobs/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/jobs/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Delete job mutation
  const deleteJobMutation = useMutation({
    mutationFn: async (jobId: number) => {
      await apiRequestWithAuth('DELETE', `/api/jobs/${jobId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/jobs/${companyId}`] });
      toast({
        title: "Success",
        description: "Job deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAddJob = () => {
    setSelectedJob(null);
    setShowForm(true);
  };

  const handleEditJob = (job: Job) => {
    setSelectedJob(job);
    setShowForm(true);
  };

  const handleDeleteJob = (job: Job) => {
    if (confirm(`Are you sure you want to delete "${job.title}"?`)) {
      deleteJobMutation.mutate(job.id);
    }
  };

  // Filter jobs based on search query
  const filteredJobs = jobs.filter(job =>
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.location?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-hr-secondary/10 text-hr-secondary';
      case 'draft':
        return 'bg-yellow-100 text-yellow-700';
      case 'closed':
        return 'bg-gray-100 text-gray-700';
      case 'cancelled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const formatDate = (date: string | Date | null) => {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString();
  };

  const formatSalary = (min: string | null, max: string | null) => {
    if (!min && !max) return 'Not specified';
    if (min && max) return `$${min} - $${max}`;
    if (min) return `From $${min}`;
    if (max) return `Up to $${max}`;
    return 'Not specified';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Job Openings</h1>
          <p className="text-muted-foreground">{filteredJobs.length} jobs total</p>
        </div>
        {user?.role !== 'employee' && (
          <Button onClick={handleAddJob} className="bg-hr-primary hover:bg-hr-primary/90">
            Post New Job
          </Button>
        )}
      </div>

      <div className="flex items-center space-x-4">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Search jobs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-hr-primary focus:border-transparent"
          />
        </div>
      </div>

      {isLoading ? (
            <div className="text-center py-8">
              <p className="text-hr-neutral">Loading jobs...</p>
            </div>
          ) : filteredJobs.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <p className="text-hr-neutral mb-4">
                  {searchQuery ? 'No jobs match your search.' : 'No job openings found.'}
                </p>
                {!searchQuery && user?.role !== 'employee' && (
                  <Button 
                    onClick={handleAddJob}
                    className="bg-hr-primary hover:bg-hr-primary/90"
                  >
                    Post First Job
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredJobs.map((job) => (
                <Card key={job.id} className="shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg font-semibold text-hr-text-primary mb-2">
                          {job.title}
                        </CardTitle>
                        <Badge className={`${getStatusColor(job.status)} capitalize mb-2`}>
                          {job.status}
                        </Badge>
                      </div>
                      {user?.role !== 'employee' && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical size={16} />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => console.log('View applications', job.id)}>
                              <Users size={16} className="mr-2" />
                              View Applications
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEditJob(job)}>
                              <Edit size={16} className="mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDeleteJob(job)}
                              className="text-hr-accent"
                            >
                              <Trash2 size={16} className="mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-3">
                      <p className="text-hr-neutral text-sm line-clamp-3">
                        {job.description}
                      </p>
                      
                      <div className="flex items-center space-x-2 text-sm text-hr-neutral">
                        <MapPin size={16} />
                        <span>{job.location || 'Not specified'}</span>
                      </div>
                      
                      <div className="flex items-center space-x-2 text-sm text-hr-neutral">
                        <DollarSign size={16} />
                        <span>{formatSalary(job.salaryMin, job.salaryMax)}</span>
                      </div>
                      
                      <div className="flex items-center space-x-2 text-sm text-hr-neutral">
                        <Clock size={16} />
                        <span>{job.employmentType || 'Full-time'}</span>
                      </div>
                      
                      {job.postedAt && (
                        <div className="pt-2 border-t border-gray-100">
                          <p className="text-xs text-hr-neutral">
                            Posted: {formatDate(job.postedAt)}
                          </p>
                        </div>
                      )}
                      
                      {job.closingDate && (
                        <p className="text-xs text-hr-neutral">
                          Closes: {formatDate(job.closingDate)}
                        </p>
                      )}
                    </div>
                    
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        onClick={() => console.log('View job details', job.id)}
                      >
                        <Eye size={16} className="mr-2" />
                        View Details
                      </Button>
                    </div>
                </CardContent>
              </Card>
            ))}
        </div>
      )}

      {/* Job Form Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedJob ? 'Edit Job' : 'Post New Job'}
            </DialogTitle>
          </DialogHeader>
          <JobForm
            job={selectedJob}
            onSuccess={() => {
              setShowForm(false);
              queryClient.invalidateQueries({ queryKey: [`/api/jobs/${companyId}`] });
            }}
            onCancel={() => setShowForm(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
