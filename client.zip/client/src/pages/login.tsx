import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { authService } from '@/lib/auth';
import { User, Mail, Lock, Building2, Users } from 'lucide-react';

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const loginMutation = useMutation({
    mutationFn: async (credentials: { email: string; password: string }) => {
      return await authService.login(credentials);
    },
    onSuccess: (data) => {
      toast({
        title: "Login Successful",
        description: `Welcome back, ${data.user.email}!`,
      });
      
      // Redirect based on user role
      if (data.user.role === 'system_admin') {
        setLocation('/admin/companies');
      } else if (data.user.role === 'admin') {
        setLocation('/admin-dashboard');
      } else {
        setLocation('/employee-dashboard');
      }
    },
    onError: (error: any) => {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast({
        title: "Validation Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }
    loginMutation.mutate({ email, password });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-white p-4 rounded-full shadow-lg">
              <Building2 className="h-8 w-8 text-blue-600" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">HR Management System</h1>
          <p className="text-gray-600 text-lg">Employee Lifecycle Management Platform</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Login Form */}
          <Card className="shadow-xl">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold text-center flex items-center justify-center gap-2">
                <User className="h-6 w-6" />
                Sign In
              </CardTitle>
              <CardDescription className="text-center">
                Enter your credentials to access your account
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">
                    Email Address
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email"
                      className="pl-10 h-12"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="pl-10 h-12"
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full h-12 text-lg"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? 'Signing In...' : 'Sign In'}
                </Button>
              </form>

              <div className="pt-4">
                <Button
                  variant="outline"
                  onClick={() => setLocation('/signup')}
                  className="w-full h-12"
                >
                  Don't have an account? Sign up
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Demo Credentials & Information */}
          <div className="space-y-6">
            {/* Demo Credentials */}
            <Card className="border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="text-green-800 flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Demo Credentials
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h4 className="font-medium text-green-800">System Admin</h4>
                  <p className="text-sm text-green-700">
                    <strong>Email:</strong> system@techcorp.com<br />
                    <strong>Password:</strong> sysadmin123
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium text-green-800">Company Admin</h4>
                  <p className="text-sm text-green-700">
                    <strong>Email:</strong> admin@demo.com<br />
                    <strong>Password:</strong> admin123
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium text-green-800">Employee</h4>
                  <p className="text-sm text-green-700">
                    <strong>Email:</strong> employee@demo.com<br />
                    <strong>Password:</strong> emp123
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* System Information */}
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="text-blue-800">System Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-blue-800 mb-2">Employee Management</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• Complete employee lifecycle management</li>
                      <li>• Advanced role-based access control</li>
                      <li>• Comprehensive attendance tracking</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-blue-800 mb-2">HR Operations</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• Recruitment and job management</li>
                      <li>• Payroll and compliance tracking</li>
                      <li>• Leave and advance request workflows</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}