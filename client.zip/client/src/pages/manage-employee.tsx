import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Plus, MoreHorizontal, Edit, Trash2, Users, ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";

// Form schema for employee assignment
const assignEmployeeSchema = z.object({
  employeeId: z.number().min(1, "Please select an employee"),
  designationId: z.number().min(1, "Please select a designation"),
  assignDate: z.string().min(1, "Assign date is required"),
  address: z.string().min(1, "Address is required"),
  useActualAddress: z.boolean().default(false),
});

type AssignEmployeeFormData = z.infer<typeof assignEmployeeSchema>;

interface EmployeeAssignment {
  id: number;
  employeeId: number;
  designationId: number;
  assignDate: string;
  deassignDate?: string;
  address: string;
  employee: {
    id: number;
    firstName: string;
    lastName: string;
    address: string;
  };
  designation: {
    id: number;
    title: string;
  };
}

export default function ManageEmployee() {
  const [location, setLocation] = useLocation();
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [isDeassignDialogOpen, setIsDeassignDialogOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<EmployeeAssignment | null>(null);
  const [deassignDate, setDeassignDate] = useState<string>('');
  const [selectedAssignmentId, setSelectedAssignmentId] = useState<number | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Get project context from URL parameters
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  const projectId = urlParams.get('projectId');
  const projectName = urlParams.get('projectName') ? decodeURIComponent(urlParams.get('projectName')!) : null;

  // Get current user and company info
  const { data: user } = useQuery<any>({
    queryKey: ['/api/auth/me'],
  });

  const companyId = user?.user?.companyId;

  // Fetch employees
  const { data: employees = [] } = useQuery<any[]>({
    queryKey: [`/api/employees/${companyId}`],
    enabled: !!companyId,
  });

  // Fetch designations
  const { data: designations = [] } = useQuery<any[]>({
    queryKey: [`/api/designations/${companyId}`],
    enabled: !!companyId,
  });

  // Fetch employee assignments
  const { data: assignments = [], isLoading } = useQuery<any[]>({
    queryKey: [`/api/employee-assignments/${companyId}`],
    enabled: !!companyId,
  });

  const form = useForm<AssignEmployeeFormData>({
    resolver: zodResolver(assignEmployeeSchema),
    defaultValues: {
      employeeId: 0,
      designationId: 0,
      assignDate: "",
      address: "",
      useActualAddress: false,
    },
  });

  // Watch for selected employee to get actual address
  const selectedEmployeeId = form.watch("employeeId");
  const useActualAddress = form.watch("useActualAddress");
  const selectedEmployee = employees.find((emp: any) => emp.id === selectedEmployeeId);

  // Update address when "Same as actual" is checked
  useEffect(() => {
    if (useActualAddress && selectedEmployee?.address) {
      form.setValue("address", selectedEmployee.address);
    } else if (!useActualAddress) {
      form.setValue("address", "");
    }
  }, [useActualAddress, selectedEmployee?.address, form]);

  // Create employee assignment mutation
  const createAssignmentMutation = useMutation({
    mutationFn: async (data: AssignEmployeeFormData) => {
      const response = await apiRequest('POST', '/api/employee-assignments', { 
        ...data, 
        companyId 
      });
      return response.ok ? response.json() : Promise.reject(new Error('Failed to create assignment'));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/employee-assignments/${companyId}`] });
      setIsAssignDialogOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Employee assigned successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to assign employee",
        variant: "destructive",
      });
    },
  });

  // Update employee assignment mutation
  const updateAssignmentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<AssignEmployeeFormData> }) => {
      const response = await apiRequest('PUT', `/api/employee-assignments/${id}`, data);
      if (!response.ok) {
        throw new Error('Failed to update assignment');
      }
      const text = await response.text();
      return text ? JSON.parse(text) : { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/employee-assignments/${companyId}`] });
      setEditingAssignment(null);
      form.reset();
      toast({
        title: "Success",
        description: "Employee assignment updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update assignment",
        variant: "destructive",
      });
    },
  });

  // Delete employee assignment mutation
  const deleteAssignmentMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/employee-assignments/${id}`);
      return response.ok ? response.json() : Promise.reject(new Error('Failed to delete assignment'));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/employee-assignments/${companyId}`] });
      toast({
        title: "Success",
        description: "Employee assignment deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete assignment",
        variant: "destructive",
      });
    },
  });

  // De-assign employee mutation
  const deassignMutation = useMutation({
    mutationFn: async ({ id, deassignDate }: { id: number; deassignDate: string }) => {
      const response = await apiRequest('PUT', `/api/employee-assignments/${id}/deassign`, {
        deassignDate
      });
      if (!response.ok) {
        throw new Error('Failed to de-assign employee');
      }
      const text = await response.text();
      return text ? JSON.parse(text) : { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/employee-assignments/${companyId}`] });
      toast({
        title: "Success",
        description: "Employee de-assigned successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to de-assign employee",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: AssignEmployeeFormData) => {
    if (editingAssignment) {
      updateAssignmentMutation.mutate({ id: editingAssignment.id, data });
    } else {
      createAssignmentMutation.mutate(data);
    }
  };

  const handleEdit = (assignment: EmployeeAssignment) => {
    setEditingAssignment(assignment);
    form.reset({
      employeeId: assignment.employeeId,
      designationId: assignment.designationId,
      assignDate: assignment.assignDate,
      address: assignment.address,
      useActualAddress: false,
    });
    setIsAssignDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this employee assignment?")) {
      deleteAssignmentMutation.mutate(id);
    }
  };

  const handleDeassign = (id: number) => {
    setSelectedAssignmentId(id);
    setDeassignDate(new Date().toISOString().split('T')[0]); // Default to today
    setIsDeassignDialogOpen(true);
  };

  const confirmDeassign = () => {
    if (selectedAssignmentId && deassignDate) {
      deassignMutation.mutate({ id: selectedAssignmentId, deassignDate });
      setIsDeassignDialogOpen(false);
      setSelectedAssignmentId(null);
      setDeassignDate('');
    }
  };

  const resetForm = () => {
    setEditingAssignment(null);
    form.reset();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          {projectName && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setLocation('/client-compliances')}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Client Projects</span>
            </Button>
          )}
          <div>
            <h1 className="text-3xl font-bold">
              {projectName ? `Manage Employee - ${projectName}` : 'Manage Employee'}
            </h1>
            <p className="text-muted-foreground">
              {projectName 
                ? `Assign employees to this project and manage their assignments`
                : 'Assign and manage employee designations and locations'
              }
            </p>
          </div>
        </div>
        <Dialog 
          open={isAssignDialogOpen} 
          onOpenChange={(open) => {
            setIsAssignDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Assign Employee
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingAssignment ? "Update Employee Assignment" : "Assign Employee"}
              </DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="employeeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Employee</FormLabel>
                      <Select 
                        value={field.value.toString()} 
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select employee" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {employees.map((employee: any) => (
                            <SelectItem key={employee.id} value={employee.id.toString()}>
                              {employee.firstName} {employee.lastName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="designationId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Designation</FormLabel>
                      <Select 
                        value={field.value.toString()} 
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select designation" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {designations.map((designation: any) => (
                            <SelectItem key={designation.id} value={designation.id.toString()}>
                              {designation.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="assignDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assign Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="useActualAddress"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={!selectedEmployee?.address}
                        />
                      </FormControl>
                      <FormLabel className="text-sm font-normal">
                        Same as actual address
                      </FormLabel>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Employee Address</FormLabel>
                      <FormControl>
                        <textarea
                          {...field}
                          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="Enter employee address"
                          rows={3}
                          disabled={useActualAddress}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsAssignDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createAssignmentMutation.isPending || updateAssignmentMutation.isPending}
                  >
                    {editingAssignment ? "Update" : "Assign"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* De-assign Date Dialog */}
        <Dialog open={isDeassignDialogOpen} onOpenChange={setIsDeassignDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                De-assign Employee
              </DialogTitle>
              <DialogDescription>
                Please select the de-assignment date for this employee.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="deassign-date">De-assignment Date</Label>
                <Input
                  id="deassign-date"
                  type="date"
                  value={deassignDate}
                  onChange={(e) => setDeassignDate(e.target.value)}
                  className="w-full"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <Button 
                variant="outline" 
                onClick={() => setIsDeassignDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                onClick={confirmDeassign}
                disabled={!deassignDate || deassignMutation.isPending}
                className="bg-red-600 hover:bg-red-700"
              >
                {deassignMutation.isPending ? "De-assigning..." : "De-assign Employee"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Employee Assignments
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>S.No.</TableHead>
                  <TableHead>Employee Name</TableHead>
                  <TableHead>Designation</TableHead>
                  <TableHead>Address</TableHead>
                  <TableHead>Assign Date</TableHead>
                  <TableHead>De-assign Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      Loading assignments...
                    </TableCell>
                  </TableRow>
                ) : assignments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      No employee assignments found
                    </TableCell>
                  </TableRow>
                ) : (
                  assignments.map((assignment: EmployeeAssignment, index: number) => (
                    <TableRow key={assignment.id}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell className="font-medium">
                        {assignment.employee.firstName} {assignment.employee.lastName}
                      </TableCell>
                      <TableCell>{assignment.designation.title}</TableCell>
                      <TableCell className="max-w-xs truncate" title={assignment.address}>
                        {assignment.address}
                      </TableCell>
                      <TableCell>{assignment.assignDate}</TableCell>
                      <TableCell>
                        {assignment.deassignDate || "-"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={assignment.deassignDate ? "secondary" : "default"}>
                          {assignment.deassignDate ? "De-assigned" : "Active"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEdit(assignment)}>
                              <Edit className="w-4 h-4 mr-2" />
                              Update
                            </DropdownMenuItem>
                            {!assignment.deassignDate && (
                              <DropdownMenuItem onClick={() => handleDeassign(assignment.id)}>
                                <Users className="w-4 h-4 mr-2" />
                                De-assign
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem 
                              onClick={() => handleDelete(assignment.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}