import { db } from "./db";
import { jobs, companies, departments, users } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function seedJobs() {
  try {
    console.log("Seeding job postings...");

    // Get the company, departments, and admin user
    const [company] = await db.select().from(companies).limit(1);
    const [adminUser] = await db.select().from(users).where(eq(users.role, 'admin')).limit(1);
    const departmentsList = await db.select().from(departments);
    
    const engineeringDept = departmentsList.find(d => d.name === 'Engineering');
    const hrDept = departmentsList.find(d => d.name === 'Human Resources');
    const marketingDept = departmentsList.find(d => d.name === 'Marketing');

    if (!company || !adminUser || !engineeringDept || !hrDept || !marketingDept) {
      throw new Error("Required data not found. Please run the main seed script first.");
    }

    // Create job postings
    await db.insert(jobs).values([
      {
        companyId: company.id,
        title: "Senior Full Stack Developer",
        description: `We're looking for a talented Senior Full Stack Developer to join our growing engineering team. You'll be responsible for designing and implementing both frontend and backend solutions for our enterprise applications.

Key Responsibilities:
• Develop and maintain web applications using React, Node.js, and PostgreSQL
• Collaborate with product managers and designers to deliver high-quality features
• Participate in code reviews and mentor junior developers
• Ensure application performance, quality, and responsiveness
• Stay up-to-date with emerging technologies and best practices

What We Offer:
• Competitive salary and comprehensive benefits
• Flexible work arrangements and remote-friendly culture
• Professional development opportunities and conference attendance
• Collaborative and innovative work environment
• Opportunity to work on cutting-edge projects`,
        requirements: `Required Qualifications:
• Bachelor's degree in Computer Science or related field
• 5+ years of experience in full-stack development
• Strong proficiency in JavaScript, TypeScript, React, and Node.js
• Experience with relational databases (PostgreSQL preferred)
• Familiarity with cloud platforms (AWS, GCP, or Azure)
• Understanding of REST APIs and modern web development practices
• Experience with version control systems (Git)

Preferred Qualifications:
• Experience with Docker and containerization
• Knowledge of CI/CD pipelines
• Experience with testing frameworks (Jest, Cypress)
• Familiarity with agile development methodologies
• Previous experience in a leadership or mentoring role`,
        departmentId: engineeringDept.id,
        salaryMin: "95000",
        salaryMax: "135000",
        location: "San Francisco, CA / Remote",
        employmentType: "full-time",
        status: "active",
        postedBy: adminUser.id,
        postedAt: new Date("2025-01-15"),
        closingDate: new Date("2025-02-28"),
      },
      {
        companyId: company.id,
        title: "DevOps Engineer",
        description: `Join our infrastructure team as a DevOps Engineer and help us build scalable, reliable systems that power our applications. You'll work with cutting-edge technologies and be responsible for automation, monitoring, and continuous improvement of our development and deployment processes.

Key Responsibilities:
• Design and implement CI/CD pipelines
• Manage cloud infrastructure and containerized applications
• Monitor system performance and implement alerting solutions
• Automate deployment processes and infrastructure provisioning
• Collaborate with development teams to improve deployment workflows
• Ensure security best practices across all environments`,
        requirements: `Required Skills:
• 3+ years of experience in DevOps or Site Reliability Engineering
• Strong experience with cloud platforms (AWS, GCP, or Azure)
• Proficiency with containerization technologies (Docker, Kubernetes)
• Experience with Infrastructure as Code (Terraform, CloudFormation)
• Knowledge of CI/CD tools (Jenkins, GitLab CI, GitHub Actions)
• Understanding of monitoring and logging tools (Prometheus, Grafana, ELK stack)
• Strong scripting skills (Python, Bash, or similar)

Nice to Have:
• Experience with service mesh technologies (Istio, Linkerd)
• Knowledge of database administration
• Certification in cloud platforms
• Experience with microservices architecture`,
        departmentId: engineeringDept.id,
        salaryMin: "85000",
        salaryMax: "120000",
        location: "Austin, TX / Remote",
        employmentType: "full-time",
        status: "active",
        postedBy: adminUser.id,
        postedAt: new Date("2025-01-18"),
        closingDate: new Date("2025-03-15"),
      },
      {
        companyId: company.id,
        title: "HR Business Partner",
        description: `We're seeking an experienced HR Business Partner to work closely with our leadership team and employees to drive organizational effectiveness and employee engagement. This role is perfect for an HR professional who wants to make a strategic impact in a growing technology company.

Key Responsibilities:
• Partner with business leaders on workforce planning and organizational design
• Provide HR guidance on performance management, employee relations, and policy interpretation
• Lead talent acquisition efforts and develop recruitment strategies
• Design and implement employee development and retention programs
• Analyze HR metrics and provide insights to drive decision-making
• Support change management initiatives and organizational transformation`,
        requirements: `Required Qualifications:
• Bachelor's degree in Human Resources, Business Administration, or related field
• 5+ years of HR experience with at least 2 years as an HR Business Partner
• Strong knowledge of employment law and HR best practices
• Experience with HRIS systems and HR analytics
• Excellent communication and interpersonal skills
• Demonstrated ability to influence and build relationships at all organizational levels

Preferred Qualifications:
• PHR or SHRM certification
• Experience in a technology or fast-paced startup environment
• Project management experience
• Experience with performance management systems
• Master's degree in HR, Business, or related field`,
        departmentId: hrDept.id,
        salaryMin: "75000",
        salaryMax: "95000",
        location: "New York, NY / Hybrid",
        employmentType: "full-time",
        status: "active",
        postedBy: adminUser.id,
        postedAt: new Date("2025-01-20"),
        closingDate: new Date("2025-02-20"),
      },
      {
        companyId: company.id,
        title: "Digital Marketing Specialist",
        description: `Join our marketing team as a Digital Marketing Specialist and help drive our online presence and lead generation efforts. You'll work across multiple digital channels to create engaging campaigns that attract and convert our target audience.

Key Responsibilities:
• Develop and execute digital marketing campaigns across multiple channels
• Manage social media accounts and create engaging content
• Optimize website content for search engines (SEO)
• Create and manage PPC campaigns on Google Ads and social platforms
• Analyze campaign performance and provide actionable insights
• Collaborate with design team on marketing materials and creatives
• Track and report on key marketing metrics and ROI`,
        requirements: `Required Skills:
• Bachelor's degree in Marketing, Communications, or related field
• 2-4 years of experience in digital marketing
• Proficiency with Google Analytics, Google Ads, and social media platforms
• Experience with email marketing platforms (Mailchimp, HubSpot, etc.)
• Strong analytical skills and experience with marketing metrics
• Excellent written and verbal communication skills
• Creative thinking and problem-solving abilities

Preferred Qualifications:
• Google Ads and Analytics certifications
• Experience with marketing automation tools
• Knowledge of HTML/CSS and basic web development
• Experience with A/B testing and conversion optimization
• Familiarity with CRM systems
• Experience in B2B or SaaS marketing`,
        departmentId: marketingDept.id,
        salaryMin: "50000",
        salaryMax: "70000",
        location: "Chicago, IL / Remote",
        employmentType: "full-time",
        status: "active",
        postedBy: adminUser.id,
        postedAt: new Date("2025-01-19"),
        closingDate: new Date("2025-02-25"),
      },
      {
        companyId: company.id,
        title: "Frontend Developer (React)",
        description: `We're looking for a passionate Frontend Developer to join our product team and help build beautiful, responsive user interfaces for our web applications. You'll work closely with designers and backend developers to create exceptional user experiences.

Key Responsibilities:
• Develop responsive web applications using React and modern JavaScript
• Collaborate with UX/UI designers to implement pixel-perfect designs
• Optimize applications for maximum speed and scalability
• Write clean, maintainable, and well-tested code
• Participate in code reviews and contribute to team knowledge sharing
• Stay current with frontend development trends and best practices`,
        requirements: `Required Skills:
• Bachelor's degree in Computer Science, Web Development, or related field
• 2-4 years of frontend development experience
• Strong proficiency in React, JavaScript (ES6+), and TypeScript
• Experience with CSS3, HTML5, and responsive design
• Familiarity with state management libraries (Redux, Context API)
• Understanding of RESTful APIs and asynchronous programming
• Experience with version control (Git)

Nice to Have:
• Experience with Next.js or other React frameworks
• Knowledge of testing frameworks (Jest, React Testing Library)
• Familiarity with build tools (Webpack, Vite)
• Understanding of accessibility standards (WCAG)
• Experience with design tools (Figma, Adobe Creative Suite)`,
        departmentId: engineeringDept.id,
        salaryMin: "65000",
        salaryMax: "90000",
        location: "Remote",
        employmentType: "full-time",
        status: "draft",
        postedBy: adminUser.id,
        postedAt: null,
        closingDate: null,
      },
    ]);

    console.log("✅ Job postings seeded successfully!");
    console.log("Created 5 job postings across Engineering, HR, and Marketing departments");

  } catch (error) {
    console.error("Error seeding jobs:", error);
    throw error;
  }
}

// Export for manual use