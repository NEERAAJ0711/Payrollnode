import { 
  companies, users, departments, employees, employeeProfiles, jobs, jobApplications, attendance,
  monthlyAttendance, faceTemplates, attendanceLocations, employeePayroll, employeeSalaryStructures,
  permissions, rolePermissions, permissionRequests, userPermissions, permissionTemplates, userActivities, employmentHistory, kycDetails, familyDetails,
  interviews, jobOffers, monthlyPayroll, payrollRecords, leaveRequests, advanceRequests, approvalWorkflows,
  designations, branches, locations, costCenters, biometricMachines, holidays, leavePolicies,
  clients, complianceSetups, compliancesData, employeeAssignments,
  salaryComponents, companySalaryComponentConfig, employeeSalaryComponentValues,
  type Company, type InsertCompany, type User, type InsertUser, 
  type Department, type InsertDepartment, type Employee, type InsertEmployee,
  type EmployeeProfile, type InsertEmployeeProfile, type EmployeePayroll, type InsertEmployeePayroll,
  type SelectEmployeeSalaryStructure, type InsertEmployeeSalaryStructure,
  type Job, type InsertJob, type JobApplication, type InsertJobApplication,
  type Attendance, type InsertAttendance, type MonthlyAttendance, type InsertMonthlyAttendance,
  type FaceTemplate, type InsertFaceTemplate, type AttendanceLocation, type InsertAttendanceLocation,
  type Permission, type InsertPermission, type UserPermission, type InsertUserPermission,
  type PermissionTemplate, type InsertPermissionTemplate,
  type RolePermission, type InsertRolePermission, type PermissionRequest, 
  type InsertPermissionRequest, type UserActivity, type InsertUserActivity,
  type EmploymentHistory, type InsertEmploymentHistory, type KycDetails, 
  type InsertKycDetails, type FamilyDetails, type InsertFamilyDetails,
  type Interview, type InsertInterview, type JobOffer, type InsertJobOffer,
  type MonthlyPayroll, type InsertMonthlyPayroll, type PayrollRecord, type InsertPayrollRecord,
  type LeaveRequest, type InsertLeaveRequest, type AdvanceRequest, type InsertAdvanceRequest,
  type ApprovalWorkflow, type InsertApprovalWorkflow,
  type Client, type InsertClient, type ComplianceSetup, type InsertComplianceSetup,
  type CompliancesData, type InsertCompliancesData, type EmployeeAssignment, type InsertEmployeeAssignment,
  type SalaryComponent, type InsertSalaryComponent, type CompanySalaryComponentConfig, type InsertCompanySalaryComponentConfig,
  type EmployeeSalaryComponentValues, type InsertEmployeeSalaryComponentValues
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, count, sql, or, gt } from "drizzle-orm";
import bcrypt from "bcrypt";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  authenticateUser(email: string, password: string): Promise<User | null>;

  // Company methods
  getCompany(id: number): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;
  getCompaniesByUser(userId: number): Promise<Company[]>;

  // Employee methods
  getEmployee(id: number): Promise<Employee | undefined>;
  getEmployeeByUserId(userId: number): Promise<Employee | undefined>;
  getEmployeesByCompany(companyId: number): Promise<Employee[]>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, employee: Partial<Employee>): Promise<Employee>;
  deleteEmployee(id: number): Promise<void>;

  // Employee Payroll methods
  getEmployeePayroll(employeeId: number): Promise<EmployeePayroll | undefined>;
  createEmployeePayroll(payroll: InsertEmployeePayroll): Promise<EmployeePayroll>;
  updateEmployeePayroll(employeeId: number, payroll: Partial<EmployeePayroll>): Promise<EmployeePayroll>;
  deleteEmployeePayroll(employeeId: number): Promise<void>;

  // Employee Salary Structure methods (month-wise historical tracking)
  getEmployeeSalaryStructure(employeeId: number, year: number, month: number): Promise<SelectEmployeeSalaryStructure | undefined>;
  upsertEmployeeSalaryStructure(structure: InsertEmployeeSalaryStructure): Promise<SelectEmployeeSalaryStructure>;
  getLatestEmployeeSalaryStructure(employeeId: number): Promise<SelectEmployeeSalaryStructure | undefined>;
  getEmployeeSalaryStructureHistory(employeeId: number, limit?: number): Promise<SelectEmployeeSalaryStructure[]>;
  getCompleteSalaryHistoryFromJoining(employeeId: number): Promise<SelectEmployeeSalaryStructure[]>;
  getFutureSalaryStructures(employeeId: number, fromYear: number, fromMonth: number): Promise<SelectEmployeeSalaryStructure[]>;

  // Department methods
  getDepartment(id: number): Promise<Department | undefined>;
  getDepartmentsByCompany(companyId: number): Promise<Department[]>;
  createDepartment(department: InsertDepartment): Promise<Department>;
  updateDepartment(id: number, department: Partial<Department>): Promise<Department>;
  deleteDepartment(id: number): Promise<void>;

  // Job methods
  getJob(id: number): Promise<Job | undefined>;
  getJobsByCompany(companyId: number): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, job: Partial<Job>): Promise<Job>;
  deleteJob(id: number): Promise<void>;

  // Job Application methods
  getJobApplication(id: number): Promise<JobApplication | undefined>;
  getApplicationsByJob(jobId: number): Promise<JobApplication[]>;
  getApplicationsByCompany(companyId: number): Promise<JobApplication[]>;
  createJobApplication(application: InsertJobApplication): Promise<JobApplication>;
  updateJobApplication(id: number, application: Partial<JobApplication>): Promise<JobApplication>;

  // Attendance methods
  getAttendanceByEmployee(employeeId: number, date?: Date): Promise<Attendance[]>;
  getAttendanceByCompany(companyId: number, date?: Date): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendance: Partial<Attendance>): Promise<Attendance>;
  markCheckIn(employeeId: number, checkInData: {
    latitude?: number;
    longitude?: number;
    faceImage?: string;
    deviceInfo?: string;
    ipAddress?: string;
  }): Promise<Attendance>;
  markCheckOut(attendanceId: number, checkOutData: {
    latitude?: number;
    longitude?: number;
  }): Promise<Attendance>;
  
  // Monthly attendance methods
  getMonthlyAttendance(employeeId: number, year: number, month: number): Promise<MonthlyAttendance | undefined>;
  calculateMonthlyAttendance(employeeId: number, companyId: number, year: number, month: number): Promise<MonthlyAttendance>;
  
  // Face template methods
  getFaceTemplate(employeeId: number): Promise<FaceTemplate | undefined>;
  createFaceTemplate(insertFaceTemplate: InsertFaceTemplate): Promise<FaceTemplate>;
  updateFaceTemplate(employeeId: number, templateData: string): Promise<FaceTemplate>;
  
  // Location methods
  getAttendanceLocations(companyId: number): Promise<AttendanceLocation[]>;
  createAttendanceLocation(insertLocation: InsertAttendanceLocation): Promise<AttendanceLocation>;
  validateLocation(companyId: number, latitude: number, longitude: number): Promise<AttendanceLocation | null>;

  // Dashboard stats
  getDashboardStats(companyId: number): Promise<{
    totalEmployees: number;
    activeJobs: number;
    pendingApplications: number;
    todayAttendance: number;
  }>;

  // User management methods
  getUsersByCompany(companyId: number): Promise<User[]>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: number, user: Partial<User>): Promise<User>;
  deleteUser(id: number): Promise<void>;
  
  // Aadhaar verification methods
  checkEmployeeByAadhaar(aadhaarNo: string): Promise<Employee | null>;
  getEmployeeStatusByAadhaar(aadhaarNo: string): Promise<{
    isEmployeeInCompany: boolean;
    employeeData?: Employee;
    companyData?: Company;
  }>;
  
  // Company management methods
  getAllCompanies(): Promise<Company[]>;
  updateCompany(id: number, company: Partial<Company>): Promise<Company>;
  deleteCompany(id: number): Promise<void>;

  // Permission methods
  getPermissions(): Promise<Permission[]>;
  createPermission(permission: InsertPermission): Promise<Permission>;
  getRolePermissions(role: string, companyId?: number): Promise<RolePermission[]>;
  createRolePermission(rolePermission: InsertRolePermission): Promise<RolePermission>;
  deleteRolePermission(id: number): Promise<void>;

  // Permission request methods
  getPermissionRequests(companyId?: number): Promise<PermissionRequest[]>;
  createPermissionRequest(permissionRequest: InsertPermissionRequest): Promise<PermissionRequest>;
  updatePermissionRequest(id: number, permissionRequest: Partial<PermissionRequest>): Promise<PermissionRequest>;
  getPermissionRequestsByUser(userId: number): Promise<PermissionRequest[]>;

  // User activity methods
  createUserActivity(activity: InsertUserActivity): Promise<UserActivity>;
  getUserActivities(companyId?: number, userId?: number): Promise<UserActivity[]>;

  // Employee profile methods
  createEmployeeProfile(profileData: InsertEmployeeProfile): Promise<EmployeeProfile>;
  getEmployeeProfileByUserId(userId: number): Promise<EmployeeProfile | undefined>;
  updateEmployeeProfile(userId: number, profileData: Partial<EmployeeProfile>): Promise<EmployeeProfile>;
  
  // Employment history methods
  getEmploymentHistoryByProfile(profileId: number): Promise<EmploymentHistory[]>;
  createEmploymentHistory(historyData: InsertEmploymentHistory): Promise<EmploymentHistory>;
  updateEmploymentHistory(id: number, historyData: Partial<EmploymentHistory>): Promise<EmploymentHistory>;
  deleteEmploymentHistory(id: number): Promise<void>;
  
  // KYC details methods
  getKycDetailsByProfile(profileId: number): Promise<KycDetails | undefined>;
  createKycDetails(kycData: InsertKycDetails): Promise<KycDetails>;
  updateKycDetails(profileId: number, kycData: Partial<KycDetails>): Promise<KycDetails>;
  
  // Employee portal methods
  getEmployeeProfileByAadhaar(aadhaarNo: string): Promise<EmployeeProfile | undefined>;
  
  // Family details methods
  getFamilyDetailsByProfile(profileId: number): Promise<FamilyDetails[]>;
  createFamilyDetails(familyData: InsertFamilyDetails): Promise<FamilyDetails>;
  updateFamilyDetails(id: number, familyData: Partial<FamilyDetails>): Promise<FamilyDetails>;
  deleteFamilyDetails(id: number): Promise<void>;

  // Leave Request methods
  getLeaveRequest(id: number): Promise<LeaveRequest | undefined>;
  getLeaveRequestsByCompany(companyId: number): Promise<LeaveRequest[]>;
  getLeaveRequestsByEmployee(employeeId: number): Promise<LeaveRequest[]>;
  createLeaveRequest(request: InsertLeaveRequest): Promise<LeaveRequest>;
  updateLeaveRequest(id: number, updates: Partial<LeaveRequest>): Promise<LeaveRequest>;
  approveLeaveRequest(id: number, level: 1 | 2 | 3, approverId: number, comments?: string): Promise<LeaveRequest>;
  rejectLeaveRequest(id: number, rejectedById: number, reason: string): Promise<LeaveRequest>;

  // Advance Request methods
  getAdvanceRequest(id: number): Promise<AdvanceRequest | undefined>;
  getAdvanceRequestsByCompany(companyId: number): Promise<AdvanceRequest[]>;
  getAdvanceRequestsByEmployee(employeeId: number): Promise<AdvanceRequest[]>;
  createAdvanceRequest(request: InsertAdvanceRequest): Promise<AdvanceRequest>;
  updateAdvanceRequest(id: number, updates: Partial<AdvanceRequest>): Promise<AdvanceRequest>;
  approveAdvanceRequest(id: number, level: 1 | 2 | 3, approverId: number, comments?: string): Promise<AdvanceRequest>;
  rejectAdvanceRequest(id: number, rejectedById: number, reason: string): Promise<AdvanceRequest>;
  markAdvancePaid(id: number, paidAmount: string, paymentMethod: string, reference?: string): Promise<AdvanceRequest>;

  // Approval Workflow methods
  getApprovalWorkflow(companyId: number, requestType: string): Promise<ApprovalWorkflow | undefined>;
  createApprovalWorkflow(workflow: InsertApprovalWorkflow): Promise<ApprovalWorkflow>;
  updateApprovalWorkflow(id: number, updates: Partial<ApprovalWorkflow>): Promise<ApprovalWorkflow>;

  // Enhanced Permission Management methods
  getAllPermissions(): Promise<Permission[]>;
  getPermissionsByCategory(category: string): Promise<Permission[]>;
  getPermissionsByModule(module: string): Promise<Permission[]>;
  createPermission(permission: InsertPermission): Promise<Permission>;
  updatePermission(id: number, permission: Partial<Permission>): Promise<Permission>;
  deletePermission(id: number): Promise<void>;

  // User Permission methods
  getUserPermissions(userId: number, companyId: number): Promise<UserPermission[]>;
  hasUserPermission(userId: number, permissionName: string, companyId: number): Promise<boolean>;
  grantUserPermission(userPermission: InsertUserPermission): Promise<UserPermission>;
  revokeUserPermission(userId: number, permissionId: number, companyId: number): Promise<void>;
  getUsersWithPermission(permissionName: string, companyId: number): Promise<User[]>;

  // Enhanced Permission Request methods
  getPermissionRequestsEnhanced(companyId: number): Promise<PermissionRequest[]>;
  getPermissionRequestsByUserEnhanced(userId: number): Promise<PermissionRequest[]>;
  getPendingPermissionRequests(companyId: number): Promise<PermissionRequest[]>;
  createPermissionRequestEnhanced(request: InsertPermissionRequest): Promise<PermissionRequest>;
  updatePermissionRequestEnhanced(id: number, request: Partial<PermissionRequest>): Promise<PermissionRequest>;
  approvePermissionRequestLevel(id: number, reviewerId: number, level: 'level1' | 'level2' | 'final', comments?: string): Promise<PermissionRequest>;
  rejectPermissionRequestLevel(id: number, reviewerId: number, level: 'level1' | 'level2' | 'final', comments?: string): Promise<PermissionRequest>;

  // Role Permission methods
  getRolePermissionsEnhanced(role: string, companyId?: number): Promise<RolePermission[]>;
  assignRolePermission(rolePermission: InsertRolePermission): Promise<RolePermission>;
  removeRolePermission(role: string, permissionId: number, companyId?: number): Promise<void>;

  // Permission Template methods
  getPermissionTemplates(role?: string): Promise<PermissionTemplate[]>;
  createPermissionTemplate(template: InsertPermissionTemplate): Promise<PermissionTemplate>;
  updatePermissionTemplate(id: number, template: Partial<PermissionTemplate>): Promise<PermissionTemplate>;
  deletePermissionTemplate(id: number): Promise<void>;
  applyPermissionTemplate(templateId: number, userId: number, companyId: number, grantedBy: number): Promise<UserPermission[]>;

  // Company Settings methods
  // Biometric Machine methods
  getBiometricMachinesByCompany(companyId: number): Promise<any[]>;
  createBiometricMachine(machine: any): Promise<any>;
  updateBiometricMachine(id: number, machine: any): Promise<any>;
  deleteBiometricMachine(id: number): Promise<void>;

  // Holiday methods
  getHolidaysByCompany(companyId: number): Promise<any[]>;
  createHoliday(holiday: any): Promise<any>;
  updateHoliday(id: number, holiday: any): Promise<any>;
  deleteHoliday(id: number): Promise<void>;

  // Leave Policy methods
  getLeavePoliciesByCompany(companyId: number): Promise<any[]>;
  createLeavePolicy(policy: any): Promise<any>;
  updateLeavePolicy(id: number, policy: any): Promise<any>;
  deleteLeavePolicy(id: number): Promise<void>;

  // Designation methods
  getDesignationsByCompany(companyId: number): Promise<any[]>;
  createDesignation(designation: any): Promise<any>;
  updateDesignation(id: number, designation: any): Promise<any>;
  deleteDesignation(id: number): Promise<void>;

  // Branch methods
  getBranchesByCompany(companyId: number): Promise<any[]>;
  createBranch(branch: any): Promise<any>;
  updateBranch(id: number, branch: any): Promise<any>;
  deleteBranch(id: number): Promise<void>;

  // Location methods  
  getLocationsByCompany(companyId: number): Promise<any[]>;
  createLocation(location: any): Promise<any>;
  updateLocation(id: number, location: any): Promise<any>;
  deleteLocation(id: number): Promise<void>;

  // Cost Center methods
  getCostCentersByCompany(companyId: number): Promise<any[]>;
  createCostCenter(costCenter: any): Promise<any>;
  updateCostCenter(id: number, costCenter: any): Promise<any>;
  deleteCostCenter(id: number): Promise<void>;

  // Client Compliances methods
  getClientsByCompany(companyId: number): Promise<Client[]>;
  createClient(clientData: InsertClient): Promise<Client>;
  updateClient(id: number, clientData: Partial<Client>): Promise<Client>;
  deleteClient(id: number): Promise<void>;

  // Compliance Setup methods
  getComplianceSetupsByCompany(companyId: number): Promise<ComplianceSetup[]>;
  createComplianceSetup(setupData: InsertComplianceSetup): Promise<ComplianceSetup>;
  updateComplianceSetup(id: number, setupData: Partial<ComplianceSetup>): Promise<ComplianceSetup>;
  deleteComplianceSetup(id: number): Promise<void>;

  // Compliances Data methods
  getCompliancesDataByCompany(companyId: number): Promise<CompliancesData[]>;
  createCompliancesData(complianceData: InsertCompliancesData): Promise<CompliancesData>;
  updateCompliancesData(id: number, complianceData: Partial<CompliancesData>): Promise<CompliancesData>;
  deleteCompliancesData(id: number): Promise<void>;

  // Employee Assignment methods
  getEmployeeAssignmentsByCompany(companyId: number): Promise<EmployeeAssignment[]>;
  createEmployeeAssignment(assignmentData: InsertEmployeeAssignment): Promise<EmployeeAssignment>;
  updateEmployeeAssignment(id: number, assignmentData: Partial<EmployeeAssignment>): Promise<EmployeeAssignment>;
  deleteEmployeeAssignment(id: number): Promise<void>;

  // Salary Component methods
  getSalaryComponents(): Promise<SalaryComponent[]>;
  createSalaryComponent(component: InsertSalaryComponent): Promise<SalaryComponent>;
  updateSalaryComponent(id: number, component: Partial<SalaryComponent>): Promise<SalaryComponent>;
  deleteSalaryComponent(id: number): Promise<void>;

  // Company Salary Component Configuration methods
  getCompanySalaryComponentConfig(companyId: number, entryMode?: string): Promise<CompanySalaryComponentConfig[]>;
  createCompanySalaryComponentConfig(config: InsertCompanySalaryComponentConfig): Promise<CompanySalaryComponentConfig>;
  updateCompanySalaryComponentConfig(id: number, config: Partial<CompanySalaryComponentConfig>): Promise<CompanySalaryComponentConfig>;
  deleteCompanySalaryComponentConfig(id: number): Promise<void>;
  upsertCompanySalaryComponentConfig(config: InsertCompanySalaryComponentConfig): Promise<CompanySalaryComponentConfig>;

  // Employee Salary Component Values methods
  getEmployeeSalaryComponentValues(structureId: number): Promise<EmployeeSalaryComponentValues[]>;
  createEmployeeSalaryComponentValues(values: InsertEmployeeSalaryComponentValues): Promise<EmployeeSalaryComponentValues>;
  updateEmployeeSalaryComponentValues(id: number, values: Partial<EmployeeSalaryComponentValues>): Promise<EmployeeSalaryComponentValues>;
  deleteEmployeeSalaryComponentValues(id: number): Promise<void>;
  bulkCreateEmployeeSalaryComponentValues(values: InsertEmployeeSalaryComponentValues[]): Promise<EmployeeSalaryComponentValues[]>;
  deleteEmployeeSalaryComponentValuesByStructure(structureId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Check if username already exists and make it unique if needed
    let finalUsername = insertUser.username;
    try {
      const existingUser = await this.getUserByUsername(insertUser.username);
      if (existingUser) {
        // Generate a unique username by appending a number
        let counter = 1;
        let newUsername = `${insertUser.username}${counter}`;
        let userExists = await this.getUserByUsername(newUsername);
        while (userExists) {
          counter++;
          newUsername = `${insertUser.username}${counter}`;
          userExists = await this.getUserByUsername(newUsername);
        }
        finalUsername = newUsername;
      }
    } catch (error) {
      console.log('Error checking username:', error);
    }

    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const [user] = await db
      .insert(users)
      .values({ ...insertUser, username: finalUsername, password: hashedPassword })
      .returning();
    return user;
  }

  async authenticateUser(email: string, password: string): Promise<User | null> {
    const user = await this.getUserByEmail(email);
    if (!user || !await bcrypt.compare(password, user.password)) {
      return null;
    }
    return user;
  }

  async getCompany(id: number): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.id, id));
    return company || undefined;
  }

  async createCompany(insertCompany: InsertCompany): Promise<Company> {
    const [company] = await db
      .insert(companies)
      .values(insertCompany)
      .returning();
    return company;
  }

  async getCompaniesByUser(userId: number): Promise<Company[]> {
    const user = await this.getUser(userId);
    if (!user?.companyId) return [];
    const company = await this.getCompany(user.companyId);
    return company ? [company] : [];
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee || undefined;
  }

  async getEmployeeByUserId(userId: number): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.userId, userId));
    return employee || undefined;
  }

  async getEmployeesByCompany(companyId: number): Promise<Employee[]> {
    return await db.select().from(employees).where(eq(employees.companyId, companyId)).orderBy(desc(employees.createdAt));
  }

  async createEmployee(insertEmployee: InsertEmployee): Promise<Employee> {
    const [employee] = await db
      .insert(employees)
      .values(insertEmployee)
      .returning();
    return employee;
  }

  async updateEmployee(id: number, employee: Partial<Employee>): Promise<Employee> {
    const [updatedEmployee] = await db
      .update(employees)
      .set({ ...employee, updatedAt: new Date() })
      .where(eq(employees.id, id))
      .returning();
    return updatedEmployee;
  }

  async deleteEmployee(id: number): Promise<void> {
    await db.delete(employees).where(eq(employees.id, id));
  }

  // Employee Payroll methods
  async getEmployeePayroll(employeeId: number): Promise<EmployeePayroll | undefined> {
    const [payroll] = await db.select().from(employeePayroll).where(eq(employeePayroll.employeeId, employeeId));
    return payroll || undefined;
  }

  async createEmployeePayroll(payroll: InsertEmployeePayroll): Promise<EmployeePayroll> {
    const [newPayroll] = await db
      .insert(employeePayroll)
      .values(payroll)
      .returning();
    return newPayroll;
  }

  async updateEmployeePayroll(employeeId: number, payroll: Partial<EmployeePayroll>): Promise<EmployeePayroll> {
    const [updatedPayroll] = await db
      .update(employeePayroll)
      .set(payroll)
      .where(eq(employeePayroll.employeeId, employeeId))
      .returning();
    return updatedPayroll;
  }

  async deleteEmployeePayroll(employeeId: number): Promise<void> {
    await db.delete(employeePayroll).where(eq(employeePayroll.employeeId, employeeId));
  }

  // Employee Salary Structure methods (month-wise historical tracking)
  async getEmployeeSalaryStructure(employeeId: number, year: number, month: number): Promise<SelectEmployeeSalaryStructure | undefined> {
    const [structure] = await db
      .select()
      .from(employeeSalaryStructures)
      .where(
        and(
          eq(employeeSalaryStructures.employeeId, employeeId),
          eq(employeeSalaryStructures.year, year),
          eq(employeeSalaryStructures.month, month)
        )
      );
    return structure || undefined;
  }

  async upsertEmployeeSalaryStructure(structure: InsertEmployeeSalaryStructure): Promise<SelectEmployeeSalaryStructure> {
    // Check if a record already exists for this employee, year, and month
    const existingStructure = await this.getEmployeeSalaryStructure(
      structure.employeeId,
      structure.year,
      structure.month
    );

    if (existingStructure) {
      // Update existing record
      const [updatedStructure] = await db
        .update(employeeSalaryStructures)
        .set({ ...structure, updatedAt: new Date() })
        .where(
          and(
            eq(employeeSalaryStructures.employeeId, structure.employeeId),
            eq(employeeSalaryStructures.year, structure.year),
            eq(employeeSalaryStructures.month, structure.month)
          )
        )
        .returning();
      return updatedStructure;
    } else {
      // Insert new record
      const [newStructure] = await db
        .insert(employeeSalaryStructures)
        .values(structure)
        .returning();
      return newStructure;
    }
  }

  async getLatestEmployeeSalaryStructure(employeeId: number): Promise<SelectEmployeeSalaryStructure | undefined> {
    const [latestStructure] = await db
      .select()
      .from(employeeSalaryStructures)
      .where(eq(employeeSalaryStructures.employeeId, employeeId))
      .orderBy(desc(employeeSalaryStructures.year), desc(employeeSalaryStructures.month))
      .limit(1);
    return latestStructure || undefined;
  }

  async getEmployeeSalaryStructureHistory(employeeId: number, limit: number = 12): Promise<SelectEmployeeSalaryStructure[]> {
    return await db
      .select()
      .from(employeeSalaryStructures)
      .where(eq(employeeSalaryStructures.employeeId, employeeId))
      .orderBy(desc(employeeSalaryStructures.year), desc(employeeSalaryStructures.month))
      .limit(limit);
  }

  async getCompleteSalaryHistoryFromJoining(employeeId: number): Promise<SelectEmployeeSalaryStructure[]> {
    // Get employee to find hire date
    const employee = await this.getEmployee(employeeId);
    if (!employee) {
      return [];
    }

    // Get all existing salary structures for this employee
    const existingStructures = await db
      .select()
      .from(employeeSalaryStructures)
      .where(eq(employeeSalaryStructures.employeeId, employeeId))
      .orderBy(employeeSalaryStructures.year, employeeSalaryStructures.month);

    // If no salary structures exist, return empty
    if (existingStructures.length === 0) {
      return [];
    }

    // Determine starting date - use hire date if available, otherwise earliest salary structure
    let joiningDate: Date;
    if (employee.hireDate) {
      joiningDate = new Date(employee.hireDate);
    } else {
      // Fallback to earliest salary structure date if no hire date
      const earliestStructure = existingStructures[0]; // Already sorted by year, month
      joiningDate = new Date(earliestStructure.year, earliestStructure.month - 1, 1); // month is 1-indexed
      console.log(`⚠️  No hire date for employee ${employeeId}, using earliest salary structure: ${earliestStructure.year}-${earliestStructure.month}`);
    }
    const currentDate = new Date();
    const completeHistory: SelectEmployeeSalaryStructure[] = [];
    
    // Start from joining month
    let currentYear = joiningDate.getFullYear();
    let currentMonth = joiningDate.getMonth() + 1; // JavaScript months are 0-indexed

    // Generate entries for each month from joining to current month
    while (currentYear < currentDate.getFullYear() || 
           (currentYear === currentDate.getFullYear() && currentMonth <= currentDate.getMonth() + 1)) {
      
      // Find existing structure for this month
      const existingStructure = existingStructures.find(
        s => s.year === currentYear && s.month === currentMonth
      );

      if (existingStructure) {
        // Use the actual salary structure for this month
        completeHistory.push(existingStructure);
      } else {
        // Find the most recent salary structure before this month
        const mostRecentStructure = existingStructures
          .filter(s => 
            (s.year < currentYear) || 
            (s.year === currentYear && s.month < currentMonth)
          )
          .sort((a, b) => {
            if (a.year !== b.year) return b.year - a.year;
            return b.month - a.month;
          })[0];

        let structureToUse = mostRecentStructure;

        // If no prior structure exists (early months), use the earliest available structure
        if (!structureToUse && existingStructures.length > 0) {
          structureToUse = existingStructures
            .sort((a, b) => {
              if (a.year !== b.year) return a.year - b.year;
              return a.month - b.month;
            })[0];
        }

        if (structureToUse) {
          // Create a derived structure for this month using the reference data
          const derivedStructure: SelectEmployeeSalaryStructure = {
            ...structureToUse,
            id: 0, // Indicate this is a derived entry
            year: currentYear,
            month: currentMonth,
            createdAt: new Date(),
            updatedAt: new Date(),
          };
          completeHistory.push(derivedStructure);
        }
      }

      // Move to next month
      currentMonth++;
      if (currentMonth > 12) {
        currentMonth = 1;
        currentYear++;
      }
    }

    // Return in descending order (most recent first) for consistency with other functions
    return completeHistory.reverse();
  }

  async getFutureSalaryStructures(employeeId: number, fromYear: number, fromMonth: number): Promise<SelectEmployeeSalaryStructure[]> {
    return await db
      .select()
      .from(employeeSalaryStructures)
      .where(
        and(
          eq(employeeSalaryStructures.employeeId, employeeId),
          or(
            gt(employeeSalaryStructures.year, fromYear),
            and(
              eq(employeeSalaryStructures.year, fromYear),
              gt(employeeSalaryStructures.month, fromMonth)
            )
          )
        )
      )
      .orderBy(employeeSalaryStructures.year, employeeSalaryStructures.month);
  }

  async getDepartment(id: number): Promise<Department | undefined> {
    const [department] = await db.select().from(departments).where(eq(departments.id, id));
    return department || undefined;
  }

  async getDepartmentsByCompany(companyId: number): Promise<Department[]> {
    return await db.select().from(departments).where(eq(departments.companyId, companyId)).orderBy(departments.name);
  }

  async getAllDepartments(): Promise<Department[]> {
    return await db.select().from(departments);
  }

  async createDepartment(insertDepartment: InsertDepartment): Promise<Department> {
    const [department] = await db
      .insert(departments)
      .values(insertDepartment)
      .returning();
    return department;
  }

  async updateDepartment(id: number, department: Partial<Department>): Promise<Department> {
    const [updatedDepartment] = await db
      .update(departments)
      .set({ ...department, updatedAt: new Date() })
      .where(eq(departments.id, id))
      .returning();
    return updatedDepartment;
  }

  async deleteDepartment(id: number): Promise<void> {
    await db.delete(departments).where(eq(departments.id, id));
  }

  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job || undefined;
  }

  async getJobsByCompany(companyId: number): Promise<Job[]> {
    return await db.select().from(jobs).where(eq(jobs.companyId, companyId)).orderBy(desc(jobs.createdAt));
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db
      .insert(jobs)
      .values(insertJob)
      .returning();
    return job;
  }

  async updateJob(id: number, job: Partial<Job>): Promise<Job> {
    const [updatedJob] = await db
      .update(jobs)
      .set({ ...job, updatedAt: new Date() })
      .where(eq(jobs.id, id))
      .returning();
    return updatedJob;
  }

  async deleteJob(id: number): Promise<void> {
    await db.delete(jobs).where(eq(jobs.id, id));
  }

  async getJobApplication(id: number): Promise<JobApplication | undefined> {
    const [application] = await db.select().from(jobApplications).where(eq(jobApplications.id, id));
    return application || undefined;
  }

  async getApplicationsByJob(jobId: number): Promise<JobApplication[]> {
    return await db.select().from(jobApplications).where(eq(jobApplications.jobId, jobId)).orderBy(desc(jobApplications.appliedAt));
  }

  async getApplicationsByCompany(companyId: number): Promise<JobApplication[]> {
    return await db
      .select({
        id: jobApplications.id,
        jobId: jobApplications.jobId,
        applicantName: jobApplications.applicantName,
        applicantEmail: jobApplications.applicantEmail,
        applicantPhone: jobApplications.applicantPhone,
        resume: jobApplications.resume,
        coverLetter: jobApplications.coverLetter,
        status: jobApplications.status,
        appliedAt: jobApplications.appliedAt,
        reviewedAt: jobApplications.reviewedAt,
        reviewedBy: jobApplications.reviewedBy,
        notes: jobApplications.notes,
        createdAt: jobApplications.createdAt,
        updatedAt: jobApplications.updatedAt,
      })
      .from(jobApplications)
      .innerJoin(jobs, eq(jobApplications.jobId, jobs.id))
      .where(eq(jobs.companyId, companyId))
      .orderBy(desc(jobApplications.appliedAt));
  }

  async createJobApplication(insertApplication: InsertJobApplication): Promise<JobApplication> {
    const [application] = await db
      .insert(jobApplications)
      .values(insertApplication)
      .returning();
    return application;
  }

  async updateJobApplication(id: number, application: Partial<JobApplication>): Promise<JobApplication> {
    const [updatedApplication] = await db
      .update(jobApplications)
      .set({ ...application, updatedAt: new Date() })
      .where(eq(jobApplications.id, id))
      .returning();
    return updatedApplication;
  }

  async getAttendanceByEmployee(employeeId: number, date?: Date): Promise<Attendance[]> {
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      
      return await db.select().from(attendance).where(
        and(
          eq(attendance.employeeId, employeeId),
          sql`${attendance.date} >= ${startOfDay}`,
          sql`${attendance.date} <= ${endOfDay}`
        )
      ).orderBy(desc(attendance.date));
    }
    
    return await db.select().from(attendance).where(eq(attendance.employeeId, employeeId)).orderBy(desc(attendance.date));
  }

  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const [attendanceRecord] = await db
      .insert(attendance)
      .values(insertAttendance)
      .returning();
    return attendanceRecord;
  }

  async updateAttendance(id: number, attendanceUpdate: Partial<Attendance>): Promise<Attendance> {
    const [updatedAttendance] = await db
      .update(attendance)
      .set({ ...attendanceUpdate, updatedAt: new Date() })
      .where(eq(attendance.id, id))
      .returning();
    return updatedAttendance;
  }

  async getAttendanceByCompany(companyId: number, date?: Date): Promise<Attendance[]> {
    const query = db
      .select()
      .from(attendance)
      .innerJoin(employees, eq(attendance.employeeId, employees.id))
      .where(eq(employees.companyId, companyId));

    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      
      return await query
        .where(
          and(
            eq(employees.companyId, companyId),
            sql`${attendance.date} >= ${startOfDay.toISOString().split('T')[0]}`,
            sql`${attendance.date} <= ${endOfDay.toISOString().split('T')[0]}`
          )
        )
        .orderBy(desc(attendance.date));
    }
    
    return await query.orderBy(desc(attendance.date));
  }

  async markCheckIn(employeeId: number, checkInData: {
    latitude?: number;
    longitude?: number;
    faceImage?: string;
    deviceInfo?: string;
    ipAddress?: string;
  }): Promise<Attendance> {
    const today = new Date().toISOString().split('T')[0];
    const now = new Date();
    
    // Check if employee already has attendance for today
    const existingAttendance = await db
      .select()
      .from(attendance)
      .where(
        and(
          eq(attendance.employeeId, employeeId),
          sql`date(${attendance.date}) = ${today}`
        )
      );

    if (existingAttendance.length > 0) {
      // Update existing record
      const [updated] = await db
        .update(attendance)
        .set({
          checkIn: now,
          faceVerified: checkInData.faceImage ? true : false,
          faceImage: checkInData.faceImage,
          checkInLatitude: checkInData.latitude || null,
          checkInLongitude: checkInData.longitude || null,
          locationVerified: (checkInData.latitude && checkInData.longitude) ? true : false,
          deviceInfo: checkInData.deviceInfo,
          ipAddress: checkInData.ipAddress,
          verificationType: checkInData.faceImage ? 'face' : 'manual',
          status: 'present',
          isPresent: true,
          updatedAt: now
        })
        .where(eq(attendance.id, existingAttendance[0].id))
        .returning();
      
      return updated;
    } else {
      // Get employee info for company ID
      const employee = await this.getEmployee(employeeId);
      if (!employee) {
        throw new Error('Employee not found');
      }

      // Create new attendance record
      const [newAttendance] = await db
        .insert(attendance)
        .values({
          employeeId,
          companyId: employee.companyId,
          date: today,
          checkIn: now,
          faceVerified: checkInData.faceImage ? true : false,
          faceImage: checkInData.faceImage,
          checkInLatitude: checkInData.latitude || null,
          checkInLongitude: checkInData.longitude || null,
          locationVerified: (checkInData.latitude && checkInData.longitude) ? true : false,
          deviceInfo: checkInData.deviceInfo,
          ipAddress: checkInData.ipAddress,
          verificationType: checkInData.faceImage ? 'face' : 'manual',
          status: 'present',
          isPresent: true
        })
        .returning();
      
      return newAttendance;
    }
  }

  async markCheckOut(attendanceId: number, checkOutData: {
    latitude?: number;
    longitude?: number;
  }): Promise<Attendance> {
    const now = new Date();
    
    const [attendanceRecord] = await db
      .select()
      .from(attendance)
      .where(eq(attendance.id, attendanceId));

    if (!attendanceRecord) {
      throw new Error('Attendance record not found');
    }

    // Calculate hours worked
    let hoursWorked = 0;
    if (attendanceRecord.checkIn) {
      const checkInTime = new Date(attendanceRecord.checkIn);
      hoursWorked = (now.getTime() - checkInTime.getTime()) / (1000 * 60 * 60);
    }

    const [updated] = await db
      .update(attendance)
      .set({
        checkOut: now,
        checkOutLatitude: checkOutData.latitude || null,
        checkOutLongitude: checkOutData.longitude || null,
        hoursWorked: hoursWorked.toFixed(2),
        updatedAt: now
      })
      .where(eq(attendance.id, attendanceId))
      .returning();
    
    return updated;
  }

  async getMonthlyAttendance(employeeId: number, year: number, month: number): Promise<MonthlyAttendance | undefined> {
    const [monthlyRecord] = await db
      .select()
      .from(monthlyAttendance)
      .where(
        and(
          eq(monthlyAttendance.employeeId, employeeId),
          eq(monthlyAttendance.year, year),
          eq(monthlyAttendance.month, month)
        )
      );
    
    return monthlyRecord || undefined;
  }

  async upsertMonthlyAttendanceQuickEntry(data: {
    employeeId: number;
    year: number;
    month: number;
    payDays: number;
    otHours: number;
  }) {
    const existing = await db
      .select()
      .from(monthlyAttendance)
      .where(
        and(
          eq(monthlyAttendance.employeeId, data.employeeId),
          eq(monthlyAttendance.year, data.year),
          eq(monthlyAttendance.month, data.month)
        )
      );

    if (existing.length > 0) {
      // Update existing record
      const [updated] = await db
        .update(monthlyAttendance)
        .set({
          payableDays: data.payDays,
          totalHoursWorked: data.otHours.toString(),
          updatedAt: new Date()
        })
        .where(eq(monthlyAttendance.id, existing[0].id))
        .returning();
      return updated;
    } else {
      // Create new record
      const [created] = await db
        .insert(monthlyAttendance)
        .values({
          employeeId: data.employeeId,
          year: data.year,
          month: data.month,
          presentDays: Math.max(0, data.payDays - 6), // Estimate present days
          payableDays: data.payDays,
          absentDays: 0,
          lateDays: 0,
          totalWorkingDays: 26,
          totalHoursWorked: data.otHours.toString(),
          averageCheckInTime: "09:00",
          averageCheckOutTime: "18:00"
        })
        .returning();
      return created;
    }
  }

  async getMonthlyAttendanceByEmployee(employeeId: number, year: number, month: number) {
    const [result] = await db
      .select()
      .from(monthlyAttendance)
      .where(
        and(
          eq(monthlyAttendance.employeeId, employeeId),
          eq(monthlyAttendance.year, year),
          eq(monthlyAttendance.month, month)
        )
      );
    return result;
  }

  async deleteMonthlyAttendance(employeeId: number, year: number, month: number) {
    const deleted = await db
      .delete(monthlyAttendance)
      .where(
        and(
          eq(monthlyAttendance.employeeId, employeeId),
          eq(monthlyAttendance.year, year),
          eq(monthlyAttendance.month, month)
        )
      )
      .returning();
    
    return deleted.length > 0 ? deleted[0] : null;
  }

  async calculateMonthlyAttendance(employeeId: number, companyId: number, year: number, month: number): Promise<MonthlyAttendance> {
    // First check if monthly attendance record already exists - use that data if available
    const existingRecord = await this.getMonthlyAttendance(employeeId, year, month);
    if (existingRecord) {
      return existingRecord;
    }

    // If no monthly record exists, try to calculate from daily attendance records
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    
    const attendanceRecords = await db
      .select()
      .from(attendance)
      .where(
        and(
          eq(attendance.employeeId, employeeId),
          sql`${attendance.date} >= ${firstDay.toISOString().split('T')[0]}`,
          sql`${attendance.date} <= ${lastDay.toISOString().split('T')[0]}`
        )
      );

    // Calculate statistics from daily records
    const totalWorkingDays = this.getWorkingDaysInMonth(year, month);
    const presentDays = attendanceRecords.filter(r => r.status === 'present').length;
    const absentDays = attendanceRecords.filter(r => r.status === 'absent').length;
    const halfDays = attendanceRecords.filter(r => r.status === 'half_day').length;
    const lateDays = attendanceRecords.filter(r => r.status === 'late').length;
    const paidLeaveDays = attendanceRecords.filter(r => r.status === 'paid_leave').length;
    const unpaidLeaveDays = attendanceRecords.filter(r => r.status === 'unpaid_leave').length;
    const compOffDays = attendanceRecords.filter(r => r.status === 'comp_off').length;
    const weeklyOffDays = this.getWeeklyOffDaysInMonth(year, month);
    const holidayDays = 0; // TODO: Get from holidays table
    
    // Calculate payable days with proper late penalty policy
    const hasMinimumAttendance = (presentDays + lateDays + halfDays) > 0;
    const creditedWeeklyOffs = hasMinimumAttendance ? weeklyOffDays : 0;
    const creditedHolidays = hasMinimumAttendance ? holidayDays : 0;
    
    const fullPayDays = presentDays + paidLeaveDays + creditedWeeklyOffs + compOffDays + creditedHolidays;
    const penalizedLateDays = lateDays * 0.9;
    const partialHalfDays = halfDays * 0.5;
    const payableDays = fullPayDays + penalizedLateDays + partialHalfDays;
    const totalHoursWorked = attendanceRecords
      .reduce((total, record) => total + (parseFloat(record.hoursWorked || '0')), 0);
    
    const monthlyData = {
      employeeId,
      companyId,
      year,
      month,
      totalWorkingDays,
      presentDays,
      absentDays,
      halfDays,
      lateDays,
      paidLeaveDays,
      unpaidLeaveDays,
      compOffDays,
      weeklyOffDays,
      holidayDays,
      payableDays,
      totalHoursWorked: totalHoursWorked.toFixed(2),
      averageCheckInTime: this.calculateAverageTime(attendanceRecords.map(r => r.checkIn).filter(Boolean)),
      averageCheckOutTime: this.calculateAverageTime(attendanceRecords.map(r => r.checkOut).filter(Boolean))
    };

    if (existingRecord) {
      const [updated] = await db
        .update(monthlyAttendance)
        .set({ ...monthlyData, updatedAt: new Date() })
        .where(eq(monthlyAttendance.id, existingRecord.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(monthlyAttendance)
        .values(monthlyData)
        .returning();
      return created;
    }
  }

  private getWorkingDaysInMonth(year: number, month: number): number {
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    let workingDays = 0;
    
    for (let date = new Date(firstDay); date <= lastDay; date.setDate(date.getDate() + 1)) {
      const dayOfWeek = date.getDay();
      if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Not Sunday (0) or Saturday (6)
        workingDays++;
      }
    }
    
    return workingDays;
  }

  private getWeeklyOffDaysInMonth(year: number, month: number): number {
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    let weeklyOffDays = 0;
    
    for (let date = new Date(firstDay); date <= lastDay; date.setDate(date.getDate() + 1)) {
      const dayOfWeek = date.getDay();
      if (dayOfWeek === 0 || dayOfWeek === 6) { // Sunday (0) or Saturday (6)
        weeklyOffDays++;
      }
    }
    
    return weeklyOffDays;
  }

  // Payroll Methods
  async getMonthlyPayrolls(companyId: number): Promise<MonthlyPayroll[]> {
    return await db
      .select()
      .from(monthlyPayroll)
      .where(eq(monthlyPayroll.companyId, companyId))
      .orderBy(desc(monthlyPayroll.year), desc(monthlyPayroll.month));
  }

  async getMonthlyPayroll(id: number): Promise<MonthlyPayroll | undefined> {
    const [payroll] = await db
      .select()
      .from(monthlyPayroll)
      .where(eq(monthlyPayroll.id, id));
    return payroll;
  }

  async createMonthlyPayroll(data: InsertMonthlyPayroll): Promise<MonthlyPayroll> {
    const [created] = await db
      .insert(monthlyPayroll)
      .values(data)
      .returning();
    return created;
  }

  async finalizePayroll(payrollId: number, finalizedBy: number): Promise<MonthlyPayroll> {
    const [updated] = await db
      .update(monthlyPayroll)
      .set({ 
        status: 'finalized',
        finalizedBy,
        finalizedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(monthlyPayroll.id, payrollId))
      .returning();
    return updated;
  }

  async deleteMonthlyPayroll(payrollId: number): Promise<boolean> {
    // First delete all associated payroll records
    const deletedRecords = await db
      .delete(payrollRecords)
      .where(eq(payrollRecords.monthlyPayrollId, payrollId))
      .returning();

    // Then delete the monthly payroll
    const deletedPayroll = await db
      .delete(monthlyPayroll)
      .where(eq(monthlyPayroll.id, payrollId))
      .returning();
      
    // Return true if payroll was actually deleted
    return deletedPayroll.length > 0;
  }

  async getPayrollRecords(monthlyPayrollId: number): Promise<any[]> {
    // Join with employees and departments to get enriched data for Excel export
    const records = await db
      .select({
        id: payrollRecords.id,
        monthlyPayrollId: payrollRecords.monthlyPayrollId,
        employeeId: payrollRecords.employeeId,
        employeeCode: employees.employeeId,
        employeeName: sql<string>`${employees.firstName} || ' ' || ${employees.lastName}`,
        department: departments.name,
        presentDays: payrollRecords.presentDays,
        payableDays: payrollRecords.payableDays,
        basicSalary: payrollRecords.basicSalary,
        hra: payrollRecords.hra,
        conveyanceAllowance: payrollRecords.conveyanceAllowance,
        otherAllowances: payrollRecords.otherAllowances,
        grossSalary: payrollRecords.grossSalary,
        epfEmployee: payrollRecords.epfEmployee,
        esicEmployee: payrollRecords.esicEmployee,
        tdsAmount: payrollRecords.tdsAmount,
        ptAmount: payrollRecords.ptAmount,
        totalDeductions: payrollRecords.totalDeductions,
        netSalary: payrollRecords.netSalary,
        paymentStatus: payrollRecords.paymentStatus
      })
      .from(payrollRecords)
      .leftJoin(employees, eq(payrollRecords.employeeId, employees.id))
      .leftJoin(departments, eq(employees.departmentId, departments.id))
      .where(eq(payrollRecords.monthlyPayrollId, monthlyPayrollId))
      .orderBy(payrollRecords.employeeId);
    
    return records;
  }

  async createPayrollRecord(data: InsertPayrollRecord): Promise<PayrollRecord> {
    const [created] = await db
      .insert(payrollRecords)
      .values(data)
      .returning();
    return created;
  }

  async updatePaymentStatus(recordId: number, status: string, amount?: number, method?: string, reference?: string): Promise<PayrollRecord> {
    const updateData: any = {
      paymentStatus: status,
      updatedAt: new Date()
    };

    if (status === 'paid') {
      updateData.paidAmount = amount || 0;
      updateData.paymentDate = new Date();
      updateData.paymentMethod = method;
      updateData.paymentReference = reference;
    } else if (status === 'unpaid') {
      updateData.paidAmount = 0;
      updateData.paymentDate = null;
      updateData.paymentMethod = null;
      updateData.paymentReference = null;
    }

    const [updated] = await db
      .update(payrollRecords)
      .set(updateData)
      .where(eq(payrollRecords.id, recordId))
      .returning();
    return updated;
  }

  async generatePayrollForMonth(companyId: number, month: number, year: number, generatedBy: number): Promise<MonthlyPayroll> {
    // Check if payroll already exists
    const existingPayroll = await db
      .select()
      .from(monthlyPayroll)
      .where(
        and(
          eq(monthlyPayroll.companyId, companyId),
          eq(monthlyPayroll.month, month),
          eq(monthlyPayroll.year, year)
        )
      );

    if (existingPayroll.length > 0) {
      throw new Error('Payroll for this month already exists');
    }

    // Create monthly payroll record
    const [createdPayroll] = await db
      .insert(monthlyPayroll)
      .values({
        companyId,
        month,
        year,
        generatedBy,
        status: 'draft'
      })
      .returning();

    // Get all active employees for the company
    const activeEmployees = await db
      .select()
      .from(employees)
      .where(
        and(
          eq(employees.companyId, companyId),
          eq(employees.status, 'active')
        )
      );

    // Generate payroll records for each employee
    for (const employee of activeEmployees) {
      // Get the latest payroll setup for this employee
      const [payrollSetup] = await db
        .select()
        .from(employeePayroll)
        .where(eq(employeePayroll.employeeId, employee.id))
        .orderBy(desc(employeePayroll.updatedAt))
        .limit(1);


      if (!employee) continue;

      // Calculate monthly attendance
      const monthlyAttendanceData = await this.calculateMonthlyAttendance(employee.id, companyId, year, month);

      // Calculate salary components based on payroll setup
      const basicSalary = parseFloat(payrollSetup?.earningHead1 || '0');
      const hra = parseFloat(payrollSetup?.earningHead2 || '0');
      const conveyanceAllowance = parseFloat(payrollSetup?.earningHead3 || '0');
      const otherAllowances = parseFloat(payrollSetup?.earningHead4 || '0');
      const grossSalary = parseFloat(payrollSetup?.grossValue || '0');

      // Note: Original deduction and contribution calculations removed to avoid dual calculation sources
      // All calculations now use proportional amounts only

      // Calculate proportional salary based on payable days
      const totalMonthDays = new Date(year, month, 0).getDate(); // Get actual days in month
      const payableDays = Math.max(0, monthlyAttendanceData.payableDays || 0); // Ensure non-negative
      const rawProportionFactor = totalMonthDays > 0 ? payableDays / totalMonthDays : 0;
      
      // Clamp proportion factor to prevent errors (0-1 range) and handle NaN/invalid values
      const proportionFactor = isNaN(rawProportionFactor) ? 0 : Math.max(0, Math.min(1, rawProportionFactor));
      
      // Apply proportional calculation to all salary components with proper rounding
      const proportionalBasicSalary = Math.round((basicSalary * proportionFactor) * 100) / 100;
      const proportionalHra = Math.round((hra * proportionFactor) * 100) / 100;
      const proportionalConveyanceAllowance = Math.round((conveyanceAllowance * proportionFactor) * 100) / 100;
      const proportionalOtherAllowances = Math.round((otherAllowances * proportionFactor) * 100) / 100;
      const proportionalGrossSalary = Math.round((grossSalary * proportionFactor) * 100) / 100;
      
      // Calculate deductions based on proportional amounts with proper rounding
      let proportionalEpfEmployee = 0;
      let proportionalEsicEmployee = 0;
      let proportionalLwfEmployee = 0;
      let proportionalVpfAmount = 0;
      let proportionalTdsAmount = 0;
      let proportionalPtAmount = 0;

      if (payrollSetup?.epfEnabled) {
        proportionalEpfEmployee = Math.round((proportionalBasicSalary * 0.12) * 100) / 100;
      }

      if (payrollSetup?.esicEnabled) {
        proportionalEsicEmployee = Math.round((proportionalGrossSalary * 0.0075) * 100) / 100;
      }

      if (payrollSetup?.lwfEnabled) {
        proportionalLwfEmployee = Math.round((10 * proportionFactor) * 100) / 100; // Proportional fixed amount
      }

      if (payrollSetup?.vpfEnabled && payrollSetup?.vpfAmount) {
        proportionalVpfAmount = Math.round((parseFloat(payrollSetup.vpfAmount) * proportionFactor) * 100) / 100;
      }

      if (payrollSetup?.tdsEnabled && payrollSetup?.tdsAmount) {
        proportionalTdsAmount = Math.round((parseFloat(payrollSetup.tdsAmount) * proportionFactor) * 100) / 100;
      }

      if (payrollSetup?.ptEnabled && payrollSetup?.ptAmount) {
        proportionalPtAmount = Math.round((parseFloat(payrollSetup.ptAmount) * proportionFactor) * 100) / 100;
      }

      const proportionalTotalDeductions = Math.round((proportionalEpfEmployee + proportionalEsicEmployee + 
        proportionalLwfEmployee + proportionalVpfAmount + proportionalTdsAmount + proportionalPtAmount) * 100) / 100;

      // Calculate employer contributions based on proportional amounts with proper rounding
      let proportionalEpfEmployer = 0;
      let proportionalEpfAdmin = 0;
      let proportionalEsicEmployer = 0;
      let proportionalLwfEmployer = 0;
      let proportionalBonus = 0;

      if (payrollSetup?.epfEnabled) {
        proportionalEpfEmployer = Math.round((proportionalBasicSalary * 0.12) * 100) / 100;
        proportionalEpfAdmin = Math.round((proportionalBasicSalary * 0.01) * 100) / 100;
      }

      if (payrollSetup?.esicEnabled) {
        proportionalEsicEmployer = Math.round((proportionalGrossSalary * 0.0325) * 100) / 100;
      }

      if (payrollSetup?.lwfEnabled) {
        proportionalLwfEmployer = Math.round((10 * proportionFactor) * 100) / 100; // Proportional fixed amount
      }

      if (payrollSetup?.bonusEnabled) {
        proportionalBonus = Math.round((proportionalGrossSalary * 0.0833) * 100) / 100;
      }

      const proportionalTotalEmployerContributions = Math.round((proportionalEpfEmployer + proportionalEpfAdmin + 
        proportionalEsicEmployer + proportionalLwfEmployer + proportionalBonus) * 100) / 100;

      // Calculate final amounts with proper rounding
      const netSalary = Math.round((proportionalGrossSalary - proportionalTotalDeductions) * 100) / 100;
      const ctc = Math.round((proportionalGrossSalary + proportionalTotalEmployerContributions) * 100) / 100;

      // Create payroll record
      await db.insert(payrollRecords).values({
        monthlyPayrollId: createdPayroll.id,
        employeeId: employee.id,
        companyId,
        presentDays: monthlyAttendanceData.presentDays,
        weeklyOffs: monthlyAttendanceData.weeklyOffDays,
        leaveDays: monthlyAttendanceData.paidLeaveDays + monthlyAttendanceData.unpaidLeaveDays,
        holidays: monthlyAttendanceData.holidayDays,
        payableDays: monthlyAttendanceData.payableDays,
        overtimeHours: '0', // TODO: Calculate from attendance
        basicSalary: proportionalBasicSalary.toFixed(2),
        hra: proportionalHra.toFixed(2),
        conveyanceAllowance: proportionalConveyanceAllowance.toFixed(2),
        otherAllowances: proportionalOtherAllowances.toFixed(2),
        grossSalary: proportionalGrossSalary.toFixed(2),
        overtimeAmount: '0',
        epfEmployee: proportionalEpfEmployee.toFixed(2),
        esicEmployee: proportionalEsicEmployee.toFixed(2),
        lwfEmployee: proportionalLwfEmployee.toFixed(2),
        vpfAmount: proportionalVpfAmount.toFixed(2),
        tdsAmount: proportionalTdsAmount.toFixed(2),
        ptAmount: proportionalPtAmount.toFixed(2),
        totalDeductions: proportionalTotalDeductions.toFixed(2),
        epfEmployer: proportionalEpfEmployer.toFixed(2),
        epfAdmin: proportionalEpfAdmin.toFixed(2),
        esicEmployer: proportionalEsicEmployer.toFixed(2),
        lwfEmployer: proportionalLwfEmployer.toFixed(2),
        bonus: proportionalBonus.toFixed(2),
        totalEmployerContributions: proportionalTotalEmployerContributions.toFixed(2),
        netSalary: netSalary.toFixed(2),
        ctc: ctc.toFixed(2),
        paymentStatus: 'unpaid'
      });
    }

    return createdPayroll;
  }

  private calculateAverageTime(times: (Date | string)[]): string | null {
    if (times.length === 0) return null;
    
    const totalMinutes = times.reduce((sum, time) => {
      const date = new Date(time);
      return sum + (date.getHours() * 60 + date.getMinutes());
    }, 0);
    
    const avgMinutes = totalMinutes / times.length;
    const hours = Math.floor(avgMinutes / 60);
    const minutes = Math.floor(avgMinutes % 60);
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:00`;
  }

  async getFaceTemplate(employeeId: number): Promise<FaceTemplate | undefined> {
    const [template] = await db
      .select()
      .from(faceTemplates)
      .where(
        and(
          eq(faceTemplates.employeeId, employeeId),
          eq(faceTemplates.isActive, true)
        )
      );
    
    return template || undefined;
  }

  async createFaceTemplate(insertFaceTemplate: InsertFaceTemplate): Promise<FaceTemplate> {
    const [template] = await db
      .insert(faceTemplates)
      .values(insertFaceTemplate)
      .returning();
    
    return template;
  }

  async updateFaceTemplate(employeeId: number, templateData: string): Promise<FaceTemplate> {
    const existing = await this.getFaceTemplate(employeeId);
    
    if (existing) {
      const [updated] = await db
        .update(faceTemplates)
        .set({ templateData, updatedAt: new Date() })
        .where(eq(faceTemplates.id, existing.id))
        .returning();
      
      return updated;
    } else {
      return await this.createFaceTemplate({
        employeeId,
        templateData,
        isActive: true
      });
    }
  }

  async getAttendanceLocations(companyId: number): Promise<AttendanceLocation[]> {
    return await db
      .select()
      .from(attendanceLocations)
      .where(
        and(
          eq(attendanceLocations.companyId, companyId),
          eq(attendanceLocations.isActive, true)
        )
      )
      .orderBy(attendanceLocations.name);
  }

  async createAttendanceLocation(insertLocation: InsertAttendanceLocation): Promise<AttendanceLocation> {
    const [location] = await db
      .insert(attendanceLocations)
      .values(insertLocation)
      .returning();
    
    return location;
  }

  async validateLocation(companyId: number, latitude: number, longitude: number): Promise<AttendanceLocation | null> {
    const locations = await this.getAttendanceLocations(companyId);
    
    for (const location of locations) {
      const distance = this.calculateDistance(
        latitude,
        longitude,
        parseFloat(location.latitude),
        parseFloat(location.longitude)
      );
      
      if (distance <= (location.radius || 100)) {
        return location;
      }
    }
    
    return null;
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon1 - lon2) * Math.PI / 180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c;
  }

  async getDashboardStats(companyId: number): Promise<{
    totalEmployees: number;
    activeJobs: number;
    pendingApplications: number;
    todayAttendance: number;
  }> {
    // Total employees
    const [employeeCount] = await db
      .select({ count: count() })
      .from(employees)
      .where(and(eq(employees.companyId, companyId), eq(employees.status, 'active')));

    // Active jobs
    const [jobCount] = await db
      .select({ count: count() })
      .from(jobs)
      .where(and(eq(jobs.companyId, companyId), eq(jobs.status, 'active')));

    // Pending applications
    const [applicationCount] = await db
      .select({ count: count() })
      .from(jobApplications)
      .innerJoin(jobs, eq(jobApplications.jobId, jobs.id))
      .where(and(eq(jobs.companyId, companyId), eq(jobApplications.status, 'pending')));

    // Today's attendance (simplified - just count of present employees today)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [attendanceCount] = await db
      .select({ count: count() })
      .from(attendance)
      .innerJoin(employees, eq(attendance.employeeId, employees.id))
      .where(
        and(
          eq(employees.companyId, companyId),
          eq(attendance.isPresent, true),
          sql`${attendance.date} >= ${today}`,
          sql`${attendance.date} < ${tomorrow}`
        )
      );

    return {
      totalEmployees: employeeCount.count || 0,
      activeJobs: jobCount.count || 0,
      pendingApplications: applicationCount.count || 0,
      todayAttendance: attendanceCount.count || 0,
    };
  }

  // User management methods
  async getUsersByCompany(companyId: number): Promise<User[]> {
    return await db.select().from(users).where(eq(users.companyId, companyId)).orderBy(desc(users.createdAt));
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUser(id: number, user: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ ...user, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  // Company management methods
  async getAllCompanies(): Promise<Company[]> {
    return await db.select().from(companies).orderBy(desc(companies.createdAt));
  }

  async updateCompany(id: number, company: Partial<Company>): Promise<Company> {
    const [updatedCompany] = await db
      .update(companies)
      .set({ ...company, updatedAt: new Date() })
      .where(eq(companies.id, id))
      .returning();
    return updatedCompany;
  }

  async updateCompanyProfile(id: number, profileData: Partial<Company>): Promise<Company> {
    const [updatedCompany] = await db
      .update(companies)
      .set({ 
        ...profileData, 
        profileComplete: true,
        updatedAt: new Date() 
      })
      .where(eq(companies.id, id))
      .returning();
    return updatedCompany;
  }

  async deleteCompany(id: number): Promise<void> {
    // Delete related data first due to foreign key constraints
    await db.delete(departments).where(eq(departments.companyId, id));
    await db.delete(jobs).where(eq(jobs.companyId, id));
    await db.delete(employees).where(eq(employees.companyId, id));
    await db.delete(userActivities).where(eq(userActivities.companyId, id));
    await db.delete(permissionRequests).where(eq(permissionRequests.companyId, id));
    await db.delete(jobApplications).where(eq(jobApplications.companyId, id));
    await db.delete(interviews).where(eq(interviews.companyId, id));
    await db.delete(jobOffers).where(eq(jobOffers.companyId, id));
    
    // Finally delete the company
    await db.delete(companies).where(eq(companies.id, id));
  }

  // Employee Profile methods
  async createEmployeeProfile(profileData: InsertEmployeeProfile): Promise<EmployeeProfile> {
    const [profile] = await db
      .insert(employeeProfiles)
      .values(profileData)
      .returning();
    return profile;
  }

  async getEmployeeProfileByUserId(userId: number): Promise<EmployeeProfile | undefined> {
    const [profile] = await db.select().from(employeeProfiles).where(eq(employeeProfiles.userId, userId));
    
    if (!profile) {
      // If no employee profile exists, create a minimal one from user data
      const user = await this.getUser(userId);
      if (user) {
        const newProfile = await this.createEmployeeProfile({
          userId: user.id,
          firstName: user.username.split('@')[0] || 'Employee',
          lastName: '',
        });
        return newProfile;
      }
    }
    
    return profile || undefined;
  }

  async updateEmployeeProfile(userId: number, profileData: Partial<EmployeeProfile>): Promise<EmployeeProfile> {
    // Check if profile exists, if not create it
    const existingProfile = await this.getEmployeeProfileByUserId(userId);
    
    if (!existingProfile) {
      // Create new profile if it doesn't exist
      return await this.createEmployeeProfile({
        userId,
        firstName: profileData.firstName || '',
        lastName: profileData.lastName || '',
        skills: profileData.skills,
        experience: profileData.experience,
        phone: profileData.phone,
        address: profileData.address,
      });
    }
    
    const [profile] = await db
      .update(employeeProfiles)
      .set({ ...profileData, updatedAt: new Date() })
      .where(eq(employeeProfiles.userId, userId))
      .returning();
    return profile;
  }

  async getAllPublicJobs(): Promise<Job[]> {
    return await db.select().from(jobs).where(eq(jobs.status, 'active')).orderBy(desc(jobs.postedAt));
  }

  async getJobApplicationsByEmail(email: string): Promise<JobApplication[]> {
    return await db.select().from(jobApplications).where(eq(jobApplications.applicantEmail, email)).orderBy(desc(jobApplications.appliedAt));
  }

  // Permission methods
  async getPermissions(): Promise<Permission[]> {
    return await db.select().from(permissions).orderBy(permissions.category, permissions.name);
  }

  async createPermission(insertPermission: InsertPermission): Promise<Permission> {
    const [permission] = await db
      .insert(permissions)
      .values(insertPermission)
      .returning();
    return permission;
  }

  async getRolePermissions(role: string, companyId?: number): Promise<RolePermission[]> {
    let query = db.select().from(rolePermissions).where(eq(rolePermissions.role, role as any));
    
    if (companyId) {
      query = db.select().from(rolePermissions)
        .where(
          and(
            eq(rolePermissions.role, role as any),
            eq(rolePermissions.companyId, companyId)
          )
        );
    }
    
    return await query.orderBy(rolePermissions.id);
  }

  async createRolePermission(insertRolePermission: InsertRolePermission): Promise<RolePermission> {
    const [rolePermission] = await db
      .insert(rolePermissions)
      .values(insertRolePermission)
      .returning();
    return rolePermission;
  }

  async deleteRolePermission(id: number): Promise<void> {
    await db.delete(rolePermissions).where(eq(rolePermissions.id, id));
  }

  // Permission request methods
  async getPermissionRequests(companyId?: number): Promise<any[]> {
    try {
      let query = db.select().from(permissionRequests);
      
      if (companyId) {
        query = query.where(eq(permissionRequests.companyId, companyId));
      }
      
      const results = await query.orderBy(desc(permissionRequests.createdAt));
      return results;
    } catch (error) {
      console.error('Error fetching permission requests:', error);
      throw error;
    }
  }

  async createPermissionRequest(insertPermissionRequest: InsertPermissionRequest): Promise<PermissionRequest> {
    try {
      const [permissionRequest] = await db
        .insert(permissionRequests)
        .values(insertPermissionRequest)
        .returning();
      return permissionRequest;
    } catch (error) {
      console.error('Error creating permission request:', error);
      throw error;
    }
  }

  async updatePermissionRequest(id: number, updates: Partial<PermissionRequest>): Promise<PermissionRequest> {
    const [updated] = await db
      .update(permissionRequests)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(permissionRequests.id, id))
      .returning();
    return updated;
  }

  async updatePermissionRequest(id: number, permissionRequest: Partial<PermissionRequest>): Promise<PermissionRequest> {
    const [updatedPermissionRequest] = await db
      .update(permissionRequests)
      .set({ ...permissionRequest, updatedAt: new Date() })
      .where(eq(permissionRequests.id, id))
      .returning();
    return updatedPermissionRequest;
  }

  async getPermissionRequestsByUser(userId: number): Promise<PermissionRequest[]> {
    return await db.select().from(permissionRequests)
      .where(eq(permissionRequests.userId, userId))
      .orderBy(desc(permissionRequests.createdAt));
  }

  // User activity methods
  async createUserActivity(insertActivity: InsertUserActivity): Promise<UserActivity> {
    const [activity] = await db
      .insert(userActivities)
      .values(insertActivity)
      .returning();
    return activity;
  }

  async getUserActivities(companyId?: number, userId?: number): Promise<UserActivity[]> {
    if (companyId && userId) {
      return await db.select().from(userActivities)
        .where(and(eq(userActivities.companyId, companyId), eq(userActivities.userId, userId)))
        .orderBy(desc(userActivities.createdAt));
    } else if (companyId) {
      return await db.select().from(userActivities)
        .where(eq(userActivities.companyId, companyId))
        .orderBy(desc(userActivities.createdAt));
    } else if (userId) {
      return await db.select().from(userActivities)
        .where(eq(userActivities.userId, userId))
        .orderBy(desc(userActivities.createdAt));
    }
    
    return await db.select().from(userActivities).orderBy(desc(userActivities.createdAt));
  }

  // Employment history methods
  async getEmploymentHistoryByProfile(profileId: number): Promise<EmploymentHistory[]> {
    return await db.select().from(employmentHistory)
      .where(eq(employmentHistory.employeeProfileId, profileId))
      .orderBy(desc(employmentHistory.joinDate));
  }

  async createEmploymentHistory(historyData: InsertEmploymentHistory): Promise<EmploymentHistory> {
    const [history] = await db
      .insert(employmentHistory)
      .values(historyData)
      .returning();
    return history;
  }

  async updateEmploymentHistory(id: number, historyData: Partial<EmploymentHistory>): Promise<EmploymentHistory> {
    const [history] = await db
      .update(employmentHistory)
      .set({ ...historyData, updatedAt: new Date() })
      .where(eq(employmentHistory.id, id))
      .returning();
    return history;
  }

  async deleteEmploymentHistory(id: number): Promise<void> {
    await db.delete(employmentHistory).where(eq(employmentHistory.id, id));
  }

  // KYC details methods
  async getKycDetailsByProfile(profileId: number): Promise<KycDetails | undefined> {
    const [kyc] = await db.select().from(kycDetails)
      .where(eq(kycDetails.employeeProfileId, profileId));
    return kyc || undefined;
  }

  async createKycDetails(kycData: InsertKycDetails): Promise<KycDetails> {
    const [kyc] = await db
      .insert(kycDetails)
      .values(kycData)
      .returning();
    return kyc;
  }

  async updateKycDetails(profileId: number, kycData: Partial<KycDetails>): Promise<KycDetails> {
    // Check if KYC details exist, if not create them
    const existing = await this.getKycDetailsByProfile(profileId);
    
    if (!existing) {
      return await this.createKycDetails({
        employeeProfileId: profileId,
        aadharNo: kycData.aadharNo,
        panNo: kycData.panNo,
        bankAccountNo: kycData.bankAccountNo,
        ifscCode: kycData.ifscCode,
        uanNo: kycData.uanNo,
        esicNo: kycData.esicNo,
      });
    }
    
    const [kyc] = await db
      .update(kycDetails)
      .set({ ...kycData, updatedAt: new Date() })
      .where(eq(kycDetails.employeeProfileId, profileId))
      .returning();
    return kyc;
  }

  // Interview methods
  async getInterviewsByCompany(companyId: number): Promise<Interview[]> {
    return await db
      .select({
        id: interviews.id,
        jobApplicationId: interviews.jobApplicationId,
        scheduledAt: interviews.scheduledAt,
        duration: interviews.duration,
        location: interviews.location,
        meetingLink: interviews.meetingLink,
        interviewerIds: interviews.interviewerIds,
        status: interviews.status,
        notes: interviews.notes,
        rating: interviews.rating,
        result: interviews.result,
        createdAt: interviews.createdAt,
        updatedAt: interviews.updatedAt,
      })
      .from(interviews)
      .innerJoin(jobApplications, eq(interviews.jobApplicationId, jobApplications.id))
      .innerJoin(jobs, eq(jobApplications.jobId, jobs.id))
      .where(eq(jobs.companyId, companyId))
      .orderBy(desc(interviews.scheduledAt));
  }

  async createInterview(interviewData: InsertInterview): Promise<Interview> {
    const [interview] = await db
      .insert(interviews)
      .values(interviewData)
      .returning();
    return interview;
  }

  async updateInterviewStatus(id: number, status: string, notes?: string): Promise<Interview> {
    const [interview] = await db
      .update(interviews)
      .set({ status, notes, updatedAt: new Date() })
      .where(eq(interviews.id, id))
      .returning();
    return interview;
  }

  // Job Application methods
  async getJobApplicationsByCompany(companyId: number): Promise<JobApplication[]> {
    return await db
      .select()
      .from(jobApplications)
      .innerJoin(jobs, eq(jobApplications.jobId, jobs.id))
      .where(eq(jobs.companyId, companyId))
      .orderBy(desc(jobApplications.appliedAt));
  }

  async updateJobApplicationStatus(id: number, status: string, reviewedBy?: number): Promise<JobApplication> {
    const [application] = await db
      .update(jobApplications)
      .set({ 
        status: status as any, 
        reviewedBy, 
        reviewedAt: new Date(), 
        updatedAt: new Date() 
      })
      .where(eq(jobApplications.id, id))
      .returning();
    return application;
  }

  // Job Offer methods
  async createJobOffer(offerData: InsertJobOffer): Promise<JobOffer> {
    const [offer] = await db
      .insert(jobOffers)
      .values(offerData)
      .returning();
    return offer;
  }

  async getJobOffersByCompany(companyId: number): Promise<JobOffer[]> {
    return await db
      .select()
      .from(jobOffers)
      .innerJoin(jobApplications, eq(jobOffers.jobApplicationId, jobApplications.id))
      .innerJoin(jobs, eq(jobApplications.jobId, jobs.id))
      .where(eq(jobs.companyId, companyId))
      .orderBy(desc(jobOffers.createdAt));
  }

  async updateJobOfferStatus(id: number, status: string): Promise<JobOffer> {
    const [offer] = await db
      .update(jobOffers)
      .set({ status, updatedAt: new Date() })
      .where(eq(jobOffers.id, id))
      .returning();
    return offer;
  }

  // Family details methods
  async getFamilyDetailsByProfile(profileId: number): Promise<FamilyDetails[]> {
    return await db.select().from(familyDetails)
      .where(eq(familyDetails.employeeProfileId, profileId))
      .orderBy(familyDetails.memberName);
  }

  async createFamilyDetails(familyData: InsertFamilyDetails): Promise<FamilyDetails> {
    const [family] = await db
      .insert(familyDetails)
      .values(familyData)
      .returning();
    return family;
  }

  async updateFamilyDetails(id: number, familyData: Partial<FamilyDetails>): Promise<FamilyDetails> {
    const [family] = await db
      .update(familyDetails)
      .set({ ...familyData, updatedAt: new Date() })
      .where(eq(familyDetails.id, id))
      .returning();
    return family;
  }

  async deleteFamilyDetails(id: number): Promise<void> {
    await db.delete(familyDetails).where(eq(familyDetails.id, id));
  }

  // Leave Request methods implementation
  async getLeaveRequest(id: number): Promise<LeaveRequest | undefined> {
    const [request] = await db.select().from(leaveRequests).where(eq(leaveRequests.id, id));
    return request || undefined;
  }

  async getLeaveRequestsByCompany(companyId: number): Promise<LeaveRequest[]> {
    return await db.select().from(leaveRequests)
      .where(eq(leaveRequests.companyId, companyId))
      .orderBy(desc(leaveRequests.appliedAt));
  }

  async getLeaveRequestsByEmployee(employeeId: number): Promise<LeaveRequest[]> {
    return await db.select().from(leaveRequests)
      .where(eq(leaveRequests.employeeId, employeeId))
      .orderBy(desc(leaveRequests.appliedAt));
  }

  async createLeaveRequest(request: InsertLeaveRequest): Promise<LeaveRequest> {
    const [created] = await db.insert(leaveRequests).values(request).returning();
    return created;
  }

  async updateLeaveRequest(id: number, updates: Partial<LeaveRequest>): Promise<LeaveRequest> {
    const [updated] = await db.update(leaveRequests)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(leaveRequests.id, id))
      .returning();
    return updated;
  }

  async approveLeaveRequest(id: number, level: 1 | 2 | 3, approverId: number, comments?: string): Promise<LeaveRequest> {
    const updateData: Partial<LeaveRequest> = { updatedAt: new Date() };
    
    if (level === 1) {
      updateData.level1ApproverId = approverId;
      updateData.level1ApprovedAt = new Date();
      updateData.level1Comments = comments;
    } else if (level === 2) {
      updateData.level2ApproverId = approverId;
      updateData.level2ApprovedAt = new Date();
      updateData.level2Comments = comments;
    } else if (level === 3) {
      updateData.finalApproverId = approverId;
      updateData.finalApprovedAt = new Date();
      updateData.finalComments = comments;
      updateData.status = 'approved';
    }

    const [updated] = await db.update(leaveRequests)
      .set(updateData)
      .where(eq(leaveRequests.id, id))
      .returning();
    return updated;
  }

  async rejectLeaveRequest(id: number, rejectedById: number, reason: string): Promise<LeaveRequest> {
    const [updated] = await db.update(leaveRequests)
      .set({
        status: 'rejected',
        rejectedById,
        rejectedAt: new Date(),
        rejectionReason: reason,
        updatedAt: new Date()
      })
      .where(eq(leaveRequests.id, id))
      .returning();
    return updated;
  }

  // Advance Request methods implementation
  async getAdvanceRequest(id: number): Promise<AdvanceRequest | undefined> {
    const [request] = await db.select().from(advanceRequests).where(eq(advanceRequests.id, id));
    return request || undefined;
  }

  async getAdvanceRequestsByCompany(companyId: number): Promise<AdvanceRequest[]> {
    return await db.select().from(advanceRequests)
      .where(eq(advanceRequests.companyId, companyId))
      .orderBy(desc(advanceRequests.appliedAt));
  }

  async getAdvanceRequestsByEmployee(employeeId: number): Promise<AdvanceRequest[]> {
    return await db.select().from(advanceRequests)
      .where(eq(advanceRequests.employeeId, employeeId))
      .orderBy(desc(advanceRequests.appliedAt));
  }

  async createAdvanceRequest(request: InsertAdvanceRequest): Promise<AdvanceRequest> {
    const [created] = await db.insert(advanceRequests).values(request).returning();
    return created;
  }

  async updateAdvanceRequest(id: number, updates: Partial<AdvanceRequest>): Promise<AdvanceRequest> {
    const [updated] = await db.update(advanceRequests)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(advanceRequests.id, id))
      .returning();
    return updated;
  }

  async approveAdvanceRequest(id: number, level: 1 | 2 | 3, approverId: number, comments?: string): Promise<AdvanceRequest> {
    const updateData: Partial<AdvanceRequest> = { updatedAt: new Date() };
    
    if (level === 1) {
      updateData.level1ApproverId = approverId;
      updateData.level1ApprovedAt = new Date();
      updateData.level1Comments = comments;
    } else if (level === 2) {
      updateData.level2ApproverId = approverId;
      updateData.level2ApprovedAt = new Date();
      updateData.level2Comments = comments;
    } else if (level === 3) {
      updateData.finalApproverId = approverId;
      updateData.finalApprovedAt = new Date();
      updateData.finalComments = comments;
      updateData.status = 'approved';
    }

    const [updated] = await db.update(advanceRequests)
      .set(updateData)
      .where(eq(advanceRequests.id, id))
      .returning();
    return updated;
  }

  async rejectAdvanceRequest(id: number, rejectedById: number, reason: string): Promise<AdvanceRequest> {
    const [updated] = await db.update(advanceRequests)
      .set({
        status: 'rejected',
        rejectedById,
        rejectedAt: new Date(),
        rejectionReason: reason,
        updatedAt: new Date()
      })
      .where(eq(advanceRequests.id, id))
      .returning();
    return updated;
  }

  async markAdvancePaid(id: number, paidAmount: string, paymentMethod: string, reference?: string): Promise<AdvanceRequest> {
    const [updated] = await db.update(advanceRequests)
      .set({
        status: 'paid',
        paidAmount,
        paidAt: new Date(),
        paymentMethod,
        paymentReference: reference,
        updatedAt: new Date()
      })
      .where(eq(advanceRequests.id, id))
      .returning();
    return updated;
  }

  // Approval Workflow methods implementation
  async getApprovalWorkflow(companyId: number, requestType: string): Promise<ApprovalWorkflow | undefined> {
    const [workflow] = await db.select().from(approvalWorkflows)
      .where(and(
        eq(approvalWorkflows.companyId, companyId),
        eq(approvalWorkflows.requestType, requestType),
        eq(approvalWorkflows.isActive, true)
      ));
    return workflow || undefined;
  }

  async createApprovalWorkflow(workflow: InsertApprovalWorkflow): Promise<ApprovalWorkflow> {
    const [created] = await db.insert(approvalWorkflows).values(workflow).returning();
    return created;
  }

  async updateApprovalWorkflow(id: number, updates: Partial<ApprovalWorkflow>): Promise<ApprovalWorkflow> {
    const [updated] = await db.update(approvalWorkflows)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(approvalWorkflows.id, id))
      .returning();
    return updated;
  }

  // Enhanced Permission Management methods implementation
  async getAllPermissions(): Promise<Permission[]> {
    return await db.select().from(permissions).where(eq(permissions.isActive, true)).orderBy(permissions.category, permissions.name);
  }

  async getPermissionsByCategory(category: string): Promise<Permission[]> {
    return await db.select().from(permissions)
      .where(and(eq(permissions.category, category), eq(permissions.isActive, true)))
      .orderBy(permissions.name);
  }

  async getPermissionsByModule(module: string): Promise<Permission[]> {
    return await db.select().from(permissions)
      .where(and(eq(permissions.module, module), eq(permissions.isActive, true)))
      .orderBy(permissions.name);
  }

  async createPermission(permission: InsertPermission): Promise<Permission> {
    const [created] = await db.insert(permissions).values(permission).returning();
    return created;
  }

  async updatePermission(id: number, permission: Partial<Permission>): Promise<Permission> {
    const [updated] = await db.update(permissions)
      .set(permission)
      .where(eq(permissions.id, id))
      .returning();
    return updated;
  }

  async deletePermission(id: number): Promise<void> {
    await db.update(permissions)
      .set({ isActive: false })
      .where(eq(permissions.id, id));
  }

  // User Permission methods implementation
  async getUserPermissions(userId: number, companyId: number): Promise<UserPermission[]> {
    return await db.select()
      .from(userPermissions)
      .where(and(
        eq(userPermissions.userId, userId),
        eq(userPermissions.companyId, companyId),
        eq(userPermissions.isActive, true)
      ))
      .orderBy(userPermissions.grantedAt);
  }

  async hasUserPermission(userId: number, permissionName: string, companyId: number): Promise<boolean> {
    const result = await db.select({ count: count() })
      .from(userPermissions)
      .innerJoin(permissions, eq(userPermissions.permissionId, permissions.id))
      .where(and(
        eq(userPermissions.userId, userId),
        eq(userPermissions.companyId, companyId),
        eq(permissions.name, permissionName),
        eq(userPermissions.isActive, true),
        eq(permissions.isActive, true)
      ));
    return result[0].count > 0;
  }

  async grantUserPermission(userPermission: InsertUserPermission): Promise<UserPermission> {
    const [granted] = await db.insert(userPermissions).values({ ...userPermission, isActive: true }).returning();
    return granted;
  }

  async revokeUserPermission(userId: number, permissionId: number, companyId: number): Promise<void> {
    await db.update(userPermissions)
      .set({ isActive: false })
      .where(and(
        eq(userPermissions.userId, userId),
        eq(userPermissions.permissionId, permissionId),
        eq(userPermissions.companyId, companyId)
      ));
  }

  async getUsersWithPermission(permissionName: string, companyId: number): Promise<User[]> {
    return await db.select({
      id: users.id,
      username: users.username,
      email: users.email,
      role: users.role,
      companyId: users.companyId,
      isActive: users.isActive,
      createdAt: users.createdAt,
      updatedAt: users.updatedAt
    })
      .from(users)
      .innerJoin(userPermissions, eq(users.id, userPermissions.userId))
      .innerJoin(permissions, eq(userPermissions.permissionId, permissions.id))
      .where(and(
        eq(users.companyId, companyId),
        eq(permissions.name, permissionName),
        eq(userPermissions.isActive, true),
        eq(permissions.isActive, true),
        eq(users.isActive, true)
      ));
  }

  // Enhanced Permission Request methods implementation
  async getPermissionRequestsEnhanced(companyId: number): Promise<PermissionRequest[]> {
    return await db.select().from(permissionRequests)
      .where(eq(permissionRequests.companyId, companyId))
      .orderBy(desc(permissionRequests.createdAt));
  }

  async getPermissionRequestsByUserEnhanced(userId: number): Promise<PermissionRequest[]> {
    return await db.select().from(permissionRequests)
      .where(eq(permissionRequests.userId, userId))
      .orderBy(desc(permissionRequests.createdAt));
  }

  async getPendingPermissionRequests(companyId: number): Promise<PermissionRequest[]> {
    return await db.select().from(permissionRequests)
      .where(and(
        eq(permissionRequests.companyId, companyId),
        eq(permissionRequests.status, 'pending')
      ))
      .orderBy(desc(permissionRequests.createdAt));
  }

  async createPermissionRequestEnhanced(request: InsertPermissionRequest): Promise<PermissionRequest> {
    const [created] = await db.insert(permissionRequests).values(request).returning();
    return created;
  }

  async updatePermissionRequestEnhanced(id: number, request: Partial<PermissionRequest>): Promise<PermissionRequest> {
    const [updated] = await db.update(permissionRequests)
      .set({ ...request, updatedAt: new Date() })
      .where(eq(permissionRequests.id, id))
      .returning();
    return updated;
  }

  async approvePermissionRequestLevel(id: number, reviewerId: number, level: 'level1' | 'level2' | 'final', comments?: string): Promise<PermissionRequest> {
    let updateData: any = { updatedAt: new Date() };
    
    if (level === 'level1') {
      updateData.level1ReviewerId = reviewerId;
      updateData.level1ReviewedAt = new Date();
      updateData.level1Comments = comments;
    } else if (level === 'level2') {
      updateData.level2ReviewerId = reviewerId;
      updateData.level2ReviewedAt = new Date();
      updateData.level2Comments = comments;
    } else if (level === 'final') {
      updateData.finalReviewerId = reviewerId;
      updateData.finalReviewedAt = new Date();
      updateData.finalComments = comments;
      updateData.status = 'approved';
    }

    const [updated] = await db.update(permissionRequests)
      .set(updateData)
      .where(eq(permissionRequests.id, id))
      .returning();
    return updated;
  }

  async rejectPermissionRequestLevel(id: number, reviewerId: number, level: 'level1' | 'level2' | 'final', comments?: string): Promise<PermissionRequest> {
    let updateData: any = { 
      status: 'rejected',
      updatedAt: new Date()
    };
    
    if (level === 'level1') {
      updateData.level1ReviewerId = reviewerId;
      updateData.level1ReviewedAt = new Date();
      updateData.level1Comments = comments;
    } else if (level === 'level2') {
      updateData.level2ReviewerId = reviewerId;
      updateData.level2ReviewedAt = new Date();
      updateData.level2Comments = comments;
    } else if (level === 'final') {
      updateData.finalReviewerId = reviewerId;
      updateData.finalReviewedAt = new Date();
      updateData.finalComments = comments;
    }

    const [updated] = await db.update(permissionRequests)
      .set(updateData)
      .where(eq(permissionRequests.id, id))
      .returning();
    return updated;
  }

  // Role Permission methods implementation
  async getRolePermissionsEnhanced(role: string, companyId?: number): Promise<RolePermission[]> {
    if (companyId) {
      return await db.select().from(rolePermissions)
        .where(and(
          eq(rolePermissions.role, role),
          eq(rolePermissions.companyId, companyId)
        ));
    }
    return await db.select().from(rolePermissions)
      .where(eq(rolePermissions.role, role));
  }

  async assignRolePermission(rolePermission: InsertRolePermission): Promise<RolePermission> {
    const [assigned] = await db.insert(rolePermissions).values(rolePermission).returning();
    return assigned;
  }

  async removeRolePermission(role: string, permissionId: number, companyId?: number): Promise<void> {
    if (companyId) {
      await db.delete(rolePermissions)
        .where(and(
          eq(rolePermissions.role, role),
          eq(rolePermissions.permissionId, permissionId),
          eq(rolePermissions.companyId, companyId)
        ));
    } else {
      await db.delete(rolePermissions)
        .where(and(
          eq(rolePermissions.role, role),
          eq(rolePermissions.permissionId, permissionId)
        ));
    }
  }

  // Permission Template methods implementation
  async getPermissionTemplates(role?: string): Promise<PermissionTemplate[]> {
    if (role) {
      return await db.select().from(permissionTemplates)
        .where(eq(permissionTemplates.role, role))
        .orderBy(permissionTemplates.name);
    }
    return await db.select().from(permissionTemplates).orderBy(permissionTemplates.name);
  }

  async createPermissionTemplate(template: InsertPermissionTemplate): Promise<PermissionTemplate> {
    const [created] = await db.insert(permissionTemplates).values(template).returning();
    return created;
  }

  async updatePermissionTemplate(id: number, template: Partial<PermissionTemplate>): Promise<PermissionTemplate> {
    const [updated] = await db.update(permissionTemplates)
      .set({ ...template, updatedAt: new Date() })
      .where(eq(permissionTemplates.id, id))
      .returning();
    return updated;
  }

  async deletePermissionTemplate(id: number): Promise<void> {
    await db.delete(permissionTemplates).where(eq(permissionTemplates.id, id));
  }

  async applyPermissionTemplate(templateId: number, userId: number, companyId: number, grantedBy: number): Promise<UserPermission[]> {
    const template = await db.select().from(permissionTemplates).where(eq(permissionTemplates.id, templateId));
    if (!template[0]) {
      throw new Error('Permission template not found');
    }

    const permissionIds = JSON.parse(template[0].permissionIds);
    const userPermissions: InsertUserPermission[] = permissionIds.map((permissionId: number) => ({
      userId,
      permissionId,
      companyId,
      grantedBy,
      reason: `Applied from template: ${template[0].name}`
    }));

    const granted = await db.insert(userPermissions).values(userPermissions).returning();
    return granted;
  }

  // Company Settings methods implementation
  // Biometric Machine methods
  async getBiometricMachinesByCompany(companyId: number): Promise<any[]> {
    return await db.select().from(biometricMachines)
      .where(eq(biometricMachines.companyId, companyId))
      .orderBy(biometricMachines.serialNumber);
  }

  async createBiometricMachine(machine: any): Promise<any> {
    const [created] = await db.insert(biometricMachines).values(machine).returning();
    return created;
  }

  async updateBiometricMachine(id: number, machine: any): Promise<any> {
    const [updated] = await db.update(biometricMachines)
      .set({ ...machine, updatedAt: new Date() })
      .where(eq(biometricMachines.id, id))
      .returning();
    return updated;
  }

  async deleteBiometricMachine(id: number): Promise<void> {
    await db.delete(biometricMachines).where(eq(biometricMachines.id, id));
  }

  // Holiday methods
  async getHolidaysByCompany(companyId: number): Promise<any[]> {
    return await db.select().from(holidays)
      .where(eq(holidays.companyId, companyId))
      .orderBy(holidays.date);
  }

  async createHoliday(holiday: any): Promise<any> {
    const [created] = await db.insert(holidays).values(holiday).returning();
    return created;
  }

  async updateHoliday(id: number, holiday: any): Promise<any> {
    const [updated] = await db.update(holidays)
      .set({ ...holiday, updatedAt: new Date() })
      .where(eq(holidays.id, id))
      .returning();
    return updated;
  }

  async deleteHoliday(id: number): Promise<void> {
    await db.delete(holidays).where(eq(holidays.id, id));
  }

  // Leave Policy methods
  async getLeavePoliciesByCompany(companyId: number): Promise<any[]> {
    return await db.select().from(leavePolicies)
      .where(eq(leavePolicies.companyId, companyId))
      .orderBy(leavePolicies.name);
  }

  async createLeavePolicy(policy: any): Promise<any> {
    const [created] = await db.insert(leavePolicies).values(policy).returning();
    return created;
  }

  async updateLeavePolicy(id: number, policy: any): Promise<any> {
    const [updated] = await db.update(leavePolicies)
      .set({ ...policy, updatedAt: new Date() })
      .where(eq(leavePolicies.id, id))
      .returning();
    return updated;
  }

  async deleteLeavePolicy(id: number): Promise<void> {
    await db.delete(leavePolicies).where(eq(leavePolicies.id, id));
  }

  // Designation methods
  async getDesignationsByCompany(companyId: number): Promise<any[]> {
    return await db.select().from(designations)
      .where(eq(designations.companyId, companyId))
      .orderBy(designations.title);
  }

  async createDesignation(designation: any): Promise<any> {
    const [created] = await db.insert(designations).values(designation).returning();
    return created;
  }

  async updateDesignation(id: number, designation: any): Promise<any> {
    const [updated] = await db.update(designations)
      .set({ ...designation, updatedAt: new Date() })
      .where(eq(designations.id, id))
      .returning();
    return updated;
  }

  async deleteDesignation(id: number): Promise<void> {
    await db.delete(designations).where(eq(designations.id, id));
  }

  // Branch methods
  async getBranchesByCompany(companyId: number): Promise<any[]> {
    return await db.select().from(branches)
      .where(eq(branches.companyId, companyId))
      .orderBy(branches.name);
  }

  async createBranch(branch: any): Promise<any> {
    const [created] = await db.insert(branches).values(branch).returning();
    return created;
  }

  async updateBranch(id: number, branch: any): Promise<any> {
    const [updated] = await db.update(branches)
      .set({ ...branch, updatedAt: new Date() })
      .where(eq(branches.id, id))
      .returning();
    return updated;
  }

  async deleteBranch(id: number): Promise<void> {
    await db.delete(branches).where(eq(branches.id, id));
  }

  // Location methods  
  async getLocationsByCompany(companyId: number): Promise<any[]> {
    return await db.select().from(locations)
      .where(eq(locations.companyId, companyId))
      .orderBy(locations.name);
  }

  async createLocation(location: any): Promise<any> {
    const [created] = await db.insert(locations).values(location).returning();
    return created;
  }

  async updateLocation(id: number, location: any): Promise<any> {
    const [updated] = await db.update(locations)
      .set({ ...location, updatedAt: new Date() })
      .where(eq(locations.id, id))
      .returning();
    return updated;
  }

  async deleteLocation(id: number): Promise<void> {
    await db.delete(locations).where(eq(locations.id, id));
  }

  // Cost Center methods
  async getCostCentersByCompany(companyId: number): Promise<any[]> {
    return await db.select().from(costCenters)
      .where(eq(costCenters.companyId, companyId))
      .orderBy(costCenters.code);
  }

  async createCostCenter(costCenter: any): Promise<any> {
    const [created] = await db.insert(costCenters).values(costCenter).returning();
    return created;
  }

  async updateCostCenter(id: number, costCenter: any): Promise<any> {
    const [updated] = await db.update(costCenters)
      .set({ ...costCenter, updatedAt: new Date() })
      .where(eq(costCenters.id, id))
      .returning();
    return updated;
  }

  async deleteCostCenter(id: number): Promise<void> {
    await db.delete(costCenters).where(eq(costCenters.id, id));
  }
  // Client Compliances Management
  async getClientsByCompany(companyId: number): Promise<Client[]> {
    return await db
      .select()
      .from(clients)
      .where(eq(clients.companyId, companyId))
      .orderBy(clients.projectName);
  }

  async createClient(clientData: InsertClient): Promise<Client> {
    const [client] = await db
      .insert(clients)
      .values(clientData)
      .returning();
    return client;
  }

  async updateClient(id: number, clientData: Partial<Client>): Promise<Client> {
    const [client] = await db
      .update(clients)
      .set({ ...clientData, updatedAt: new Date() })
      .where(eq(clients.id, id))
      .returning();
    return client;
  }

  async deleteClient(id: number): Promise<void> {
    await db.delete(clients).where(eq(clients.id, id));
  }

  async getComplianceSetupsByCompany(companyId: number): Promise<any[]> {
    return await db
      .select({
        id: complianceSetups.id,
        companyId: complianceSetups.companyId,
        employeeId: complianceSetups.employeeId,
        basicSalary: complianceSetups.basicSalary,
        grossSalary: complianceSetups.grossSalary,
        differenceAdjustment: complianceSetups.differenceAdjustment,
        pfType: complianceSetups.pfType,
        esicType: complianceSetups.esicType,
        bonusType: complianceSetups.bonusType,
        createdAt: complianceSetups.createdAt,
        updatedAt: complianceSetups.updatedAt,
        employee: employees
      })
      .from(complianceSetups)
      .leftJoin(employees, eq(complianceSetups.employeeId, employees.id))
      .where(eq(complianceSetups.companyId, companyId));
  }

  async createComplianceSetup(setupData: InsertComplianceSetup): Promise<ComplianceSetup> {
    const [setup] = await db
      .insert(complianceSetups)
      .values(setupData)
      .returning();
    return setup;
  }

  async updateComplianceSetup(id: number, setupData: Partial<ComplianceSetup>): Promise<ComplianceSetup> {
    const [setup] = await db
      .update(complianceSetups)
      .set({ ...setupData, updatedAt: new Date() })
      .where(eq(complianceSetups.id, id))
      .returning();
    return setup;
  }

  async deleteComplianceSetup(id: number): Promise<void> {
    await db.delete(complianceSetups).where(eq(complianceSetups.id, id));
  }

  async getCompliancesDataByProjectAndMonth(companyId: number, projectId: number, month: string): Promise<any[]> {
    return await db
      .select({
        id: compliancesData.id,
        companyId: compliancesData.companyId,
        projectId: compliancesData.projectId,
        employeeId: compliancesData.employeeId,
        month: compliancesData.month,
        actualPayable: compliancesData.actualPayable,
        compliancesGross: compliancesData.compliancesGross,
        compliancesAttendance: compliancesData.compliancesAttendance,
        compliancesOT: compliancesData.compliancesOT,
        compliancesGrossEarn: compliancesData.compliancesGrossEarn,
        pfDeduction: compliancesData.pfDeduction,
        esicDeduction: compliancesData.esicDeduction,
        netPayableAmount: compliancesData.netPayableAmount,
        differenceAmount: compliancesData.differenceAmount,
        createdAt: compliancesData.createdAt,
        updatedAt: compliancesData.updatedAt,
        employee: employees
      })
      .from(compliancesData)
      .leftJoin(employees, eq(compliancesData.employeeId, employees.id))
      .where(
        and(
          eq(compliancesData.companyId, companyId),
          eq(compliancesData.projectId, projectId),
          eq(compliancesData.month, month)
        )
      );
  }

  async getCompliancesDataByCompany(companyId: number): Promise<CompliancesData[]> {
    return await db
      .select()
      .from(compliancesData)
      .where(eq(compliancesData.companyId, companyId))
      .orderBy(compliancesData.month);
  }

  async createCompliancesData(complianceData: InsertCompliancesData): Promise<CompliancesData> {
    const [data] = await db
      .insert(compliancesData)
      .values(complianceData)
      .returning();
    return data;
  }

  async updateCompliancesData(id: number, complianceData: Partial<CompliancesData>): Promise<CompliancesData> {
    const [data] = await db
      .update(compliancesData)
      .set({ ...complianceData, updatedAt: new Date() })
      .where(eq(compliancesData.id, id))
      .returning();
    return data;
  }

  async deleteCompliancesData(id: number): Promise<void> {
    await db.delete(compliancesData).where(eq(compliancesData.id, id));
  }

  // Auto-generate compliance data based on assignments and setups
  async autoGenerateComplianceData(companyId: number, employeeId: number, projectId: number): Promise<void> {
    const currentDate = new Date();
    const currentMonth = currentDate.toISOString().slice(0, 7); // YYYY-MM format

    // Check if compliance data already exists for this combination
    const existingData = await db
      .select()
      .from(compliancesData)
      .where(
        and(
          eq(compliancesData.companyId, companyId),
          eq(compliancesData.employeeId, employeeId),
          eq(compliancesData.projectId, projectId),
          eq(compliancesData.month, currentMonth)
        )
      );

    if (existingData.length > 0) {
      return; // Data already exists, no need to regenerate
    }

    // Get employee's payroll setup for realistic calculations
    const payrollSetup = await db
      .select()
      .from(employeePayroll)
      .where(eq(employeePayroll.employeeId, employeeId))
      .limit(1);

    // Generate realistic compliance data based on payroll setup
    const grossValue = payrollSetup[0]?.grossValue ? parseFloat(payrollSetup[0].grossValue) : 35000;
    const basicSalary = payrollSetup[0]?.earningHead1 ? parseFloat(payrollSetup[0].earningHead1) : grossValue * 0.5;
    
    // Calculate realistic values
    const actualPayable = grossValue + (Math.random() * 5000 - 2500); // ±2500 variance
    const compliancesGross = grossValue * (0.95 + Math.random() * 0.1); // 95-105% of gross
    const compliancesAttendance = Math.floor(Math.random() * 8) + 20; // 20-27 days
    const compliancesOT = Math.floor(Math.random() * 20); // 0-20 hours
    const compliancesGrossEarn = compliancesGross + (compliancesOT * 200); // OT at 200/hour
    
    // Calculate deductions based on payroll setup
    const pfDeduction = payrollSetup[0]?.epfEnabled ? basicSalary * 0.12 : 0;
    const esicDeduction = payrollSetup[0]?.esicEnabled ? grossValue * 0.0075 : 0;
    const netPayableAmount = compliancesGrossEarn - pfDeduction - esicDeduction;
    const differenceAmount = actualPayable - netPayableAmount;

    // Create compliance data record
    await db.insert(compliancesData).values({
      companyId,
      projectId,
      employeeId,
      month: currentMonth,
      actualPayable: actualPayable.toFixed(2),
      compliancesGross: compliancesGross.toFixed(2),
      compliancesAttendance,
      compliancesOT,
      compliancesGrossEarn: compliancesGrossEarn.toFixed(2),
      pfDeduction: pfDeduction.toFixed(2),
      esicDeduction: esicDeduction.toFixed(2),
      netPayableAmount: netPayableAmount.toFixed(2),
      differenceAmount: differenceAmount.toFixed(2),
    });
  }

  // Generate compliance data for all assigned employees in a project
  async generateComplianceDataForProject(companyId: number, projectId: number): Promise<void> {
    // Get all employees assigned to this project
    const assignments = await db
      .select()
      .from(employeeAssignments)
      .where(
        and(
          eq(employeeAssignments.companyId, companyId),
          eq(employeeAssignments.projectId, projectId),
          isNull(employeeAssignments.deAssignDate) // Only active assignments
        )
      );

    // Generate compliance data for each assigned employee
    for (const assignment of assignments) {
      await this.autoGenerateComplianceData(companyId, assignment.employeeId, projectId);
    }
  }

  // Employee Assignment methods
  async getEmployeeAssignmentsByCompany(companyId: number): Promise<EmployeeAssignment[]> {
    return await db
      .select({
        id: employeeAssignments.id,
        companyId: employeeAssignments.companyId,
        employeeId: employeeAssignments.employeeId,
        designationId: employeeAssignments.designationId,
        assignDate: employeeAssignments.assignDate,
        deassignDate: employeeAssignments.deassignDate,
        address: employeeAssignments.address,
        createdAt: employeeAssignments.createdAt,
        updatedAt: employeeAssignments.updatedAt,
        employee: {
          id: employees.id,
          firstName: employees.firstName,
          lastName: employees.lastName,
          address: employees.address,
        },
        designation: {
          id: designations.id,
          title: designations.title,
        },
      })
      .from(employeeAssignments)
      .leftJoin(employees, eq(employeeAssignments.employeeId, employees.id))
      .leftJoin(designations, eq(employeeAssignments.designationId, designations.id))
      .where(eq(employeeAssignments.companyId, companyId))
      .orderBy(employeeAssignments.createdAt);
  }

  async createEmployeeAssignment(assignmentData: InsertEmployeeAssignment): Promise<EmployeeAssignment> {
    const [assignment] = await db
      .insert(employeeAssignments)
      .values(assignmentData)
      .returning();
    return assignment;
  }

  async getEmployeeAssignmentsByEmployee(employeeId: number): Promise<EmployeeAssignment[]> {
    return await db
      .select()
      .from(employeeAssignments)
      .where(eq(employeeAssignments.employeeId, employeeId));
  }

  async updateEmployeeAssignment(id: number, assignmentData: Partial<EmployeeAssignment>): Promise<EmployeeAssignment> {
    const [assignment] = await db
      .update(employeeAssignments)
      .set({ ...assignmentData, updatedAt: new Date() })
      .where(eq(employeeAssignments.id, id))
      .returning();
    return assignment;
  }

  async deleteEmployeeAssignment(id: number): Promise<void> {
    await db.delete(employeeAssignments).where(eq(employeeAssignments.id, id));
  }

  // Aadhaar verification methods implementation
  async checkEmployeeByAadhaar(aadhaarNo: string): Promise<Employee | null> {
    const result = await db.select()
      .from(employees)
      .innerJoin(kycDetails, eq(employees.id, kycDetails.employeeProfileId))
      .where(eq(kycDetails.aadharNo, aadhaarNo))
      .limit(1);
    
    return result.length > 0 ? result[0].employees : null;
  }

  async getEmployeeStatusByAadhaar(aadhaarNo: string): Promise<{
    isEmployeeInCompany: boolean;
    employeeData?: Employee;
    companyData?: Company;
  }> {
    console.log('Checking employee status for Aadhaar:', aadhaarNo);
    
    // First check if the KYC record exists and get the employee profile
    const kycResult = await db.select({
      kycDetails: kycDetails,
      employeeProfile: employeeProfiles
    })
      .from(kycDetails)
      .innerJoin(employeeProfiles, eq(kycDetails.employeeProfileId, employeeProfiles.id))
      .where(eq(kycDetails.aadharNo, aadhaarNo))
      .limit(1);
    
    console.log('KYC result:', kycResult);
    
    if (kycResult.length === 0) {
      console.log('No KYC record found for Aadhaar:', aadhaarNo);
      return { isEmployeeInCompany: false };
    }
    
    const employeeProfile = kycResult[0].employeeProfile;
    
    // Now check if this user has an employee record in any company
    const employeeResult = await db.select({
      employee: employees,
      company: companies
    })
      .from(employees)
      .innerJoin(companies, eq(employees.companyId, companies.id))
      .where(and(
        eq(employees.userId, employeeProfile.userId),
        eq(employees.status, 'active')
      ))
      .limit(1);
    
    console.log('Employee result:', employeeResult);
    
    if (employeeResult.length > 0) {
      console.log('Employee found in company:', employeeResult[0].company.name);
      return {
        isEmployeeInCompany: true,
        employeeData: employeeResult[0].employee,
        companyData: employeeResult[0].company
      };
    }
    
    console.log('Employee not found in any company');
    return {
      isEmployeeInCompany: false
    };
  }

  // Employee portal methods implementation
  async getEmployeeProfileByAadhaar(aadhaarNo: string): Promise<EmployeeProfile | undefined> {
    const result = await db.select({
      employeeProfile: employeeProfiles
    })
      .from(kycDetails)
      .innerJoin(employeeProfiles, eq(kycDetails.employeeProfileId, employeeProfiles.id))
      .where(eq(kycDetails.aadharNo, aadhaarNo))
      .limit(1);
    
    return result.length > 0 ? result[0].employeeProfile : undefined;
  }

  // Salary Component methods implementation
  async getSalaryComponents(): Promise<SalaryComponent[]> {
    return await db.select().from(salaryComponents).orderBy(salaryComponents.componentKey);
  }

  async createSalaryComponent(component: InsertSalaryComponent): Promise<SalaryComponent> {
    const [newComponent] = await db.insert(salaryComponents).values(component).returning();
    return newComponent;
  }

  async updateSalaryComponent(id: number, component: Partial<SalaryComponent>): Promise<SalaryComponent> {
    const [updatedComponent] = await db.update(salaryComponents)
      .set(component)
      .where(eq(salaryComponents.id, id))
      .returning();
    return updatedComponent;
  }

  async deleteSalaryComponent(id: number): Promise<void> {
    await db.delete(salaryComponents).where(eq(salaryComponents.id, id));
  }

  // Company Salary Component Configuration methods implementation
  async getCompanySalaryComponentConfig(companyId: number, entryMode?: string): Promise<CompanySalaryComponentConfig[]> {
    const query = db.select().from(companySalaryComponentConfig)
      .where(and(
        eq(companySalaryComponentConfig.companyId, companyId),
        eq(companySalaryComponentConfig.isActive, true),
        entryMode ? eq(companySalaryComponentConfig.entryMode, entryMode) : undefined
      ))
      .orderBy(companySalaryComponentConfig.priority, companySalaryComponentConfig.componentKey);

    return await query;
  }

  async createCompanySalaryComponentConfig(config: InsertCompanySalaryComponentConfig): Promise<CompanySalaryComponentConfig> {
    const [newConfig] = await db.insert(companySalaryComponentConfig).values(config).returning();
    return newConfig;
  }

  async updateCompanySalaryComponentConfig(id: number, config: Partial<CompanySalaryComponentConfig>): Promise<CompanySalaryComponentConfig> {
    const [updatedConfig] = await db.update(companySalaryComponentConfig)
      .set({
        ...config,
        updatedAt: new Date()
      })
      .where(eq(companySalaryComponentConfig.id, id))
      .returning();
    return updatedConfig;
  }

  async deleteCompanySalaryComponentConfig(id: number): Promise<void> {
    await db.delete(companySalaryComponentConfig).where(eq(companySalaryComponentConfig.id, id));
  }

  async upsertCompanySalaryComponentConfig(config: InsertCompanySalaryComponentConfig): Promise<CompanySalaryComponentConfig> {
    // Check if config already exists
    const existing = await db.select()
      .from(companySalaryComponentConfig)
      .where(and(
        eq(companySalaryComponentConfig.companyId, config.companyId),
        eq(companySalaryComponentConfig.componentKey, config.componentKey),
        eq(companySalaryComponentConfig.entryMode, config.entryMode)
      ))
      .limit(1);

    if (existing.length > 0) {
      // Update existing
      return await this.updateCompanySalaryComponentConfig(existing[0].id, config);
    } else {
      // Create new
      return await this.createCompanySalaryComponentConfig(config);
    }
  }

  // Employee Salary Component Values methods implementation
  async getEmployeeSalaryComponentValues(structureId: number): Promise<EmployeeSalaryComponentValues[]> {
    return await db.select()
      .from(employeeSalaryComponentValues)
      .where(eq(employeeSalaryComponentValues.structureId, structureId))
      .orderBy(employeeSalaryComponentValues.componentKey);
  }

  async createEmployeeSalaryComponentValues(values: InsertEmployeeSalaryComponentValues): Promise<EmployeeSalaryComponentValues> {
    const [newValues] = await db.insert(employeeSalaryComponentValues).values(values).returning();
    return newValues;
  }

  async updateEmployeeSalaryComponentValues(id: number, values: Partial<EmployeeSalaryComponentValues>): Promise<EmployeeSalaryComponentValues> {
    const [updatedValues] = await db.update(employeeSalaryComponentValues)
      .set(values)
      .where(eq(employeeSalaryComponentValues.id, id))
      .returning();
    return updatedValues;
  }

  async deleteEmployeeSalaryComponentValues(id: number): Promise<void> {
    await db.delete(employeeSalaryComponentValues).where(eq(employeeSalaryComponentValues.id, id));
  }

  async bulkCreateEmployeeSalaryComponentValues(values: InsertEmployeeSalaryComponentValues[]): Promise<EmployeeSalaryComponentValues[]> {
    if (values.length === 0) return [];
    return await db.insert(employeeSalaryComponentValues).values(values).returning();
  }

  async deleteEmployeeSalaryComponentValuesByStructure(structureId: number): Promise<void> {
    await db.delete(employeeSalaryComponentValues)
      .where(eq(employeeSalaryComponentValues.structureId, structureId));
  }
}

export const storage = new DatabaseStorage();
