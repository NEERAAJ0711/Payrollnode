import { db } from './db';
import { permissions, permissionTemplates, rolePermissions } from '@shared/schema';

const permissionsData = [
  // Employee Management Permissions
  { name: 'employee_create', description: 'Create new employee records', category: 'employee_management', module: 'employees' },
  { name: 'employee_read', description: 'View employee information', category: 'employee_management', module: 'employees' },
  { name: 'employee_update', description: 'Edit employee records', category: 'employee_management', module: 'employees' },
  { name: 'employee_delete', description: 'Delete employee records', category: 'employee_management', module: 'employees' },
  { name: 'employee_payroll_view', description: 'View employee payroll information', category: 'payroll', module: 'payroll' },
  { name: 'employee_payroll_edit', description: 'Edit employee payroll settings', category: 'payroll', module: 'payroll' },

  // Attendance Permissions
  { name: 'attendance_view_all', description: 'View all employee attendance records', category: 'attendance', module: 'attendance' },
  { name: 'attendance_edit', description: 'Edit attendance records', category: 'attendance', module: 'attendance' },
  { name: 'attendance_delete', description: 'Delete attendance records', category: 'attendance', module: 'attendance' },
  { name: 'attendance_export', description: 'Export attendance reports', category: 'attendance', module: 'attendance' },

  // Payroll Permissions
  { name: 'payroll_create', description: 'Create monthly payroll runs', category: 'payroll', module: 'payroll' },
  { name: 'payroll_finalize', description: 'Finalize payroll runs', category: 'payroll', module: 'payroll' },
  { name: 'payroll_view_all', description: 'View all payroll records', category: 'payroll', module: 'payroll' },
  { name: 'payroll_payment_update', description: 'Update payment status for payroll records', category: 'payroll', module: 'payroll' },

  // Recruitment Permissions
  { name: 'job_create', description: 'Create job postings', category: 'recruitment', module: 'recruitment' },
  { name: 'job_edit', description: 'Edit job postings', category: 'recruitment', module: 'recruitment' },
  { name: 'job_delete', description: 'Delete job postings', category: 'recruitment', module: 'recruitment' },
  { name: 'application_review', description: 'Review job applications', category: 'recruitment', module: 'recruitment' },
  { name: 'interview_schedule', description: 'Schedule interviews', category: 'recruitment', module: 'recruitment' },
  { name: 'offer_create', description: 'Create job offers', category: 'recruitment', module: 'recruitment' },

  // Leave Management Permissions
  { name: 'leave_request_approve', description: 'Approve leave requests', category: 'leave_management', module: 'leave' },
  { name: 'leave_request_reject', description: 'Reject leave requests', category: 'leave_management', module: 'leave' },
  { name: 'leave_balance_view', description: 'View leave balances for all employees', category: 'leave_management', module: 'leave' },
  { name: 'leave_policy_manage', description: 'Manage leave policies', category: 'leave_management', module: 'leave' },

  // Advance Request Permissions
  { name: 'advance_request_approve', description: 'Approve advance salary requests', category: 'advance_management', module: 'advance' },
  { name: 'advance_request_reject', description: 'Reject advance salary requests', category: 'advance_management', module: 'advance' },
  { name: 'advance_payment_mark', description: 'Mark advance payments as paid', category: 'advance_management', module: 'advance' },

  // Company Settings Permissions
  { name: 'company_settings', description: 'Access company settings', category: 'company_management', module: 'company' },
  { name: 'company_settings_view', description: 'View company settings', category: 'company_management', module: 'company' },
  { name: 'company_settings_edit', description: 'Edit company settings', category: 'company_management', module: 'company' },
  { name: 'department_manage', description: 'Manage departments', category: 'company_management', module: 'company' },
  { name: 'branch_manage', description: 'Manage company branches', category: 'company_management', module: 'company' },

  // User Management Permissions
  { name: 'user_create', description: 'Create new user accounts', category: 'user_management', module: 'users' },
  { name: 'user_edit', description: 'Edit user accounts', category: 'user_management', module: 'users' },
  { name: 'user_delete', description: 'Delete user accounts', category: 'user_management', module: 'users' },
  { name: 'user_permission_grant', description: 'Grant permissions to users', category: 'user_management', module: 'users' },

  // Reporting Permissions
  { name: 'reports_generate', description: 'Generate HR reports', category: 'reporting', module: 'reports' },
  { name: 'reports_export', description: 'Export reports to various formats', category: 'reporting', module: 'reports' },
  { name: 'dashboard_view_all', description: 'View comprehensive dashboard data', category: 'reporting', module: 'dashboard' }
];

// Skip permission templates for now since we need to check if that table exists

export async function seedPermissions() {
  try {
    console.log('Seeding permissions...');
    
    // Check if permissions already exist
    const existingPermissions = await db.select().from(permissions).limit(1);
    if (existingPermissions.length > 0) {
      console.log('Permissions already exist, skipping permission seeding');
      return;
    }
    
    // Insert permissions
    const insertedPermissions = await db.insert(permissions).values(permissionsData).returning();
    console.log(`Inserted ${insertedPermissions.length} permissions`);

    // Skip permission templates for now
    console.log('Skipping permission templates - checking if table exists');

    // Skip role permissions for now - checking if table exists
    console.log('Skipping role permissions setup - checking if table exists');

    console.log('Permission seeding completed successfully!');
  } catch (error) {
    console.error('Error seeding permissions:', error);
    throw error;
  }
}