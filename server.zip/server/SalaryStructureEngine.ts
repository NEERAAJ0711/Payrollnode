import { db } from "./db";
import { 
  salaryComponents, 
  companySalaryComponentConfig, 
  employeeSalaryStructures,
  employeeSalaryComponentValues,
  salaryEntryModeEnum 
} from "../shared/schema";
import { eq, and } from "drizzle-orm";

// Types for the salary calculation engine
export interface SalaryComponent {
  componentKey: string;
  displayName: string;
  isTaxable: boolean;
  isEmployerCost: boolean;
  amount: number;
  calculatedFromPercentage: boolean;
}

export interface SalaryCalculationResult {
  mode: 'gross' | 'ctc' | 'earning_heads';
  ctcValue: number;
  grossValue: number;
  netPay?: number;
  components: SalaryComponent[];
  employerCosts: SalaryComponent[];
  deductions?: SalaryComponent[];
  configSnapshot: string; // JSON of percentages used
}

export interface ComponentConfig {
  componentKey: string;
  displayName: string;
  percentageOfGross?: number;
  percentageOfCTC?: number;
  priority: number;
  isTaxable: boolean;
  isEmployerCost: boolean;
}

export class SalaryStructureEngine {
  
  /**
   * Get salary component configuration for a company
   */
  static async getCompanyComponentConfig(companyId: number, mode: 'gross' | 'ctc' | 'earning_heads'): Promise<ComponentConfig[]> {
    const configs = await db
      .select({
        componentKey: companySalaryComponentConfig.componentKey,
        displayName: salaryComponents.displayName,
        percentageOfGross: companySalaryComponentConfig.percentageOfGross,
        percentageOfCTC: companySalaryComponentConfig.percentageOfCTC,
        priority: companySalaryComponentConfig.priority,
        isTaxable: salaryComponents.isTaxable,
        isEmployerCost: salaryComponents.isEmployerCost,
      })
      .from(companySalaryComponentConfig)
      .leftJoin(salaryComponents, eq(companySalaryComponentConfig.componentKey, salaryComponents.componentKey))
      .where(
        and(
          eq(companySalaryComponentConfig.companyId, companyId),
          eq(companySalaryComponentConfig.entryMode, mode),
          eq(companySalaryComponentConfig.isActive, true)
        )
      )
      .orderBy(companySalaryComponentConfig.priority);

    // Return default configuration if none exists
    if (configs.length === 0) {
      return this.getDefaultComponentConfig(mode);
    }

    return configs.map(config => ({
      componentKey: config.componentKey,
      displayName: config.displayName || '',
      percentageOfGross: config.percentageOfGross ? parseFloat(config.percentageOfGross) : undefined,
      percentageOfCTC: config.percentageOfCTC ? parseFloat(config.percentageOfCTC) : undefined,
      priority: config.priority ?? 0,
      isTaxable: config.isTaxable ?? true,
      isEmployerCost: config.isEmployerCost ?? false,
    }));
  }

  /**
   * Get default component configuration for a mode with custom limits
   */
  static getDefaultComponentConfig(mode: 'gross' | 'ctc' | 'earning_heads'): ComponentConfig[] {
    const configs: ComponentConfig[] = [
      { componentKey: 'basic', displayName: 'Basic Salary', percentageOfGross: 60, percentageOfCTC: 60, priority: 1, isTaxable: true, isEmployerCost: false },
      { componentKey: 'hra', displayName: 'House Rent Allowance', percentageOfGross: 30, percentageOfCTC: 30, priority: 2, isTaxable: true, isEmployerCost: false },
      { componentKey: 'conveyance', displayName: 'Conveyance Allowance', percentageOfGross: 10, percentageOfCTC: 10, priority: 3, isTaxable: true, isEmployerCost: false },
      { componentKey: 'other', displayName: 'Other Allowances', percentageOfGross: 0, percentageOfCTC: 0, priority: 4, isTaxable: true, isEmployerCost: false },
    ];

    return configs.filter(config => {
      if (mode === 'gross') return config.percentageOfGross !== undefined;
      if (mode === 'ctc') return config.percentageOfCTC !== undefined;
      return true;
    });
  }

  /**
   * Calculate component amount using waterfall approach based on gross ranges
   */
  static calculateComponentAmount(componentKey: string, grossAmount: number, basePercentage: number): number {
    // Waterfall approach based on gross salary ranges
    if (grossAmount <= 15000) {
      // For up to 15000 gross: 100% in basic, others zero
      switch (componentKey) {
        case 'basic': return grossAmount;
        case 'hra': return 0;
        case 'conveyance': return 0;
        case 'other': return 0;
        default: return 0;
      }
    } else if (grossAmount <= 22500) {
      // For 15000 to 22500: 15000 in basic, remaining in HRA
      switch (componentKey) {
        case 'basic': return 15000;
        case 'hra': return grossAmount - 15000;
        case 'conveyance': return 0;
        case 'other': return 0;
        default: return 0;
      }
    } else if (grossAmount <= 25000) {
      // For 22500 to 25000: 15000 in basic, 7500 in HRA, remaining in conveyance
      switch (componentKey) {
        case 'basic': return 15000;
        case 'hra': return 7500;
        case 'conveyance': return grossAmount - 15000 - 7500;
        case 'other': return 0;
        default: return 0;
      }
    } else if (grossAmount <= 100000) {
      // For 25000 to 100000: Basic 60%, HRA 30%, Conveyance 10%, Other 0% (NO CAPS)
      switch (componentKey) {
        case 'basic':
          // Basic: 60% of gross (no cap) - round to whole rupees
          return Math.round(grossAmount * 0.6);
        case 'hra':
          // HRA: 30% of gross (no cap) - round to whole rupees
          return Math.round(grossAmount * 0.3);
        case 'conveyance':
          // Conveyance: 10% of gross (no cap) - round to whole rupees
          return Math.round(grossAmount * 0.1);
        case 'other':
          return 0;
        default: return 0;
      }
    } else {
      // For above 100000: Basic 60%, HRA 30%, Conveyance 6%, Other 4% (NO CAPS)
      switch (componentKey) {
        case 'basic':
          // Basic: 60% of gross (no cap) - round to whole rupees
          return Math.round(grossAmount * 0.6);
        case 'hra':
          // HRA: 30% of gross (no cap) - round to whole rupees
          return Math.round(grossAmount * 0.3);
        case 'conveyance':
          // Conveyance: 6% of gross (no cap) - round to whole rupees
          return Math.round(grossAmount * 0.06);
        case 'other':
          // Other Allowances: 4% of gross (no cap) - round to whole rupees
          return Math.round(grossAmount * 0.04);
        default: return 0;
      }
    }
  }

  /**
   * Calculate salary structure from gross amount
   */
  static async calculateFromGross(
    companyId: number,
    grossAmount: number,
    complianceSettings?: any,
    complianceValues?: any
  ): Promise<SalaryCalculationResult> {
    const config = await this.getCompanyComponentConfig(companyId, 'gross');
    const components: SalaryComponent[] = [];
    const employerCosts: SalaryComponent[] = [];

    // Separate employee components from employer costs
    const employeeComponents = config.filter(c => !c.isEmployerCost);
    const employerComponents = config.filter(c => c.isEmployerCost);

    // Calculate employee components based on gross percentages with limits
    for (const configItem of employeeComponents) {
      if (configItem.percentageOfGross) {
        const amount = this.calculateComponentAmount(configItem.componentKey, grossAmount, configItem.percentageOfGross);
        components.push({
          componentKey: configItem.componentKey,
          displayName: configItem.displayName,
          isTaxable: configItem.isTaxable,
          isEmployerCost: false,
          amount,
          calculatedFromPercentage: true,
        });
      }
    }

    // Calculate employer costs based on configuration
    for (const configItem of employerComponents) {
      let amount = 0;
      
      if (configItem.percentageOfGross) {
        // Use configured percentage of gross
        amount = Math.round((grossAmount * configItem.percentageOfGross / 100) * 100) / 100;
      } else {
        // Use compliance settings for statutory calculations
        if (configItem.componentKey === 'epf_employer' && complianceSettings?.epfEnabled !== false) {
          // Calculate PF on all earning heads except HRA
          const hraComponent = components.find(c => c.componentKey === 'hra');
          const pfBaseAmount = grossAmount - (hraComponent ? hraComponent.amount : 0);
          
          let epfLimit = 15000; // Default statutory limit
          if (complianceSettings?.pfLimit) epfLimit = 21000;
          if (complianceSettings?.pfLimitHigher) epfLimit = 25000;
          const epfBasic = Math.min(pfBaseAmount, epfLimit);
          amount = Math.round((epfBasic * 0.12) * 100) / 100;
        } else if (configItem.componentKey === 'esic_employer' && grossAmount <= 25000 && complianceSettings?.esicEnabled !== false) {
          amount = Math.round((grossAmount * 0.0325) * 100) / 100;
        } else if (configItem.componentKey === 'bonus' && complianceSettings?.bonusEnabled !== false && !complianceSettings?.bonusMonthly) {
          // Calculate bonus on gross salary (only add to employer costs if NOT monthly)
          const bonusRate = 0.0833; // 8.33%
          amount = Math.round((grossAmount * bonusRate) * 100) / 100;
        } else if (configItem.componentKey === 'lwf_employer' && complianceSettings?.lwfEnabled !== false) {
          amount = 20; // Fixed amount
        }
      }
      
      if (amount > 0) {
        employerCosts.push({
          componentKey: configItem.componentKey,
          displayName: configItem.displayName,
          isTaxable: configItem.isTaxable,
          isEmployerCost: true,
          amount,
          calculatedFromPercentage: !!configItem.percentageOfGross,
        });
      }
    }

    // If no employer costs configured, use statutory defaults with compliance settings
    if (employerCosts.length === 0) {
      // EPF Employer Contribution
      if (complianceSettings?.epfEnabled !== false) {
        // Calculate PF on all earning heads except HRA
        const hraComponent = components.find(c => c.componentKey === 'hra');
        const pfBaseAmount = grossAmount - (hraComponent ? hraComponent.amount : 0);
        
        let epfLimit = 15000; // Default statutory limit
        if (complianceSettings?.pfLimit) epfLimit = 21000;
        if (complianceSettings?.pfLimitHigher) epfLimit = 25000;
        const epfBasic = Math.min(pfBaseAmount, epfLimit);
        
        employerCosts.push(
          {
            componentKey: 'epf_employer',
            displayName: 'EPF Employer Contribution',
            isTaxable: false,
            isEmployerCost: true,
            amount: Math.round((epfBasic * 0.12) * 100) / 100,
            calculatedFromPercentage: true,
          },
          {
            componentKey: 'epf_admin',
            displayName: 'EPF Admin Charges',
            isTaxable: false,
            isEmployerCost: true,
            amount: Math.round((epfBasic * 0.01) * 100) / 100,
            calculatedFromPercentage: true,
          }
        );
      }

      // Bonus (calculated on gross salary) - only add to employer costs if NOT monthly
      if (complianceSettings?.bonusEnabled !== false && !complianceSettings?.bonusMonthly) {
        employerCosts.push({
          componentKey: 'bonus',
          displayName: 'Bonus',
          isTaxable: false,
          isEmployerCost: true,
          amount: Math.round((grossAmount * 0.0833) * 100) / 100,
          calculatedFromPercentage: true,
        });
      }
      
      // ESIC if applicable
      if (complianceSettings?.esicEnabled !== false && grossAmount <= 25000) {
        employerCosts.push({
          componentKey: 'esic_employer',
          displayName: 'ESIC Employer Contribution',
          isTaxable: false,
          isEmployerCost: true,
          amount: Math.round((grossAmount * 0.0325) * 100) / 100,
          calculatedFromPercentage: true,
        });
      }
      
      // LWF
      if (complianceSettings?.lwfEnabled !== false) {
        employerCosts.push({
          componentKey: 'lwf_employer',
          displayName: 'LWF Employer Contribution',
          isTaxable: false,
          isEmployerCost: true,
          amount: 20,
          calculatedFromPercentage: false,
        });
      }
    }

    // Calculate employee deductions based on compliance settings
    const deductions: SalaryComponent[] = [];
    
    // EPF Employee Deduction
    if (complianceSettings?.epfEnabled !== false) {
      // Calculate PF on all earning heads except HRA
      const hraComponent = components.find(c => c.componentKey === 'hra');
      const pfBaseAmount = grossAmount - (hraComponent ? hraComponent.amount : 0);
      
      let epfLimit = 15000; // Default statutory limit
      if (complianceSettings?.pfLimit) epfLimit = 21000;
      if (complianceSettings?.pfLimitHigher) epfLimit = 25000;
      const epfBasic = Math.min(pfBaseAmount, epfLimit);
      deductions.push({
        componentKey: 'epf_employee',
        displayName: 'EPF Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((epfBasic * 0.12) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // ESIC Employee Deduction
    if (complianceSettings?.esicEnabled !== false && grossAmount <= 25000) {
      deductions.push({
        componentKey: 'esic_employee',
        displayName: 'ESIC Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((grossAmount * 0.0075) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // LWF Employee Deduction
    if (complianceSettings?.lwfEnabled !== false) {
      deductions.push({
        componentKey: 'lwf_employee',
        displayName: 'LWF Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: 10,
        calculatedFromPercentage: false,
      });
    }

    // VPF Employee Deduction
    if (complianceSettings?.vpfEnabled && complianceValues?.vpfPercentage > 0) {
      // Calculate VPF on all earning heads except HRA
      const hraComponent = components.find(c => c.componentKey === 'hra');
      const vpfBaseAmount = grossAmount - (hraComponent ? hraComponent.amount : 0);
      
      deductions.push({
        componentKey: 'vpf_employee',
        displayName: 'VPF Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((vpfBaseAmount * complianceValues.vpfPercentage / 100) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // TDS Deduction
    if (complianceSettings?.tdsEnabled && complianceValues?.tdsPercentage > 0) {
      deductions.push({
        componentKey: 'tds',
        displayName: 'TDS',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((grossAmount * complianceValues.tdsPercentage / 100) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // PT Deduction
    if (complianceSettings?.ptEnabled && complianceValues?.ptAmount > 0) {
      deductions.push({
        componentKey: 'pt',
        displayName: 'Professional Tax',
        isTaxable: false,
        isEmployerCost: false,
        amount: complianceValues.ptAmount,
        calculatedFromPercentage: false,
      });
    }

    // Handle monthly bonus - add to net take home instead of employer cost
    let bonusAddedToNetPay = 0;
    if (complianceSettings?.bonusEnabled !== false && complianceSettings?.bonusMonthly) {
      const bonusAmount = Math.round((grossAmount * 0.0833) * 100) / 100;
      bonusAddedToNetPay = bonusAmount;
      
      // Add monthly bonus as an employee component (earnings)
      components.push({
        componentKey: 'monthly_bonus',
        displayName: 'Monthly Bonus',
        isTaxable: true,
        isEmployerCost: false,
        amount: bonusAmount,
        calculatedFromPercentage: true,
      });
    }

    const totalEmployerCosts = employerCosts.reduce((sum, cost) => sum + cost.amount, 0);
    const totalDeductions = deductions.reduce((sum, deduction) => sum + deduction.amount, 0);
    const ctcValue = Math.round((grossAmount + totalEmployerCosts) * 100) / 100;
    const netPay = Math.round((grossAmount - totalDeductions + bonusAddedToNetPay) * 100) / 100;

    return {
      mode: 'gross',
      ctcValue,
      grossValue: grossAmount,
      netPay,
      components,
      employerCosts,
      deductions,
      configSnapshot: JSON.stringify(config),
    };
  }

  /**
   * Calculate salary structure from CTC amount  
   */
  static async calculateFromCTC(
    companyId: number,
    ctcAmount: number,
    complianceSettings?: any,
    complianceValues?: any
  ): Promise<SalaryCalculationResult> {
    const config = await this.getCompanyComponentConfig(companyId, 'ctc');
    const components: SalaryComponent[] = [];
    const employerCosts: SalaryComponent[] = [];

    // Separate employee components from employer costs
    const employeeComponents = config.filter(c => !c.isEmployerCost);
    const employerComponents = config.filter(c => c.isEmployerCost);

    // Calculate total percentage for employee components
    const totalEmployeePercentage = employeeComponents.reduce((sum, c) => 
      sum + (c.percentageOfCTC || 0), 0);
    
    // Calculate total percentage for employer components
    const totalEmployerPercentage = employerComponents.reduce((sum, c) => 
      sum + (c.percentageOfCTC || 0), 0);

    // Calculate gross as percentage of CTC (total - employer costs)
    const grossPercentageOfCTC = 100 - totalEmployerPercentage;
    const grossAmount = Math.round((ctcAmount * grossPercentageOfCTC / 100) * 100) / 100;

    // Calculate employee components based on CTC percentages with limits
    for (const configItem of employeeComponents) {
      if (configItem.percentageOfCTC) {
        // Use the gross amount for limits calculation to maintain 60/30/10/0 split
        const amount = this.calculateComponentAmount(configItem.componentKey, grossAmount, configItem.percentageOfCTC);
        components.push({
          componentKey: configItem.componentKey,
          displayName: configItem.displayName,
          isTaxable: configItem.isTaxable,
          isEmployerCost: false,
          amount,
          calculatedFromPercentage: true,
        });
      }
    }

    // Calculate employer costs based on CTC percentages
    for (const configItem of employerComponents) {
      if (configItem.percentageOfCTC) {
        const amount = Math.round((ctcAmount * configItem.percentageOfCTC / 100) * 100) / 100;
        employerCosts.push({
          componentKey: configItem.componentKey,
          displayName: configItem.displayName,
          isTaxable: configItem.isTaxable,
          isEmployerCost: true,
          amount,
          calculatedFromPercentage: true,
        });
      }
    }

    // If no employer costs configured, use statutory defaults with compliance settings
    if (employerCosts.length === 0) {
      // EPF Employer Contribution
      if (complianceSettings?.epfEnabled !== false) {
        // Calculate PF on all earning heads except HRA
        const hraComponent = components.find(c => c.componentKey === 'hra');
        const pfBaseAmount = grossAmount - (hraComponent ? hraComponent.amount : 0);
        
        let epfLimit = 15000; // Default statutory limit
        if (complianceSettings?.pfLimit) epfLimit = 21000;
        if (complianceSettings?.pfLimitHigher) epfLimit = 25000;
        const epfBasic = Math.min(pfBaseAmount, epfLimit);
        
        employerCosts.push(
          {
            componentKey: 'epf_employer',
            displayName: 'EPF Employer Contribution',
            isTaxable: false,
            isEmployerCost: true,
            amount: Math.round((epfBasic * 0.12) * 100) / 100,
            calculatedFromPercentage: true,
          },
          {
            componentKey: 'epf_admin',
            displayName: 'EPF Admin Charges',
            isTaxable: false,
            isEmployerCost: true,
            amount: Math.round((epfBasic * 0.01) * 100) / 100,
            calculatedFromPercentage: true,
          }
        );
      }

      // Bonus (calculated on gross salary) - only add to employer costs if NOT monthly
      if (complianceSettings?.bonusEnabled !== false && !complianceSettings?.bonusMonthly) {
        employerCosts.push({
          componentKey: 'bonus',
          displayName: 'Bonus',
          isTaxable: false,
          isEmployerCost: true,
          amount: Math.round((grossAmount * 0.0833) * 100) / 100,
          calculatedFromPercentage: true,
        });
      }

      // ESIC if applicable
      if (complianceSettings?.esicEnabled !== false && grossAmount <= 25000) {
        employerCosts.push({
          componentKey: 'esic_employer',
          displayName: 'ESIC Employer Contribution',
          isTaxable: false,
          isEmployerCost: true,
          amount: Math.round((grossAmount * 0.0325) * 100) / 100,
          calculatedFromPercentage: true,
        });
      }

      // LWF
      if (complianceSettings?.lwfEnabled !== false) {
        employerCosts.push({
          componentKey: 'lwf_employer',
          displayName: 'LWF Employer Contribution',
          isTaxable: false,
          isEmployerCost: true,
          amount: 20,
          calculatedFromPercentage: false,
        });
      }
    }

    // Calculate employee deductions based on compliance settings
    const deductions: SalaryComponent[] = [];
    
    // EPF Employee Deduction
    if (complianceSettings?.epfEnabled !== false) {
      // Calculate PF on all earning heads except HRA
      const hraComponent = components.find(c => c.componentKey === 'hra');
      const pfBaseAmount = grossAmount - (hraComponent ? hraComponent.amount : 0);
      
      let epfLimit = 15000; // Default statutory limit
      if (complianceSettings?.pfLimit) epfLimit = 21000;
      if (complianceSettings?.pfLimitHigher) epfLimit = 25000;
      const epfBasic = Math.min(pfBaseAmount, epfLimit);
      deductions.push({
        componentKey: 'epf_employee',
        displayName: 'EPF Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((epfBasic * 0.12) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // ESIC Employee Deduction
    if (complianceSettings?.esicEnabled !== false && grossAmount <= 25000) {
      deductions.push({
        componentKey: 'esic_employee',
        displayName: 'ESIC Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((grossAmount * 0.0075) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // LWF Employee Deduction
    if (complianceSettings?.lwfEnabled !== false) {
      deductions.push({
        componentKey: 'lwf_employee',
        displayName: 'LWF Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: 10,
        calculatedFromPercentage: false,
      });
    }

    // VPF Employee Deduction
    if (complianceSettings?.vpfEnabled && complianceValues?.vpfPercentage > 0) {
      // Calculate VPF on all earning heads except HRA
      const hraComponent = components.find(c => c.componentKey === 'hra');
      const vpfBaseAmount = grossAmount - (hraComponent ? hraComponent.amount : 0);
      
      deductions.push({
        componentKey: 'vpf_employee',
        displayName: 'VPF Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((vpfBaseAmount * complianceValues.vpfPercentage / 100) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // TDS Deduction
    if (complianceSettings?.tdsEnabled && complianceValues?.tdsPercentage > 0) {
      deductions.push({
        componentKey: 'tds',
        displayName: 'TDS',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((grossAmount * complianceValues.tdsPercentage / 100) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // PT Deduction
    if (complianceSettings?.ptEnabled && complianceValues?.ptAmount > 0) {
      deductions.push({
        componentKey: 'pt',
        displayName: 'Professional Tax',
        isTaxable: false,
        isEmployerCost: false,
        amount: complianceValues.ptAmount,
        calculatedFromPercentage: false,
      });
    }

    // Handle monthly bonus - add to net take home instead of employer cost
    let bonusAddedToNetPay = 0;
    if (complianceSettings?.bonusEnabled !== false && complianceSettings?.bonusMonthly) {
      const bonusAmount = Math.round((grossAmount * 0.0833) * 100) / 100;
      bonusAddedToNetPay = bonusAmount;
      
      // Add monthly bonus as an employee component (earnings)
      components.push({
        componentKey: 'monthly_bonus',
        displayName: 'Monthly Bonus',
        isTaxable: true,
        isEmployerCost: false,
        amount: bonusAmount,
        calculatedFromPercentage: true,
      });
    }

    const totalEmployerCosts = employerCosts.reduce((sum, cost) => sum + cost.amount, 0);
    const totalDeductions = deductions.reduce((sum, deduction) => sum + deduction.amount, 0);
    const netPay = Math.round((grossAmount - totalDeductions + bonusAddedToNetPay) * 100) / 100;

    return {
      mode: 'ctc',
      ctcValue: ctcAmount,
      grossValue: grossAmount,
      netPay,
      components,
      employerCosts,
      deductions,
      configSnapshot: JSON.stringify(config),
    };
  }

  /**
   * Calculate salary structure from earning heads
   */
  static async calculateFromEarningHeads(
    companyId: number,
    components: { componentKey: string; amount: number }[],
    complianceSettings?: any,
    complianceValues?: any
  ): Promise<SalaryCalculationResult> {
    const config = await this.getCompanyComponentConfig(companyId, 'earning_heads');
    const salaryComponents: SalaryComponent[] = [];
    let grossValue = 0;

    // Process each component
    for (const component of components) {
      const configItem = config.find(c => c.componentKey === component.componentKey);
      if (configItem) {
        salaryComponents.push({
          componentKey: component.componentKey,
          displayName: configItem.displayName,
          isTaxable: configItem.isTaxable,
          isEmployerCost: false,
          amount: component.amount.toString(),
          calculatedFromPercentage: false,
        });
        grossValue += component.amount;
      }
    }

    // Add monthly bonus early so it's included in PF calculations
    if (complianceSettings?.bonusEnabled !== false && complianceSettings?.bonusMonthly) {
      const bonusAmount = Math.round((grossValue * 0.0833) * 100) / 100;
      
      // Add monthly bonus as an employee component (earnings)
      salaryComponents.push({
        componentKey: 'monthly_bonus',
        displayName: 'Monthly Bonus',
        isTaxable: true,
        isEmployerCost: false,
        amount: bonusAmount,
        calculatedFromPercentage: true,
      });
      
      // Update grossValue to include monthly bonus for PF calculations
      grossValue += bonusAmount;
    }

    const employerCosts: SalaryComponent[] = [];

    // Calculate statutory employer costs with compliance settings
    if (complianceSettings?.epfEnabled !== false) {
      // Calculate PF on all earning heads except HRA
      const hraComponent = salaryComponents.find(c => c.componentKey === 'hra');
      const pfBaseAmount = grossValue - (hraComponent ? hraComponent.amount : 0);
      
      let epfLimit = 15000; // Default statutory limit
      if (complianceSettings?.pfLimit) epfLimit = 21000;
      if (complianceSettings?.pfLimitHigher) epfLimit = 25000;
      const epfBasic = Math.min(pfBaseAmount, epfLimit);
      
      employerCosts.push({
        componentKey: 'epf_employer',
        displayName: 'EPF Employer Contribution',
        isTaxable: false,
        isEmployerCost: true,
        amount: Math.round((epfBasic * 0.12) * 100) / 100,
        calculatedFromPercentage: true,
      });

      // EPF admin charges
      employerCosts.push({
        componentKey: 'epf_admin',
        displayName: 'EPF Admin Charges',
        isTaxable: false,
        isEmployerCost: true,
        amount: Math.round((epfBasic * 0.01) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // Bonus (calculated on gross salary) - only add to employer costs if NOT monthly
    if (complianceSettings?.bonusEnabled !== false && !complianceSettings?.bonusMonthly) {
      employerCosts.push({
        componentKey: 'bonus',
        displayName: 'Bonus',
        isTaxable: false,
        isEmployerCost: true,
        amount: Math.round((grossValue * 0.0833) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // ESIC employer contribution if applicable
    if (complianceSettings?.esicEnabled !== false && grossValue <= 25000) {
      employerCosts.push({
        componentKey: 'esic_employer',
        displayName: 'ESIC Employer Contribution',
        isTaxable: false,
        isEmployerCost: true,
        amount: Math.round((grossValue * 0.0325) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // LWF employer contribution
    if (complianceSettings?.lwfEnabled !== false) {
      employerCosts.push({
        componentKey: 'lwf_employer',
        displayName: 'LWF Employer Contribution',
        isTaxable: false,
        isEmployerCost: true,
        amount: 20,
        calculatedFromPercentage: false,
      });
    }

    // Calculate employee deductions based on compliance settings
    const deductions: SalaryComponent[] = [];
    
    // EPF Employee Deduction
    if (complianceSettings?.epfEnabled !== false) {
      // Calculate PF on all earning heads except HRA
      const hraComponent = salaryComponents.find(c => c.componentKey === 'hra');
      const pfBaseAmount = grossValue - (hraComponent ? hraComponent.amount : 0);
      
      let epfLimit = 15000; // Default statutory limit
      if (complianceSettings?.pfLimit) epfLimit = 21000;
      if (complianceSettings?.pfLimitHigher) epfLimit = 25000;
      const epfBasic = Math.min(pfBaseAmount, epfLimit);
      deductions.push({
        componentKey: 'epf_employee',
        displayName: 'EPF Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((epfBasic * 0.12) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // ESIC employee deduction if applicable
    if (complianceSettings?.esicEnabled !== false && grossValue <= 25000) {
      deductions.push({
        componentKey: 'esic_employee',
        displayName: 'ESIC Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((grossValue * 0.0075) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // LWF employee deduction
    if (complianceSettings?.lwfEnabled !== false) {
      deductions.push({
        componentKey: 'lwf_employee',
        displayName: 'LWF Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: 10,
        calculatedFromPercentage: false,
      });
    }

    // VPF Employee Deduction
    if (complianceSettings?.vpfEnabled && complianceValues?.vpfPercentage > 0) {
      // Calculate VPF on all earning heads except HRA
      const hraComponent = salaryComponents.find(c => c.componentKey === 'hra');
      const vpfBaseAmount = grossValue - (hraComponent ? hraComponent.amount : 0);
      
      deductions.push({
        componentKey: 'vpf_employee',
        displayName: 'VPF Employee Contribution',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((vpfBaseAmount * complianceValues.vpfPercentage / 100) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // TDS Deduction
    if (complianceSettings?.tdsEnabled && complianceValues?.tdsPercentage > 0) {
      deductions.push({
        componentKey: 'tds',
        displayName: 'TDS',
        isTaxable: false,
        isEmployerCost: false,
        amount: Math.round((grossValue * complianceValues.tdsPercentage / 100) * 100) / 100,
        calculatedFromPercentage: true,
      });
    }

    // PT Deduction
    if (complianceSettings?.ptEnabled && complianceValues?.ptAmount > 0) {
      deductions.push({
        componentKey: 'pt',
        displayName: 'Professional Tax',
        isTaxable: false,
        isEmployerCost: false,
        amount: complianceValues.ptAmount,
        calculatedFromPercentage: false,
      });
    }

    // Monthly bonus already handled above (added early for PF calculations)

    const totalEmployerCosts = employerCosts.reduce((sum, cost) => sum + cost.amount, 0);
    const totalDeductions = deductions.reduce((sum, deduction) => sum + deduction.amount, 0);
    const ctcValue = Math.round((grossValue + totalEmployerCosts) * 100) / 100;
    const netPay = Math.round((grossValue - totalDeductions) * 100) / 100;

    return {
      mode: 'earning_heads',
      ctcValue,
      grossValue,
      netPay,
      components: salaryComponents,
      employerCosts,
      deductions,
      configSnapshot: JSON.stringify(config),
    };
  }

  /**
   * Save salary structure to database
   */
  static async saveSalaryStructure(
    employeeId: number,
    companyId: number,
    year: number,
    month: number,
    calculationResult: SalaryCalculationResult
  ): Promise<void> {
    // Save or update the salary structure
    const existingStructure = await db
      .select()
      .from(employeeSalaryStructures)
      .where(
        and(
          eq(employeeSalaryStructures.employeeId, employeeId),
          eq(employeeSalaryStructures.year, year),
          eq(employeeSalaryStructures.month, month)
        )
      )
      .limit(1);

    let structureId: number;

    // Extract component amounts for earningHead fields (PayrollService compatibility)
    const basicComponent = calculationResult.components.find(c => c.componentKey === 'basic');
    const hraComponent = calculationResult.components.find(c => c.componentKey === 'hra');
    const conveyanceComponent = calculationResult.components.find(c => c.componentKey === 'conveyance');
    const otherComponent = calculationResult.components.find(c => c.componentKey === 'other');

    const earningHead1 = basicComponent ? basicComponent.amount.toString() : '0';
    const earningHead2 = hraComponent ? hraComponent.amount.toString() : '0';
    const earningHead3 = conveyanceComponent ? conveyanceComponent.amount.toString() : '0';
    const earningHead4 = otherComponent ? otherComponent.amount.toString() : '0';

    if (existingStructure.length > 0) {
      // Update existing structure
      await db
        .update(employeeSalaryStructures)
        .set({
          grossValue: calculationResult.grossValue.toString(),
          ctcValue: calculationResult.ctcValue.toString(),
          entryType: calculationResult.mode,
          earningHead1, // Basic Salary
          earningHead2, // House Rent Allowance
          earningHead3, // Conveyance Allowance
          earningHead4, // Other Allowances
          updatedAt: new Date(),
        })
        .where(eq(employeeSalaryStructures.id, existingStructure[0].id));

      structureId = existingStructure[0].id;

      // Delete existing component values
      await db
        .delete(employeeSalaryComponentValues)
        .where(eq(employeeSalaryComponentValues.structureId, structureId));
    } else {
      // Create new structure
      const [newStructure] = await db
        .insert(employeeSalaryStructures)
        .values({
          employeeId,
          companyId,
          year,
          month,
          grossValue: calculationResult.grossValue.toString(),
          ctcValue: calculationResult.ctcValue.toString(),
          entryType: calculationResult.mode,
          earningHead1, // Basic Salary
          earningHead2, // House Rent Allowance
          earningHead3, // Conveyance Allowance
          earningHead4, // Other Allowances
        })
        .returning({ id: employeeSalaryStructures.id });

      structureId = newStructure.id;
    }

    // Save component values
    const componentValues = [
      ...calculationResult.components.map(component => ({
        structureId,
        componentKey: component.componentKey,
        amount: component.amount.toString(),
        isEmployerCost: false,
        calculatedFromPercentage: component.calculatedFromPercentage,
      })),
      ...calculationResult.employerCosts.map(cost => ({
        structureId,
        componentKey: cost.componentKey,
        amount: cost.amount,
        isEmployerCost: true,
        calculatedFromPercentage: cost.calculatedFromPercentage,
      })),
      ...(calculationResult.deductions || []).map(deduction => ({
        structureId,
        componentKey: deduction.componentKey,
        amount: (-deduction.amount).toString(), // Store as negative for deductions
        isEmployerCost: false,
        calculatedFromPercentage: deduction.calculatedFromPercentage,
      })),
    ];

    if (componentValues.length > 0) {
      await db.insert(employeeSalaryComponentValues).values(componentValues);
    }
  }
}