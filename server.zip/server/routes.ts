import type { Express } from "express";
import { createServer, type Server } from "http";
import "./types"; // Import custom type definitions
import { storage } from "./storage";
import { loginSchema, insertEmployeeSchema, insertJobSchema, insertDepartmentSchema, insertEmployeeSalaryStructureSchema, leaveRequests, advanceRequests, clients, complianceSetups, compliancesData, employeeAssignments } from "@shared/schema";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import jwt from "jsonwebtoken";
import ExcelJS from "exceljs";
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('JWT_SECRET environment variable is required for production security');
  }
  // Development fallback - NOT FOR PRODUCTION
  console.warn('⚠️  WARNING: Using development JWT secret. Set JWT_SECRET environment variable for production!');
}
const JWT_SECRET_VALUE = JWT_SECRET || 'dev-secret-key-not-for-production';

// Middleware to verify JWT token and extract user
async function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  // Only log for non-routine requests to reduce noise
  if (req.path !== '/api/auth/me') {
    console.log('Auth check for:', req.method, req.path);
    console.log('Auth header present:', !!authHeader);
    console.log('Token extracted:', !!token);
  }

  if (!token) {
    console.log('No token provided, returning 401');
    return res.status(401).json({ message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET_VALUE) as any;
    
    const user = await storage.getUser(decoded.userId);
    
    if (!user) {
      console.log('User not found for userId:', decoded.userId);
      return res.status(401).json({ message: 'User not found' });
    }
    
    if (!user.isActive) {
      console.log('User inactive:', user.email);
      return res.status(401).json({ message: 'User account is inactive' });
    }
    
    req.user = user;
    next();
  } catch (error) {
    console.log('Token verification failed:', error.message);
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

// Middleware to check company access
function checkCompanyAccess(req: any, res: any, next: any) {
  const companyId = parseInt(req.params.companyId || req.body.companyId);
  
  if (req.user.role === 'system_admin') {
    return next(); // System admin can access all companies
  }
  
  if (req.user.companyId !== companyId) {
    return res.status(403).json({ message: 'Access denied to this company' });
  }
  
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      // Validate request body exists
      if (!req.body || typeof req.body !== 'object') {
        return res.status(400).json({ message: 'Request body is required' });
      }

      // Parse with Zod
      const validationResult = loginSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: 'Validation failed', 
          errors: validationResult.error.errors 
        });
      }
      
      const { email, password } = validationResult.data;
      
      // Test database connection first
      try {
        const user = await storage.authenticateUser(email, password);
        
        if (!user) {
          return res.status(401).json({ message: 'Invalid credentials' });
        }
        
        const token = jwt.sign({ userId: user.id }, JWT_SECRET_VALUE, { expiresIn: '7d' });
        
        res.json({
          user: {
            id: user.id,
            email: user.email,
            username: user.username,
            role: user.role,
            companyId: user.companyId,
          },
          token,
        });
      } catch (dbError) {
        console.error('Database error:', dbError);
        return res.status(500).json({ message: 'Database connection failed' });
      }
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req, res) => {
    res.json({
      user: {
        id: req.user.id,
        email: req.user.email,
        username: req.user.username,
        role: req.user.role,
        companyId: req.user.companyId,
      }
    });
  });

  // Dashboard stats
  app.get("/api/dashboard/stats/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const stats = await storage.getDashboardStats(companyId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch dashboard stats' });
    }
  });

  // Public companies endpoint MUST come before parameterized routes  
  app.get("/api/companies/public", async (req, res) => {
    try {
      const companies = await storage.getAllCompanies();
      // Return only basic info for job browsing
      const publicCompanies = companies.map(c => ({
        id: c.id,
        name: c.name,
        status: c.status
      })).filter(c => c.status === 'active');
      res.json(publicCompanies);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch companies' });
    }
  });

  // Company routes
  app.get("/api/companies/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const company = await storage.getCompany(companyId);
      if (!company) {
        return res.status(404).json({ message: 'Company not found' });
      }
      res.json(company);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch company' });
    }
  });

  // Employee routes
  app.get("/api/employees/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const employees = await storage.getEmployeesByCompany(companyId);
      res.json(employees);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch employees' });
    }
  });

  app.get("/api/employees/:companyId/:id", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      res.json(employee);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch employee' });
    }
  });

  app.post("/api/employees", authenticateToken, async (req, res) => {
    try {
      const employeeData = insertEmployeeSchema.parse(req.body);
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employeeData.companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      const employee = await storage.createEmployee(employeeData);
      res.status(201).json(employee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid employee data', errors: error.errors });
      }
      console.error('Employee creation error:', error);
      res.status(500).json({ message: 'Failed to create employee', error: error instanceof Error ? error.message : String(error) });
    }
  });

  app.put("/api/employees/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      // Extract payroll data from request body
      const {
        epfEnabled, employeePfLimit, employerPfLimit, esicEnabled, lwfEnabled, otEnabled,
        doubleOt, vpfEnabled, vpfAmount, tdsEnabled, tdsAmount, ptEnabled, ptAmount,
        bonusEnabled, bonusMonthlyPayment, entryType, ctcValue, grossValue,
        earningHead1, earningHead2, earningHead3, earningHead4,
        epfEmployeeAmount, esicEmployeeAmount, lwfEmployeeAmount,
        ...employeeFields
      } = req.body;

      // Filter out undefined/null payroll fields and only include valid employee fields
      const updateData: any = {
        firstName: employeeFields.firstName,
        lastName: employeeFields.lastName,
        email: employeeFields.email,
        phone: employeeFields.phone,
        employeeId: employeeFields.employeeId,
        position: employeeFields.position,
        departmentId: employeeFields.departmentId,
        address: employeeFields.address,
        salary: employeeFields.salary || grossValue || ctcValue,
        status: employeeFields.status,
        emergencyContact: employeeFields.emergencyContact,
        emergencyPhone: employeeFields.emergencyPhone,
      };
      
      // Handle date fields properly
      if (employeeFields.dateOfBirth) {
        updateData.dateOfBirth = new Date(employeeFields.dateOfBirth);
      }
      if (employeeFields.hireDate) {
        updateData.hireDate = new Date(employeeFields.hireDate);
      }
      
      // Remove undefined fields
      Object.keys(updateData).forEach(key => {
        if (updateData[key] === undefined || updateData[key] === null || updateData[key] === '') {
          delete updateData[key];
        }
      });
      
      const updatedEmployee = await storage.updateEmployee(id, updateData);
      
      // Handle payroll data separately
      const payrollData = {
        epfEnabled, employeePfLimit, employerPfLimit, esicEnabled, lwfEnabled, otEnabled,
        doubleOt, vpfEnabled, vpfAmount, tdsEnabled, tdsAmount, ptEnabled, ptAmount,
        bonusEnabled, bonusMonthlyPayment, entryType, ctcValue, grossValue,
        earningHead1, earningHead2, earningHead3, earningHead4,
        epfEmployeeAmount, esicEmployeeAmount, lwfEmployeeAmount
      };

      console.log('Raw payroll data received:', payrollData);

      // Clean up payroll data but preserve boolean values (including false)
      const cleanPayrollData = {};
      Object.keys(payrollData).forEach(key => {
        const value = payrollData[key];
        // Keep boolean values (true/false), non-empty strings, and numbers
        if (typeof value === 'boolean' || (value !== undefined && value !== null && value !== '')) {
          cleanPayrollData[key] = value;
        }
      });

      console.log('Cleaned payroll data to save:', cleanPayrollData);

      // Always save payroll data to ensure boolean states are preserved
      if (true) { // Always save payroll data
        try {
          const existingPayroll = await storage.getEmployeePayroll(id);
          
          if (existingPayroll) {
            await storage.updateEmployeePayroll(id, cleanPayrollData);
            console.log('Updated existing payroll for employee:', id);
          } else {
            await storage.createEmployeePayroll({
              ...cleanPayrollData,
              employeeId: id,
              companyId: updatedEmployee.companyId
            });
            console.log('Created new payroll for employee:', id);
          }
        } catch (payrollError) {
          console.error('Error handling payroll data:', payrollError);
        }
      }
      res.json(updatedEmployee);
    } catch (error) {
      console.error('Employee update error:', error);
      res.status(500).json({ message: 'Failed to update employee', error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Get employee with payroll data
  app.get("/api/employees/:companyId/:id", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Get payroll data if exists
      const payrollData = await storage.getEmployeePayroll(id);
      
      console.log('Fetched payroll data for employee', id, ':', payrollData);
      
      // Add no-cache headers to prevent stale data
      res.set({
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      
      res.json({
        ...employee,
        payroll: payrollData || null
      });
    } catch (error) {
      console.error('Employee fetch error:', error);
      res.status(500).json({ message: 'Failed to fetch employee' });
    }
  });

  app.delete("/api/employees/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check company access and role
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to delete this employee' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to delete employee' });
      }
      
      await storage.deleteEmployee(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete employee' });
    }
  });

  // Department routes
  app.get("/api/departments/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      res.json(departments);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch departments' });
    }
  });

  app.post("/api/departments", authenticateToken, async (req, res) => {
    try {
      const departmentData = insertDepartmentSchema.parse(req.body);
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== departmentData.companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to create department' });
      }
      
      const department = await storage.createDepartment(departmentData);
      res.status(201).json(department);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid department data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create department' });
    }
  });

  // Employee Salary Structure routes (month-wise historical tracking)
  
  // Get specific month's salary structure
  app.get("/api/employee-salary-structure/:employeeId/:year/:month", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      // Validate parameters
      if (isNaN(employeeId) || isNaN(year) || isNaN(month)) {
        return res.status(400).json({ message: 'Invalid parameters' });
      }
      if (month < 1 || month > 12) {
        return res.status(400).json({ message: 'Month must be between 1 and 12' });
      }
      if (year < 2000 || year > 2100) {
        return res.status(400).json({ message: 'Invalid year' });
      }
      
      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - employees can only view their own records
      if (req.user.role === 'employee') {
        if (employee.userId !== req.user.id) {
          return res.status(403).json({ message: 'Access denied - employees can only view their own salary records' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const structure = await storage.getEmployeeSalaryStructure(employeeId, year, month);
      if (!structure) {
        return res.status(404).json({ message: 'Salary structure not found for this month' });
      }
      
      res.json(structure);
    } catch (error) {
      console.error('Error fetching salary structure:', error);
      res.status(500).json({ message: 'Failed to fetch salary structure' });
    }
  });

  // Upsert salary structure for specific month
  app.put("/api/employee-salary-structure/:employeeId/:year/:month", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to update salary structure' });
      }
      
      // Validate parameters
      if (isNaN(employeeId) || isNaN(year) || isNaN(month)) {
        return res.status(400).json({ message: 'Invalid parameters' });
      }
      if (month < 1 || month > 12) {
        return res.status(400).json({ message: 'Month must be between 1 and 12' });
      }
      if (year < 2000 || year > 2100) {
        return res.status(400).json({ message: 'Invalid year' });
      }
      
      // Validate request body - Zod schema now handles empty string transformation
      const structureData = {
        ...req.body,
        employeeId,
        year,
        month,
        companyId: employee.companyId
      };
      
      const validatedData = insertEmployeeSalaryStructureSchema.parse(structureData);
      const updatedStructure = await storage.upsertEmployeeSalaryStructure(validatedData);
      
      res.json(updatedStructure);
    } catch (error) {
      console.error('Error updating salary structure:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid salary structure data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to update salary structure' });
    }
  });

  // Cascade salary structure updates to future months (until next explicit update)
  app.post("/api/employee-salary-structure/:employeeId/:year/:month/cascade", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      console.log('Cascade request received:', { employeeId, year, month });
      
      // Validate parameters
      if (isNaN(employeeId) || isNaN(year) || isNaN(month)) {
        return res.status(400).json({ message: 'Invalid parameters' });
      }
      if (month < 1 || month > 12) {
        return res.status(400).json({ message: 'Month must be between 1 and 12' });
      }
      
      // Get employee to check company access and verify existence
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - only admins can cascade updates
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to cascade salary structure updates' });
      }
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      // Get the source structure data from the persisted current month (ensures canonical data)
      const sourceStructure = await storage.getEmployeeSalaryStructure(employeeId, year, month);
      if (!sourceStructure) {
        return res.status(404).json({ message: 'Source salary structure not found for the specified month' });
      }
      
      console.log('Source structure found:', { year, month, sourceId: sourceStructure.id });
      
      // Get all existing future salary structures to determine where to stop cascading
      const existingFutureStructures = await storage.getFutureSalaryStructures(employeeId, year, month);
      console.log('Existing future structures:', existingFutureStructures.map(s => ({ year: s.year, month: s.month })));
      
      // Find the next explicit update (earliest future month with existing data)
      let stopYear = year + 2; // Default max 2 years
      let stopMonth = month;
      
      if (existingFutureStructures.length > 0) {
        const earliestFuture = existingFutureStructures[0]; // Already ordered by year, month
        stopYear = earliestFuture.year;
        stopMonth = earliestFuture.month;
        console.log('Found next explicit update, stopping at:', { stopYear, stopMonth });
      }
      
      // Generate future months to cascade (only until next explicit update)
      const futureMonths = [];
      let currentYear = year;
      let currentMonth = month + 1; // Start from next month
      
      // If there are no future structures, cascade for up to 24 months (2 years)
      if (existingFutureStructures.length === 0) {
        console.log('No existing future structures found, cascading for up to 24 months');
        for (let i = 0; i < 24; i++) {
          if (currentMonth > 12) {
            currentMonth = 1;
            currentYear++;
          }
          futureMonths.push({ year: currentYear, month: currentMonth });
          currentMonth++;
        }
      } else {
        console.log('Found existing future structures, cascading until first existing one');
        // Only cascade until the first existing future structure
        while (currentYear < stopYear || (currentYear === stopYear && currentMonth < stopMonth)) {
          if (currentMonth > 12) {
            currentMonth = 1;
            currentYear++;
          }
          
          futureMonths.push({ year: currentYear, month: currentMonth });
          currentMonth++;
          
          // Safety limit to prevent infinite loops
          if (futureMonths.length > 100) {
            console.warn('Cascade safety limit reached (100 months)');
            break;
          }
        }
      }
      
      console.log('Months to cascade:', futureMonths.length, futureMonths);
      
      // Update each future month with the source structure data (excluding id and timestamps)
      const updatedMonths = [];
      for (const { year: futureYear, month: futureMonth } of futureMonths) {
        const futureStructureData = {
          employeeId: sourceStructure.employeeId,
          companyId: sourceStructure.companyId,
          year: futureYear,
          month: futureMonth,
          epfEnabled: sourceStructure.epfEnabled,
          employeePfLimit: sourceStructure.employeePfLimit,
          employerPfLimit: sourceStructure.employerPfLimit,
          esicEnabled: sourceStructure.esicEnabled,
          lwfEnabled: sourceStructure.lwfEnabled,
          otEnabled: sourceStructure.otEnabled,
          doubleOt: sourceStructure.doubleOt,
          vpfEnabled: sourceStructure.vpfEnabled,
          vpfAmount: sourceStructure.vpfAmount,
          tdsEnabled: sourceStructure.tdsEnabled,
          tdsAmount: sourceStructure.tdsAmount,
          ptEnabled: sourceStructure.ptEnabled,
          ptAmount: sourceStructure.ptAmount,
          bonusEnabled: sourceStructure.bonusEnabled,
          bonusMonthlyPayment: sourceStructure.bonusMonthlyPayment,
          entryType: sourceStructure.entryType,
          ctcValue: sourceStructure.ctcValue,
          grossValue: sourceStructure.grossValue,
          earningHead1: sourceStructure.earningHead1,
          earningHead2: sourceStructure.earningHead2,
          earningHead3: sourceStructure.earningHead3,
          earningHead4: sourceStructure.earningHead4,
          epfEmployeeAmount: sourceStructure.epfEmployeeAmount,
          esicEmployeeAmount: sourceStructure.esicEmployeeAmount,
          lwfEmployeeAmount: sourceStructure.lwfEmployeeAmount
        };
        
        try {
          const updatedStructure = await storage.upsertEmployeeSalaryStructure(futureStructureData);
          updatedMonths.push({ year: futureYear, month: futureMonth, success: true });
          console.log(`Updated future month: ${futureYear}-${futureMonth}`);
        } catch (error) {
          console.warn(`Failed to update future month ${futureYear}-${futureMonth}:`, error);
          updatedMonths.push({ year: futureYear, month: futureMonth, success: false, error: error.message });
        }
      }
      
      console.log('Cascade completed:', { 
        total: futureMonths.length, 
        successful: updatedMonths.filter(m => m.success).length,
        failed: updatedMonths.filter(m => !m.success).length
      });
      
      res.json({ 
        message: 'Cascade update completed',
        sourceMonth: { year, month },
        updatedMonths: updatedMonths.filter(m => m.success),
        failedMonths: updatedMonths.filter(m => !m.success),
        stoppedAt: existingFutureStructures.length > 0 ? { year: stopYear, month: stopMonth } : null
      });
    } catch (error) {
      console.error('Error cascading salary structure updates:', error);
      res.status(500).json({ message: 'Failed to cascade salary structure updates', error: error.message });
    }
  });

  // Get latest salary structure for employee
  app.get("/api/employee-salary-structure/:employeeId/latest", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      
      // Validate parameters
      if (isNaN(employeeId)) {
        return res.status(400).json({ message: 'Invalid employee ID' });
      }
      
      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - employees can only view their own records
      if (req.user.role === 'employee') {
        if (employee.userId !== req.user.id) {
          return res.status(403).json({ message: 'Access denied - employees can only view their own salary records' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const latestStructure = await storage.getLatestEmployeeSalaryStructure(employeeId);
      if (!latestStructure) {
        return res.status(404).json({ message: 'No salary structure found for this employee' });
      }
      
      res.json(latestStructure);
    } catch (error) {
      console.error('Error fetching latest salary structure:', error);
      res.status(500).json({ message: 'Failed to fetch latest salary structure' });
    }
  });

  // Get salary structure history for employee
  app.get("/api/employee-salary-structure/:employeeId/history", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 12;
      
      // Validate parameters
      if (isNaN(employeeId)) {
        return res.status(400).json({ message: 'Invalid employee ID' });
      }
      if (req.query.limit && (isNaN(limit) || limit < 1 || limit > 24)) {
        return res.status(400).json({ message: 'Limit must be between 1 and 24' });
      }
      
      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - employees can only view their own records
      if (req.user.role === 'employee') {
        if (employee.userId !== req.user.id) {
          return res.status(403).json({ message: 'Access denied - employees can only view their own salary records' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const history = await storage.getEmployeeSalaryStructureHistory(employeeId, limit);
      res.json(history);
    } catch (error) {
      console.error('Error fetching salary structure history:', error);
      res.status(500).json({ message: 'Failed to fetch salary structure history' });
    }
  });

  // Generate salary history PDF for employee
  app.get("/api/employee-salary-structure/:employeeId/pdf", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 12;
      
      // Validate parameters
      if (isNaN(employeeId)) {
        return res.status(400).json({ message: 'Invalid employee ID' });
      }
      if (req.query.limit && (isNaN(limit) || limit < 1 || limit > 24)) {
        return res.status(400).json({ message: 'Limit must be between 1 and 24' });
      }
      
      // Get employee to check company access and gather info
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - employees can only view their own records
      if (req.user.role === 'employee') {
        if (employee.userId !== req.user.id) {
          return res.status(403).json({ message: 'Access denied - employees can only view their own salary records' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      // Get company information for header
      const company = await storage.getCompany(employee.companyId);
      if (!company) {
        return res.status(404).json({ message: 'Company not found' });
      }
      
      // Get complete salary history from date of joining to current month
      const history = await storage.getCompleteSalaryHistoryFromJoining(employeeId);
      if (!history || history.length === 0) {
        return res.status(404).json({ message: 'No salary history found for this employee' });
      }
      
      // Generate PDF
      const pdfDoc = await PDFDocument.create();
      const timesRomanFont = await pdfDoc.embedFont(StandardFonts.TimesRoman);
      const timesRomanBoldFont = await pdfDoc.embedFont(StandardFonts.TimesRomanBold);
      const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
      const helveticaBoldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      
      let page = pdfDoc.addPage();
      const { width, height } = page.getSize();
      let currentY = height - 50;
      
      // PDF Header
      page.drawText(company.name, {
        x: 50,
        y: currentY,
        size: 20,
        font: helveticaBoldFont,
        color: rgb(0, 0, 0.5),
      });
      currentY -= 30;
      
      page.drawText('Salary History Report', {
        x: 50,
        y: currentY,
        size: 16,
        font: helveticaBoldFont,
        color: rgb(0.2, 0.2, 0.2),
      });
      currentY -= 40;
      
      // Employee Information
      page.drawText('Employee Information:', {
        x: 50,
        y: currentY,
        size: 14,
        font: helveticaBoldFont,
        color: rgb(0, 0, 0),
      });
      currentY -= 20;
      
      const employeeInfo = [
        `Name: ${employee.firstName} ${employee.lastName}`,
        `Employee ID: ${employee.employeeId}`,
        `Position: ${employee.position || 'N/A'}`,
        `Email: ${employee.email}`,
        `Generated on: ${new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })}`
      ];
      
      employeeInfo.forEach(info => {
        page.drawText(info, {
          x: 70,
          y: currentY,
          size: 10,
          font: helveticaFont,
          color: rgb(0.3, 0.3, 0.3),
        });
        currentY -= 15;
      });
      
      currentY -= 20;
      
      // Table Headers
      const tableStartY = currentY;
      const colWidths = [80, 80, 80, 80, 80, 80, 80]; // Adjust as needed
      const headers = ['Period', 'CTC', 'Gross', 'Basic', 'HRA', 'Conveyance', 'Other'];
      
      // Draw table header background
      page.drawRectangle({
        x: 40,
        y: currentY - 20,
        width: width - 80,
        height: 25,
        color: rgb(0.9, 0.9, 0.9),
      });
      
      // Draw table headers
      let currentX = 50;
      headers.forEach((header, index) => {
        page.drawText(header, {
          x: currentX,
          y: currentY - 15,
          size: 9,
          font: helveticaBoldFont,
          color: rgb(0, 0, 0),
        });
        currentX += colWidths[index];
      });
      
      currentY -= 35;
      
      // Table Content
      const monthNames = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ];
      
      // Sort history by year and month (newest first)
      const sortedHistory = history.sort((a, b) => {
        if (a.year !== b.year) return b.year - a.year;
        return b.month - a.month;
      });
      
      sortedHistory.forEach((record, index) => {
        // Check if we need a new page
        if (currentY < 100) {
          page = pdfDoc.addPage();
          currentY = height - 50;
        }
        
        // Alternate row colors
        if (index % 2 === 0) {
          page.drawRectangle({
            x: 40,
            y: currentY - 15,
            width: width - 80,
            height: 20,
            color: rgb(0.98, 0.98, 0.98),
          });
        }
        
        const rowData = [
          `${monthNames[record.month - 1]} ${record.year}`,
          record.ctcValue ? `Rs.${parseFloat(record.ctcValue).toLocaleString('en-IN')}` : 'N/A',
          record.grossValue ? `Rs.${parseFloat(record.grossValue).toLocaleString('en-IN')}` : 'N/A',
          record.earningHead1 ? `Rs.${parseFloat(record.earningHead1).toLocaleString('en-IN')}` : 'N/A',
          record.earningHead2 ? `Rs.${parseFloat(record.earningHead2).toLocaleString('en-IN')}` : 'N/A',
          record.earningHead3 ? `Rs.${parseFloat(record.earningHead3).toLocaleString('en-IN')}` : 'N/A',
          record.earningHead4 ? `Rs.${parseFloat(record.earningHead4).toLocaleString('en-IN')}` : 'N/A',
        ];
        
        currentX = 50;
        rowData.forEach((data, colIndex) => {
          page.drawText(data, {
            x: currentX,
            y: currentY - 10,
            size: 8,
            font: helveticaFont,
            color: rgb(0.2, 0.2, 0.2),
          });
          currentX += colWidths[colIndex];
        });
        
        currentY -= 25;
      });
      
      // Add footer
      const footerY = 30;
      page.drawText('This is a computer-generated document and does not require a signature.', {
        x: 50,
        y: footerY,
        size: 8,
        font: helveticaFont,
        color: rgb(0.5, 0.5, 0.5),
      });
      
      page.drawText(`Generated by ${company.name} HR System`, {
        x: width - 200,
        y: footerY,
        size: 8,
        font: helveticaFont,
        color: rgb(0.5, 0.5, 0.5),
      });
      
      // Generate PDF bytes
      const pdfBytes = await pdfDoc.save();
      
      // Set response headers for PDF download  
      const fileName = `salary_history_${employee.firstName}_${employee.lastName}_${new Date().toISOString().split('T')[0]}.pdf`;
      
      // Clear any existing headers that might interfere
      res.removeHeader('Content-Type');
      
      // Set PDF-specific headers
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${fileName}"`,
        'Content-Length': pdfBytes.length.toString(),
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      
      // Send PDF as buffer (bypass any JSON middleware)
      res.status(200);
      res.end(Buffer.from(pdfBytes));
      
    } catch (error) {
      console.error('Error generating salary history PDF:', error);
      res.status(500).json({ message: 'Failed to generate salary history PDF' });
    }
  });

  // Salary Component Management API Routes
  
  // Get all salary components
  app.get("/api/salary-components", authenticateToken, async (req, res) => {
    try {
      const components = await storage.getSalaryComponents();
      res.json(components);
    } catch (error) {
      console.error('Error fetching salary components:', error);
      res.status(500).json({ message: 'Failed to fetch salary components' });
    }
  });

  // Company salary component configuration routes
  app.get("/api/company-salary-config/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const entryMode = req.query.entryMode as string;
      
      if (isNaN(companyId)) {
        return res.status(400).json({ message: 'Invalid company ID' });
      }

      // Validate entryMode if provided
      if (entryMode && !['gross', 'ctc', 'earning_heads'].includes(entryMode)) {
        return res.status(400).json({ message: 'Invalid entry mode. Must be: gross, ctc, or earning_heads' });
      }

      const config = await storage.getCompanySalaryComponentConfig(companyId, entryMode);
      res.json(config);
    } catch (error) {
      console.error('Error fetching company salary config:', error);
      res.status(500).json({ message: 'Failed to fetch company salary configuration' });
    }
  });

  // Create or update company salary component configuration
  app.post("/api/company-salary-config", authenticateToken, async (req, res) => {
    try {
      const { insertCompanySalaryComponentConfigSchema } = await import("@shared/schema");
      const config = insertCompanySalaryComponentConfigSchema.parse(req.body);
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== config.companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }

      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to modify salary configuration' });
      }

      const result = await storage.upsertCompanySalaryComponentConfig(config);
      res.status(201).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid configuration data', errors: error.errors });
      }
      console.error('Error saving company salary config:', error);
      res.status(500).json({ message: 'Failed to save company salary configuration' });
    }
  });

  // Salary calculation preview endpoints
  app.post("/api/salary-calculation/preview/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const { mode, amount, compliance, complianceValues } = req.body;
      
      if (isNaN(companyId)) {
        return res.status(400).json({ message: 'Invalid company ID' });
      }

      if (!mode) {
        return res.status(400).json({ message: 'Mode is required' });
      }

      // Validate mode
      if (!['gross', 'ctc', 'earning_heads'].includes(mode)) {
        return res.status(400).json({ message: 'Invalid mode. Must be: gross, ctc, or earning_heads' });
      }

      // For gross and ctc modes, amount is required
      if ((mode === 'gross' || mode === 'ctc') && (!amount || isNaN(parseFloat(amount)))) {
        return res.status(400).json({ message: 'Mode and amount are required' });
      }

      const { SalaryStructureEngine } = await import('./SalaryStructureEngine');
      let result;

      // Prepare compliance settings with defaults
      const complianceSettings = {
        epfEnabled: compliance?.epfEnabled ?? true,
        esicEnabled: compliance?.esicEnabled ?? true,
        lwfEnabled: compliance?.lwfEnabled ?? true,
        otEnabled: compliance?.otEnabled ?? false,
        vpfEnabled: compliance?.vpfEnabled ?? false,
        tdsEnabled: compliance?.tdsEnabled ?? false,
        ptEnabled: compliance?.ptEnabled ?? false,
        bonusEnabled: compliance?.bonusEnabled ?? true,
        pfLimit: compliance?.pfLimit ?? false,
        pfLimitHigher: compliance?.pfLimitHigher ?? false,
        bonusMonthly: compliance?.bonusMonthly ?? false,
      };

      // Prepare compliance values
      const complianceVals = {
        vpfPercentage: complianceValues?.vpfPercentage ? parseFloat(complianceValues.vpfPercentage) : 0,
        tdsPercentage: complianceValues?.tdsPercentage ? parseFloat(complianceValues.tdsPercentage) : 0,
        ptAmount: complianceValues?.ptAmount ? parseFloat(complianceValues.ptAmount) : 0,
      };

      switch (mode) {
        case 'gross':
          result = await SalaryStructureEngine.calculateFromGross(companyId, parseFloat(amount), complianceSettings, complianceVals);
          break;
        case 'ctc':
          result = await SalaryStructureEngine.calculateFromCTC(companyId, parseFloat(amount), complianceSettings, complianceVals);
          break;
        case 'earning_heads':
          // For earning heads mode, expect components array instead of single amount
          if (!req.body.components || !Array.isArray(req.body.components)) {
            return res.status(400).json({ message: 'Components array is required for earning heads mode' });
          }
          result = await SalaryStructureEngine.calculateFromEarningHeads(companyId, req.body.components, complianceSettings, complianceVals);
          break;
        default:
          return res.status(400).json({ message: 'Invalid calculation mode' });
      }

      res.json(result);
    } catch (error) {
      console.error('Error calculating salary preview:', error);
      res.status(500).json({ message: 'Failed to calculate salary preview' });
    }
  });

  // Employee salary component values routes
  app.get("/api/employee-salary-components/:structureId", authenticateToken, async (req, res) => {
    try {
      const structureId = parseInt(req.params.structureId);
      
      if (isNaN(structureId)) {
        return res.status(400).json({ message: 'Invalid structure ID' });
      }

      // Get structure to check access
      const structure = await storage.getEmployeeSalaryStructure(structureId, 0, 0); // Dummy year/month for ID lookup
      if (!structure) {
        return res.status(404).json({ message: 'Salary structure not found' });
      }

      // Check access permissions
      const employee = await storage.getEmployee(structure.employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role === 'employee' && employee.userId !== req.user.id) {
        return res.status(403).json({ message: 'Access denied to this salary structure' });
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }

      const values = await storage.getEmployeeSalaryComponentValues(structureId);
      res.json(values);
    } catch (error) {
      console.error('Error fetching employee salary component values:', error);
      res.status(500).json({ message: 'Failed to fetch employee salary component values' });
    }
  });

  // Public jobs endpoint MUST come before parameterized routes
  app.get("/api/jobs/public", async (req, res) => {
    try {
      const jobs = await storage.getAllPublicJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch jobs' });
    }
  });

  // Job routes
  app.get("/api/jobs/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const jobs = await storage.getJobsByCompany(companyId);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch jobs' });
    }
  });

  app.get("/api/jobs/:companyId/:id", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.getJob(id);
      if (!job) {
        return res.status(404).json({ message: 'Job not found' });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch job' });
    }
  });

  app.post("/api/jobs", authenticateToken, async (req, res) => {
    try {
      const jobData = insertJobSchema.parse(req.body);
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== jobData.companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to create job' });
      }
      
      const job = await storage.createJob({ ...jobData, postedBy: req.user.id });
      res.status(201).json(job);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid job data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create job' });
    }
  });

  app.put("/api/jobs/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.getJob(id);
      
      if (!job) {
        return res.status(404).json({ message: 'Job not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== job.companyId) {
        return res.status(403).json({ message: 'Access denied to this job' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to update job' });
      }
      
      const updatedJob = await storage.updateJob(id, req.body);
      res.json(updatedJob);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update job' });
    }
  });

  // Job Applications routes
  app.get("/api/applications/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const applications = await storage.getApplicationsByCompany(companyId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch applications' });
    }
  });

  app.get("/api/applications/job/:jobId", authenticateToken, async (req, res) => {
    try {
      const jobId = parseInt(req.params.jobId);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: 'Job not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== job.companyId) {
        return res.status(403).json({ message: 'Access denied to this job' });
      }
      
      const applications = await storage.getApplicationsByJob(jobId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch job applications' });
    }
  });

  // Attendance routes
  app.get("/api/attendance/:employeeId", authenticateToken, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const employee = await storage.getEmployee(employeeId);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const date = req.query.date ? new Date(req.query.date as string) : undefined;
      const attendance = await storage.getAttendanceByEmployee(employeeId, date);
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch attendance' });
    }
  });

  app.post("/api/attendance", authenticateToken, async (req, res) => {
    try {
      const attendanceData = req.body;
      const employee = await storage.getEmployee(attendanceData.employeeId);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const attendance = await storage.createAttendance(attendanceData);
      res.status(201).json(attendance);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create attendance record' });
    }
  });

  // Enhanced Attendance Management Routes
  
  // Check-in endpoint with face and location verification
  app.post("/api/attendance/checkin", authenticateToken, async (req, res) => {
    try {
      const employee = await storage.getEmployeeByUserId(req.user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      const { latitude, longitude, faceImage, deviceInfo } = req.body;
      const ipAddress = req.ip || req.connection.remoteAddress;

      const attendance = await storage.markCheckIn(employee.id, {
        latitude,
        longitude,
        faceImage,
        deviceInfo,
        ipAddress
      });

      res.status(201).json({
        success: true,
        message: 'Check-in successful',
        attendance,
        verifications: {
          faceVerified: attendance.faceVerified,
          locationVerified: attendance.locationVerified
        }
      });
    } catch (error) {
      console.error('Check-in error:', error);
      res.status(500).json({ message: 'Failed to mark check-in', error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Check-out endpoint
  app.post("/api/attendance/checkout/:attendanceId", authenticateToken, async (req, res) => {
    try {
      const attendanceId = parseInt(req.params.attendanceId);
      const { latitude, longitude } = req.body;

      const attendance = await storage.markCheckOut(attendanceId, {
        latitude,
        longitude
      });

      res.json({
        success: true,
        message: 'Check-out successful',
        attendance,
        hoursWorked: attendance.hoursWorked
      });
    } catch (error) {
      console.error('Check-out error:', error);
      res.status(500).json({ message: 'Failed to mark check-out', error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Get today's attendance status for employee
  app.get("/api/attendance/today", authenticateToken, async (req, res) => {
    try {
      const employee = await storage.getEmployeeByUserId(req.user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      const today = new Date();
      const attendance = await storage.getAttendanceByEmployee(employee.id, today);
      
      const todayAttendance = attendance.length > 0 ? attendance[0] : null;
      
      res.json({
        hasCheckedIn: !!todayAttendance?.checkIn,
        hasCheckedOut: !!todayAttendance?.checkOut,
        attendance: todayAttendance,
        canCheckIn: !todayAttendance?.checkIn,
        canCheckOut: todayAttendance?.checkIn && !todayAttendance?.checkOut
      });
    } catch (error) {
      console.error('Today attendance error:', error);
      res.status(500).json({ message: 'Failed to fetch today\'s attendance' });
    }
  });

  // Monthly attendance summary - for specific employee (admin access)
  app.get("/api/attendance/monthly/:employeeId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      if (isNaN(employeeId) || isNaN(year) || isNaN(month)) {
        return res.status(400).json({ message: 'Invalid parameters' });
      }
      
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      // Check access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      let monthlyAttendance = await storage.getMonthlyAttendance(employeeId, year, month);
      
      // Calculate if not exists or if requesting current month (to refresh)
      const currentDate = new Date();
      const isCurrentMonth = year === currentDate.getFullYear() && month === (currentDate.getMonth() + 1);
      
      if (!monthlyAttendance || isCurrentMonth) {
        monthlyAttendance = await storage.calculateMonthlyAttendance(employeeId, employee.companyId, year, month);
      }

      res.json(monthlyAttendance);
    } catch (error) {
      console.error('Monthly attendance error:', error);
      res.status(500).json({ message: 'Failed to fetch monthly attendance' });
    }
  });

  // Monthly attendance summary - for current employee
  app.get("/api/attendance/monthly/me/:year/:month", authenticateToken, async (req, res) => {
    try {
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      if (isNaN(year) || isNaN(month) || month < 1 || month > 12 || year < 2020 || year > 2030) {
        console.error('Invalid monthly attendance parameters:', { year, month });
        return res.status(400).json({ message: 'Invalid parameters' });
      }

      const employee = await storage.getEmployeeByUserId(req.user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      let monthlyAttendance = await storage.getMonthlyAttendance(employee.id, year, month);
      
      // Calculate if not exists or if requesting current month (to refresh)
      const currentDate = new Date();
      const isCurrentMonth = year === currentDate.getFullYear() && month === (currentDate.getMonth() + 1);
      
      if (!monthlyAttendance || isCurrentMonth) {
        monthlyAttendance = await storage.calculateMonthlyAttendance(employee.id, employee.companyId, year, month);
      }

      res.json(monthlyAttendance);
    } catch (error) {
      console.error('Monthly attendance error:', error);
      res.status(500).json({ message: 'Failed to fetch monthly attendance' });
    }
  });

  // Quick attendance entry
  app.post("/api/attendance/quick-entry", authenticateToken, async (req, res) => {
    try {
      const { employeeId, payDays, otHours, month, year } = req.body;
      
      if (!employeeId || payDays === undefined || otHours === undefined || !month || !year) {
        return res.status(400).json({ message: 'Missing required fields' });
      }

      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Store the attendance data in monthly attendance table
      const result = await storage.upsertMonthlyAttendanceQuickEntry({
        employeeId,
        year,
        month,
        payDays,
        otHours: parseFloat(otHours)
      });

      res.json({
        success: true,
        message: 'Attendance data updated successfully',
        data: result
      });
    } catch (error) {
      console.error('Quick entry error:', error);
      res.status(500).json({ message: 'Failed to update attendance data', error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Get attendance summary for today
  app.get("/api/attendance/summary/today", authenticateToken, async (req, res) => {
    try {
      const companyId = req.user.companyId;
      if (!companyId) {
        return res.status(400).json({ message: 'Company not found' });
      }
      
      const employees = await storage.getEmployeesByCompany(companyId);
      const totalEmployees = employees.length;
      
      const summary = {
        todayPresent: Math.floor(totalEmployees * 0.85) || 1,
        todayAbsent: Math.floor(totalEmployees * 0.15) || 0,
        todayLeave: Math.floor(totalEmployees * 0.08) || 0,
        todayWeeklyOff: Math.floor(totalEmployees * 0.05) || 0,
        continuouslyAbsent: Math.floor(totalEmployees * 0.02) || 0
      };

      res.json(summary);
    } catch (error) {
      console.error('Summary error:', error);
      res.status(500).json({ message: 'Failed to fetch attendance summary' });
    }
  });

  // Get employee attendance data for table
  app.get("/api/attendance/employee-data/:companyId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);

      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const employees = await storage.getEmployeesByCompany(companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      
      const attendanceData = [];
      
      for (const emp of employees) {
        let monthlyRecord = await storage.getMonthlyAttendanceByEmployee(emp.id, year, month);
        
        // If no saved record, calculate defaults
        if (!monthlyRecord) {
          const basePresent = 20 + (emp.id % 5);
          const weeklyOff = 4;
          const leave = emp.id % 3;
          const holidays = 2;
          const payDays = basePresent + weeklyOff + leave + holidays;
          const otHours = (emp.id + 1) * 1.5;
          
          monthlyRecord = {
            presentDays: basePresent,
            payableDays: payDays,
            totalHoursWorked: otHours.toString()
          };
        }
        
        const department = departments.find(d => d.id === emp.departmentId);
        
        attendanceData.push({
          id: emp.id,
          payCode: emp.employeeId,
          employeeName: `${emp.firstName} ${emp.lastName}`,
          department: department?.name || 'N/A',
          present: monthlyRecord.presentDays || 20,
          weeklyOff: 4,
          leave: Math.max(0, (monthlyRecord.payableDays || 26) - (monthlyRecord.presentDays || 20) - 4 - 2),
          holidays: 2,
          payDays: monthlyRecord.payableDays || 26,
          otHours: parseFloat(monthlyRecord.totalHoursWorked || '0')
        });
      }

      res.json(attendanceData);
    } catch (error) {
      console.error('Employee attendance data error:', error);
      res.status(500).json({ message: 'Failed to fetch employee attendance data' });
    }
  });

  // In-memory storage for monthly attendance data (in a real app, this would be in the database)
  const monthlyAttendanceStore = new Map<string, any[]>();

  // Delete attendance record
  app.delete("/api/attendance/delete/:employeeId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);

      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Get the attendance data for this company/month
      const key = `${req.user.companyId}-${year}-${month}`;
      let attendanceData = monthlyAttendanceStore.get(key);
      
      if (!attendanceData) {
        // If no stored data, get fresh data from the main API and store it
        const employees = await storage.getEmployeesByCompany(req.user.companyId);
        const departments = await storage.getDepartmentsByCompany(req.user.companyId);
        
        attendanceData = [];
        for (const emp of employees) {
          // Get monthly attendance record for this employee
          let monthlyRecord;
          try {
            monthlyRecord = await storage.getMonthlyAttendance(emp.id, year, month);
          } catch (error) {
            // If no record exists, generate default data
            const basePresent = 20 + (emp.id % 5);
            const weeklyOff = 4;
            const leave = emp.id % 3;
            const holidays = 2;
            const payDays = basePresent + weeklyOff + leave + holidays;
            const otHours = (emp.id + 1) * 1.5;
            
            monthlyRecord = {
              presentDays: basePresent,
              payableDays: payDays,
              totalHoursWorked: otHours.toString()
            };
          }
          
          const department = departments.find(d => d.id === emp.departmentId);
          
          const safePresentDays = monthlyRecord?.presentDays || 20;
          const safePayableDays = monthlyRecord?.payableDays || 26;
          const safeTotalHours = monthlyRecord?.totalHoursWorked || '0';
          
          attendanceData.push({
            id: emp.id,
            payCode: emp.employeeId,
            employeeName: `${emp.firstName} ${emp.lastName}`,
            department: department?.name || 'N/A',
            present: safePresentDays,
            weeklyOff: 4,
            leave: Math.max(0, safePayableDays - safePresentDays - 4 - 2),
            holidays: 2,
            payDays: safePayableDays,
            otHours: parseFloat(safeTotalHours)
          });
        }
        monthlyAttendanceStore.set(key, attendanceData);
      }

      // Remove the employee's attendance record
      const originalLength = attendanceData.length;
      attendanceData = attendanceData.filter((record: any) => record.id !== employeeId);
      
      if (attendanceData.length === originalLength) {
        return res.status(404).json({ message: 'Attendance record not found' });
      }

      // Update the store
      monthlyAttendanceStore.set(key, attendanceData);

      res.json({
        success: true,
        message: 'Attendance record deleted successfully'
      });
    } catch (error) {
      console.error('Delete attendance error:', error);
      res.status(500).json({ message: 'Failed to delete attendance record' });
    }
  });

  // In-memory storage for daily records (in a real app, this would be in the database)
  const dailyRecordsStore = new Map<string, any[]>();

  const generateInitialDailyRecords = (employeeId: number, year: number, month: number) => {
    const key = `${employeeId}-${year}-${month}`;
    if (dailyRecordsStore.has(key)) {
      return dailyRecordsStore.get(key)!;
    }

    const daysInMonth = new Date(year, month, 0).getDate();
    const dailyRecords = [];
    
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const statuses = ['Present', 'Present', 'Present', 'Present', 'Late', 'Present', 'Absent'];
    const sources = ['Biometric', 'Biometric', 'Manual', 'Biometric', 'Self', 'Biometric', 'Manual'];

    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month - 1, day);
      const dayOfWeek = date.getDay();
      const dayName = dayNames[dayOfWeek];
      
      // Skip Sundays for most records
      if (dayOfWeek === 0 && Math.random() > 0.2) continue;
      
      const status = statuses[day % statuses.length];
      const isPresent = status !== 'Absent';
      
      const baseInHour = 9 + (day % 3) * 0.5; // 9:00-10:30 range
      const baseOutHour = 18 + (day % 2) * 0.5; // 18:00-18:30 range
      
      const inTime = isPresent ? `${Math.floor(baseInHour).toString().padStart(2, '0')}:${((baseInHour % 1) * 60).toString().padStart(2, '0')}` : '';
      const outTime = isPresent ? `${Math.floor(baseOutHour).toString().padStart(2, '0')}:${((baseOutHour % 1) * 60).toString().padStart(2, '0')}` : '';
      
      const workingHours = isPresent ? baseOutHour - baseInHour : 0;
      const otHours = Math.max(0, workingHours - 8);

      dailyRecords.push({
        id: day + employeeId * 100,
        date: date.toISOString().split('T')[0],
        day: dayName,
        inTime,
        outTime,
        workingHours: Math.round(workingHours * 10) / 10,
        otHours: Math.round(otHours * 10) / 10,
        status,
        source: sources[day % sources.length]
      });
    }

    const sortedRecords = dailyRecords.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    dailyRecordsStore.set(key, sortedRecords);
    return sortedRecords;
  };

  // Get daily attendance log for employee
  app.get("/api/attendance/daily-log/:employeeId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);

      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const dailyRecords = generateInitialDailyRecords(employeeId, year, month);
      res.json(dailyRecords);
    } catch (error) {
      console.error('Daily log error:', error);
      res.status(500).json({ message: 'Failed to fetch daily attendance log' });
    }
  });

  // Add daily attendance record
  app.post("/api/attendance/daily-record", authenticateToken, async (req, res) => {
    try {
      const { employeeId, date, inTime, outTime, workingHours, otHours, status, source } = req.body;

      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Parse date to get year and month
      const recordDate = new Date(date);
      const year = recordDate.getFullYear();
      const month = recordDate.getMonth() + 1;
      const key = `${employeeId}-${year}-${month}`;

      // Get or create records for this month
      let records = dailyRecordsStore.get(key) || generateInitialDailyRecords(employeeId, year, month);

      // Create new record
      const newRecord = {
        id: Date.now(), // Use timestamp as unique ID
        date,
        day: recordDate.toLocaleDateString('en-US', { weekday: 'long' }),
        inTime,
        outTime,
        workingHours,
        otHours,
        status,
        source
      };

      // Add the new record
      records.push(newRecord);
      records.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      dailyRecordsStore.set(key, records);

      res.json({
        success: true,
        message: 'Daily attendance record added successfully',
        data: newRecord
      });
    } catch (error) {
      console.error('Add daily record error:', error);
      res.status(500).json({ message: 'Failed to add daily attendance record' });
    }
  });

  // Update daily attendance record
  app.put("/api/attendance/daily-record/:recordId", authenticateToken, async (req, res) => {
    try {
      const recordId = parseInt(req.params.recordId);
      const { date, inTime, outTime, workingHours, otHours, status, source } = req.body;

      // Find the record across all stored data
      let foundRecord = null;
      let foundKey = null;
      
      for (const [key, records] of dailyRecordsStore.entries()) {
        const record = records.find(r => r.id === recordId);
        if (record) {
          foundRecord = record;
          foundKey = key;
          break;
        }
      }

      if (!foundRecord || !foundKey) {
        return res.status(404).json({ message: 'Record not found' });
      }

      // Update the record
      const records = dailyRecordsStore.get(foundKey)!;
      const recordIndex = records.findIndex(r => r.id === recordId);
      
      if (recordIndex !== -1) {
        const recordDate = new Date(date);
        records[recordIndex] = {
          ...records[recordIndex],
          date,
          day: recordDate.toLocaleDateString('en-US', { weekday: 'long' }),
          inTime,
          outTime,
          workingHours,
          otHours,
          status,
          source
        };
        
        // Re-sort the records
        records.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        dailyRecordsStore.set(foundKey, records);
      }

      res.json({
        success: true,
        message: 'Daily attendance record updated successfully',
        data: records[recordIndex]
      });
    } catch (error) {
      console.error('Update daily record error:', error);
      res.status(500).json({ message: 'Failed to update daily attendance record' });
    }
  });

  // Delete daily attendance record
  app.delete("/api/attendance/daily-record/:recordId", authenticateToken, async (req, res) => {
    try {
      const recordId = parseInt(req.params.recordId);

      // Find and delete the record across all stored data
      let deletedRecord = null;
      
      for (const [key, records] of dailyRecordsStore.entries()) {
        const recordIndex = records.findIndex(r => r.id === recordId);
        if (recordIndex !== -1) {
          deletedRecord = records[recordIndex];
          records.splice(recordIndex, 1); // Remove the record
          dailyRecordsStore.set(key, records); // Update the store
          break;
        }
      }

      if (!deletedRecord) {
        return res.status(404).json({ message: 'Record not found' });
      }

      res.json({
        success: true,
        message: 'Daily attendance record deleted successfully',
        data: { recordId, deletedRecord }
      });
    } catch (error) {
      console.error('Delete daily record error:', error);
      res.status(500).json({ message: 'Failed to delete daily attendance record' });
    }
  });

  // User Management Routes (Admin and System Admin only)
  app.get("/api/users", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      let users;
      if (req.user.role === 'system_admin') {
        users = await storage.getAllUsers();
      } else {
        users = await storage.getUsersByCompany(req.user.companyId);
      }
      
      // Remove password from response
      const safeUsers = users.map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        companyId: user.companyId,
        isActive: user.isActive,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      }));
      
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch users' });
    }
  });

  app.post("/api/users", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      // System admin can create users for any company, admin only for their company
      if (req.user.role === 'admin' && req.body.companyId !== req.user.companyId) {
        return res.status(403).json({ message: 'Cannot create users for other companies' });
      }
      
      const userData = req.body;
      const user = await storage.createUser(userData);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'user_created',
        entityType: 'user',
        entityId: user.id,
        details: `Created user: ${user.email}`,
      });
      
      // Remove password from response
      const { password, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create user' });
    }
  });

  app.put("/api/users/:id", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const existingUser = await storage.getUser(userId);
      
      if (!existingUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Permission checks
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      if (req.user.role === 'admin' && existingUser.companyId !== req.user.companyId) {
        return res.status(403).json({ message: 'Cannot edit users from other companies' });
      }
      
      const updatedUser = await storage.updateUser(userId, req.body);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'user_updated',
        entityType: 'user',
        entityId: userId,
        details: `Updated user: ${updatedUser.email}`,
      });
      
      const { password, ...safeUser } = updatedUser;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user' });
    }
  });

  app.delete("/api/users/:id", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const existingUser = await storage.getUser(userId);
      
      if (!existingUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Permission checks
      if (req.user.role !== 'system_admin' && req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      if (req.user.role === 'admin' && existingUser.companyId !== req.user.companyId) {
        return res.status(403).json({ message: 'Cannot delete users from other companies' });
      }
      
      await storage.deleteUser(userId);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'user_deleted',
        entityType: 'user',
        entityId: userId,
        details: `Deleted user: ${existingUser.email}`,
      });
      
      res.json({ message: 'User deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete user' });
    }
  });

  // Company Management Routes (System Admin only)
  app.get("/api/admin/companies", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companies = await storage.getAllCompanies();
      res.json(companies);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch companies' });
    }
  });

  app.post("/api/admin/companies", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companyData = req.body;
      const company = await storage.createCompany(companyData);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: null,
        action: 'company_created',
        entityType: 'company',
        entityId: company.id,
        details: `Created company: ${company.name}`,
      });
      
      res.status(201).json(company);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create company' });
    }
  });

  app.put("/api/admin/companies/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companyId = parseInt(req.params.id);
      const updatedCompany = await storage.updateCompany(companyId, req.body);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: null,
        action: 'company_updated',
        entityType: 'company',
        entityId: companyId,
        details: `Updated company: ${updatedCompany.name}`,
      });
      
      res.json(updatedCompany);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update company' });
    }
  });

  // Company profile update for admins
  app.put("/api/companies/:id", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.id);
      
      // Check if user is admin of this company
      if (req.user.role !== 'admin' || req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      // When profile is completed, set status to pending for approval
      const profileData = { ...req.body, status: 'pending' };
      const updatedCompany = await storage.updateCompanyProfile(companyId, profileData);
      
      res.json(updatedCompany);
    } catch (error) {
      console.error('Company profile update error:', error);
      res.status(500).json({ message: 'Failed to update company profile' });
    }
  });

  // Company approval by system admin
  app.put("/api/admin/companies/:id/approve", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companyId = parseInt(req.params.id);
      const { action } = req.body; // 'approve' or 'reject'
      
      const status = action === 'approve' ? 'approved' : 'rejected';
      const updatedCompany = await storage.updateCompany(companyId, { status });
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: null,
        action: `company_${action}d`,
        entityType: 'company',
        entityId: companyId,
        details: `${action === 'approve' ? 'Approved' : 'Rejected'} company: ${updatedCompany.name}`,
      });
      
      res.json(updatedCompany);
    } catch (error) {
      console.error('Company approval error:', error);
      res.status(500).json({ message: 'Failed to process company approval' });
    }
  });

  // Delete company by system admin
  app.delete("/api/admin/companies/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companyId = parseInt(req.params.id);
      const company = await storage.getCompany(companyId);
      
      if (!company) {
        return res.status(404).json({ message: 'Company not found' });
      }
      
      await storage.deleteCompany(companyId);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: null,
        action: 'company_deleted',
        entityType: 'company',
        entityId: companyId,
        details: `Deleted company: ${company.name}`,
      });
      
      res.json({ message: 'Company deleted successfully' });
    } catch (error) {
      console.error('Company deletion error:', error);
      res.status(500).json({ message: 'Failed to delete company' });
    }
  });

  // Permission Management Routes
  app.get("/api/permissions", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const permissions = await storage.getPermissions();
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch permissions' });
    }
  });

  app.get("/api/permission-requests", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        const userRequests = await storage.getPermissionRequestsByUser(req.user.id);
        return res.json(userRequests);
      }
      
      let requests;
      if (req.user.role === 'system_admin') {
        requests = await storage.getPermissionRequests();
      } else {
        requests = await storage.getPermissionRequests(req.user.companyId);
      }
      
      res.json(requests);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch permission requests' });
    }
  });

  app.post("/api/permission-requests", authenticateToken, async (req, res) => {
    try {
      const { permissionType, reason } = req.body;
      
      if (!permissionType || !reason) {
        return res.status(400).json({ message: 'Permission type and reason are required' });
      }
      
      const requestData = {
        userId: req.user.id,
        requestedBy: req.user.id,
        permissionType: permissionType as any,
        reason,
        companyId: req.user.companyId,
        status: 'pending' as any
      };
      
      const permissionRequest = await storage.createPermissionRequest(requestData);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'permission_requested',
        entityType: 'permission_request',
        entityId: permissionRequest.id,
        details: `Requested permission: ${permissionRequest.permissionType}`,
      });
      
      res.status(201).json(permissionRequest);
    } catch (error) {
      console.error('Permission request creation error:', error);
      res.status(500).json({ message: 'Failed to create permission request' });
    }
  });

  app.put("/api/permission-requests/:id", authenticateToken, async (req, res) => {
    try {
      const requestId = parseInt(req.params.id);
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const updatedRequest = await storage.updatePermissionRequest(requestId, {
        ...req.body,
        reviewedBy: req.user.id,
        reviewedAt: new Date(),
      });
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'permission_reviewed',
        entityType: 'permission_request',
        entityId: requestId,
        details: `${req.body.status === 'approved' ? 'Approved' : 'Rejected'} permission request`,
      });
      
      res.json(updatedRequest);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update permission request' });
    }
  });

  // User Activities/Audit Trail
  app.get("/api/activities", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        const activities = await storage.getUserActivities(undefined, req.user.id);
        return res.json(activities);
      }
      
      let activities;
      if (req.user.role === 'system_admin') {
        activities = await storage.getUserActivities();
      } else {
        activities = await storage.getUserActivities(req.user.companyId);
      }
      
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch activities' });
    }
  });

  // Public routes for signup

  // Employee profile routes
  app.get("/api/employee/profile", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      // Check if user has an employee profile first
      const profile = await storage.getEmployeeProfileByUserId(user.id);
      if (profile) {
        res.json(profile);
        return;
      }

      // Fallback to old employee record if exists
      const employee = await storage.getEmployeeByUserId(user.id);
      res.json(employee);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch employee profile' });
    }
  });

  app.put("/api/employee/profile", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const profileData = req.body;
      const updatedProfile = await storage.updateEmployeeProfile(user.id, profileData);
      
      res.json(updatedProfile);
    } catch (error) {
      console.error('Error updating employee profile:', error);
      res.status(500).json({ message: 'Failed to update employee profile' });
    }
  });

  // KYC details routes
  app.get('/api/employee/kyc', authenticateToken, async (req, res) => {
    try {
      const profile = await storage.getEmployeeProfileByUserId(req.user!.id);
      if (!profile) {
        return res.status(404).json({ error: 'Employee profile not found' });
      }
      
      const kycDetails = await storage.getKycDetailsByProfile(profile.id);
      res.json(kycDetails || {});
    } catch (error) {
      res.status(500).json({ error: 'Failed to get KYC details' });
    }
  });

  app.put('/api/employee/kyc', authenticateToken, async (req, res) => {
    try {
      const profile = await storage.getEmployeeProfileByUserId(req.user!.id);
      if (!profile) {
        return res.status(404).json({ error: 'Employee profile not found' });
      }
      
      const kycDetails = await storage.updateKycDetails(profile.id, req.body);
      res.json(kycDetails);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update KYC details' });
    }
  });

  // Admin endpoint: Lookup employee by Aadhaar for auto-filling form
  app.post("/api/admin/lookup-employee-by-aadhaar", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      const { aadhaarNo } = req.body;
      
      if (user.role !== 'admin' && user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Access denied' });
      }

      if (!aadhaarNo) {
        return res.status(400).json({ message: 'Aadhaar number is required' });
      }

      // Clean Aadhaar number
      const cleanAadhaar = aadhaarNo.replace(/\s/g, '');
      
      // Get employee profile and KYC details by Aadhaar
      const result = await db.select({
        kycDetails: kycDetails,
        employeeProfile: employeeProfiles
      })
        .from(kycDetails)
        .innerJoin(employeeProfiles, eq(kycDetails.employeeProfileId, employeeProfiles.id))
        .where(eq(kycDetails.aadharNo, cleanAadhaar))
        .limit(1);

      if (result.length === 0) {
        return res.json({
          found: false,
          message: 'No employee profile found for this Aadhaar number'
        });
      }

      const employeeData = result[0];
      
      return res.json({
        found: true,
        employeeProfile: employeeData.employeeProfile,
        kycDetails: employeeData.kycDetails,
        message: 'Employee profile found and loaded'
      });
      
    } catch (error) {
      console.error('Error looking up employee by Aadhaar:', error);
      res.status(500).json({ message: 'Failed to lookup employee data' });
    }
  });

  // Check employee status by Aadhaar after verification
  app.get("/api/employee/aadhaar-status", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Get employee profile and KYC details
      const profile = await storage.getEmployeeProfileByUserId(user.id);
      if (!profile) {
        return res.status(404).json({ message: 'Employee profile not found' });
      }

      const kycDetails = await storage.getKycDetailsByProfile(profile.id);
      if (!kycDetails || !kycDetails.aadharNo) {
        return res.json({
          aadhaarVerified: false,
          isEmployeeInCompany: false,
          message: 'Aadhaar verification required'
        });
      }

      // Check if employee exists in any company database by Aadhaar
      const employeeStatus = await storage.getEmployeeStatusByAadhaar(kycDetails.aadharNo);
      
      res.json({
        aadhaarVerified: true,
        isEmployeeInCompany: employeeStatus.isEmployeeInCompany,
        employeeData: employeeStatus.employeeData,
        companyData: employeeStatus.companyData,
        currentUser: user
      });
    } catch (error) {
      console.error('Aadhaar status check error:', error);
      res.status(500).json({ message: 'Failed to check employee status' });
    }
  });

  // Recruitment Management Routes
  
  // Get job applications for company
  app.get('/api/job-applications/:companyId', authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const applications = await storage.getJobApplicationsByCompany(companyId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch job applications' });
    }
  });

  // Update job application status
  app.put('/api/job-applications/:id/status', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      const application = await storage.updateJobApplicationStatus(id, status, req.user!.id);
      res.json(application);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update application status' });
    }
  });

  // Get interviews for company
  app.get('/api/interviews/:companyId', authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const interviews = await storage.getInterviewsByCompany(companyId);
      res.json(interviews);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch interviews' });
    }
  });

  // Schedule interview
  app.post('/api/interviews', authenticateToken, async (req, res) => {
    try {
      const interviewData = req.body;
      const interview = await storage.createInterview(interviewData);
      res.status(201).json(interview);
    } catch (error) {
      res.status(500).json({ message: 'Failed to schedule interview' });
    }
  });

  // Update interview status
  app.put('/api/interviews/:id/status', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, notes } = req.body;
      
      const interview = await storage.updateInterviewStatus(id, status, notes);
      res.json(interview);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update interview status' });
    }
  });

  // Create job offer
  app.post('/api/job-offers', authenticateToken, async (req, res) => {
    try {
      const offerData = req.body;
      const offer = await storage.createJobOffer(offerData);
      res.status(201).json(offer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create job offer' });
    }
  });

  // Get job offers for company
  app.get('/api/job-offers/:companyId', authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const offers = await storage.getJobOffersByCompany(companyId);
      res.json(offers);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch job offers' });
    }
  });

  // Update job offer status
  app.put('/api/job-offers/:id/status', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      const offer = await storage.updateJobOfferStatus(id, status);
      res.json(offer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update offer status' });
    }
  });

  app.get("/api/job-applications/my", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const applications = await storage.getJobApplicationsByEmail(user.email);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch applications' });
    }
  });

  // Zod schemas for leave and advance requests
  const insertLeaveRequestSchema = createInsertSchema(leaveRequests).omit({
    id: true,
    employeeId: true,
    companyId: true,
    createdAt: true,
    updatedAt: true,
    appliedAt: true,
    level1ApproverId: true,
    level1ApprovedAt: true,
    level1Comments: true,
    level2ApproverId: true,
    level2ApprovedAt: true,
    level2Comments: true,
    finalApproverId: true,
    finalApprovedAt: true,
    finalComments: true,
    rejectedById: true,
    rejectedAt: true,
    rejectionReason: true
  });

  const insertAdvanceRequestSchema = createInsertSchema(advanceRequests).omit({
    id: true,
    employeeId: true,
    companyId: true,
    createdAt: true,
    updatedAt: true,
    appliedAt: true,
    level1ApproverId: true,
    level1ApprovedAt: true,
    level1Comments: true,
    level2ApproverId: true,
    level2ApprovedAt: true,
    level2Comments: true,
    finalApproverId: true,
    finalApprovedAt: true,
    finalComments: true,
    rejectedById: true,
    rejectedAt: true,
    rejectionReason: true,
    paidAmount: true,
    paidAt: true,
    paymentMethod: true,
    paymentReference: true
  });

  // Leave Request routes
  app.get('/api/leave-requests/:companyId', authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const user = req.user as { id: number; companyId: number; role: string };
      
      if (user.role !== 'system_admin' && user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      let requests;
      if (user.role === 'employee') {
        // Employees can only see their own requests
        const employee = await storage.getEmployeeByUserId(user.id);
        if (!employee) {
          return res.status(404).json({ message: 'Employee not found' });
        }
        requests = await storage.getLeaveRequestsByEmployee(employee.id);
      } else {
        // Admins and system admins can see all company requests
        requests = await storage.getLeaveRequestsByCompany(companyId);
      }

      res.json(requests);
    } catch (error) {
      console.error('Error fetching leave requests:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post('/api/leave-requests', authenticateToken, async (req, res) => {
    try {
      const user = req.user as { id: number; companyId: number; role: string };
      const requestData = insertLeaveRequestSchema.parse(req.body);
      
      // Get employee record for the user
      const employee = await storage.getEmployeeByUserId(user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      // Create leave request
      const leaveRequest = await storage.createLeaveRequest({
        ...requestData,
        employeeId: employee.id,
        companyId: user.companyId
      });

      res.status(201).json(leaveRequest);
    } catch (error) {
      console.error('Error creating leave request:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/leave-requests/:id/approve', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { level, comments } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.approveLeaveRequest(id, level, user.id, comments);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error approving leave request:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/leave-requests/:id/reject', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { reason } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.rejectLeaveRequest(id, user.id, reason);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error rejecting leave request:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Advance Request routes
  app.get('/api/advance-requests/:companyId', authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const user = req.user as { id: number; companyId: number; role: string };
      
      if (user.role !== 'system_admin' && user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      let requests;
      if (user.role === 'employee') {
        // Employees can only see their own requests
        const employee = await storage.getEmployeeByUserId(user.id);
        if (!employee) {
          return res.status(404).json({ message: 'Employee not found' });
        }
        requests = await storage.getAdvanceRequestsByEmployee(employee.id);
      } else {
        // Admins and system admins can see all company requests
        requests = await storage.getAdvanceRequestsByCompany(companyId);
      }

      res.json(requests);
    } catch (error) {
      console.error('Error fetching advance requests:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post('/api/advance-requests', authenticateToken, async (req, res) => {
    try {
      const user = req.user as { id: number; companyId: number; role: string };
      const requestData = insertAdvanceRequestSchema.parse(req.body);
      
      // Get employee record for the user
      const employee = await storage.getEmployeeByUserId(user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      // Create advance request
      const advanceRequest = await storage.createAdvanceRequest({
        ...requestData,
        employeeId: employee.id,
        companyId: user.companyId
      });

      res.status(201).json(advanceRequest);
    } catch (error) {
      console.error('Error creating advance request:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/advance-requests/:id/approve', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { level, comments } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.approveAdvanceRequest(id, level, user.id, comments);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error approving advance request:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/advance-requests/:id/reject', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { reason } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.rejectAdvanceRequest(id, user.id, reason);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error rejecting advance request:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/advance-requests/:id/mark-paid', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { paidAmount, paymentMethod, paymentReference } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.markAdvancePaid(id, paidAmount, paymentMethod, paymentReference);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error marking advance as paid:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Signup routes
  app.post("/api/companies/signup", async (req, res) => {
    try {
      const companyData = req.body;
      const company = await storage.createCompany({
        ...companyData,
        status: 'active',
      });
      res.status(201).json(company);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create company' });
    }
  });

  // Admin signup endpoint - simplified (3 fields only)
  app.post("/api/users/admin-signup", async (req, res) => {
    try {
      const { name, email, password } = req.body;
      
      if (!name || !email || !password) {
        return res.status(400).json({ message: 'Name, email, and password are required' });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({ message: 'Email already registered' });
      }

      // Create a default company for the admin (pending approval)
      const company = await storage.createCompany({
        name: `${name}'s Company`,
        email: email,
        phone: '',
        address: '',
        status: 'pending',
      });

      // Create admin user with simplified data
      const username = name.toLowerCase().replace(/\s+/g, '').substring(0, 20);
      const user = await storage.createUser({
        username,
        email,
        password,
        role: 'admin',
        companyId: company.id,
      });

      // Remove password from response
      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      console.error('Admin signup error:', error);
      res.status(500).json({ message: 'Failed to create admin account' });
    }
  });

  // Employee signup endpoint - simplified (3 fields only)
  app.post("/api/users/employee-signup", async (req, res) => {
    try {
      const { name, email, password } = req.body;
      
      if (!name || !email || !password) {
        return res.status(400).json({ message: 'Name, email, and password are required' });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({ message: 'Email already registered' });
      }
      
      // Create user without company association initially
      const username = name.toLowerCase().replace(/\s+/g, '').substring(0, 20);
      const user = await storage.createUser({
        username,
        email,
        password,
        role: 'employee',
        companyId: null, // No company association initially
      });
      
      // Create employee profile with minimal data - split name into first/last
      const nameParts = name.trim().split(' ');
      const firstName = nameParts[0] || name;
      const lastName = nameParts.slice(1).join(' ') || '';
      
      await storage.createEmployeeProfile({
        userId: user.id,
        firstName,
        lastName,
        skills: '',
        experience: '',  
        phone: '',
        address: '',
      });
      
      // Remove password from response
      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      console.error('Employee signup error:', error);
      
      // Handle specific database constraint errors
      if (error.code === '23505') {
        if (error.constraint === 'users_email_unique') {
          return res.status(409).json({ message: 'Email already registered' });
        }
      }
      
      res.status(500).json({ message: 'Failed to create employee account' });
    }
  });

  // Payroll Routes
  app.get("/api/payroll/monthly/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const payrolls = await storage.getMonthlyPayrolls(companyId);
      
      // Add record count and total amount for each payroll
      const enrichedPayrolls = await Promise.all(payrolls.map(async (payroll) => {
        try {
          const records = await storage.getPayrollRecords(payroll.id);
          const totalAmount = records.reduce((sum, record) => {
            const netSalary = parseFloat(record.netSalary || '0');
            return sum + (isNaN(netSalary) ? 0 : netSalary);
          }, 0);
          return {
            ...payroll,
            recordCount: records.length,
            totalAmount
          };
        } catch (error) {
          console.error(`Error processing payroll ${payroll.id}:`, error);
          return {
            ...payroll,
            recordCount: 0,
            totalAmount: 0
          };
        }
      }));
      
      res.json(enrichedPayrolls);
    } catch (error: any) {
      console.error('Error fetching monthly payrolls:', error);
      res.status(500).json({ message: error.message || 'Failed to fetch payrolls' });
    }
  });

  app.get("/api/payroll/records/:payrollId", authenticateToken, async (req, res) => {
    try {
      const payrollId = parseInt(req.params.payrollId);
      
      // First verify the payroll exists and user has access
      const payroll = await storage.getMonthlyPayroll(payrollId);
      if (!payroll) {
        return res.status(404).json({ message: 'Payroll not found' });
      }
      
      // Check company access for non-system admins
      if (req.user.role !== 'system_admin' && req.user.companyId !== payroll.companyId) {
        return res.status(403).json({ message: 'Access denied to this payroll' });
      }
      
      const records = await storage.getPayrollRecords(payrollId);
      
      // Enrich records with employee details
      const enrichedRecords = await Promise.all(records.map(async (record) => {
        const employee = await storage.getEmployee(record.employeeId);
        const departments = await storage.getDepartmentsByCompany(payroll.companyId);
        const department = departments.find(d => d.id === employee?.departmentId);
        
        return {
          ...record,
          employeeName: employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown',
          employeeCode: employee?.employeeId || 'N/A',
          department: department?.name || 'N/A'
        };
      }));
      
      res.json(enrichedRecords);
    } catch (error: any) {
      console.error('Error fetching payroll records:', error);
      res.status(500).json({ message: error.message || 'Failed to fetch payroll records' });
    }
  });

  app.post("/api/payroll/generate", authenticateToken, async (req, res) => {
    try {
      const { month, year } = req.body;
      const companyId = req.user.companyId;
      const generatedBy = req.user.id;
      
      if (!month || !year || !companyId) {
        return res.status(400).json({ message: 'Month, year, and company ID are required' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Employees cannot generate payroll' });
      }
      
      // Use new automated PayrollService instead of legacy method
      const { PayrollService } = await import('./PayrollService');
      const payroll = await PayrollService.generate(companyId, year, month, generatedBy);
      res.json(payroll);
    } catch (error: any) {
      console.error('Error generating payroll:', error);
      res.status(500).json({ message: error.message || 'Failed to generate payroll' });
    }
  });

  app.put("/api/payroll/finalize/:payrollId", authenticateToken, async (req, res) => {
    try {
      const payrollId = parseInt(req.params.payrollId);
      const finalizedBy = req.user.id;
      
      // Verify payroll exists and user has access
      const payroll = await storage.getMonthlyPayroll(payrollId);
      if (!payroll) {
        return res.status(404).json({ message: 'Payroll not found' });
      }
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== payroll.companyId) {
        return res.status(403).json({ message: 'Access denied to this payroll' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Employees cannot finalize payroll' });
      }
      
      if (payroll.status === 'finalized') {
        return res.status(400).json({ message: 'Payroll is already finalized' });
      }
      
      const finalizedPayroll = await storage.finalizePayroll(payrollId, finalizedBy);
      res.json(finalizedPayroll);
    } catch (error: any) {
      console.error('Error finalizing payroll:', error);
      res.status(500).json({ message: error.message || 'Failed to finalize payroll' });
    }
  });

  // Delete monthly payroll (only for draft status)
  app.delete("/api/payroll/monthly/:payrollId", authenticateToken, async (req, res) => {
    try {
      const payrollId = parseInt(req.params.payrollId);
      
      // Verify payroll exists and user has access
      const payroll = await storage.getMonthlyPayroll(payrollId);
      if (!payroll) {
        return res.status(404).json({ message: 'Payroll not found' });
      }
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== payroll.companyId) {
        return res.status(403).json({ message: 'Access denied to this payroll' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Employees cannot delete payroll' });
      }
      
      if (payroll.status === 'finalized') {
        return res.status(400).json({ message: 'Cannot delete finalized payroll' });
      }
      
      const deleted = await storage.deleteMonthlyPayroll(payrollId);
      if (!deleted) {
        return res.status(404).json({ message: 'Payroll not found or could not be deleted' });
      }
      
      res.status(204).end();
    } catch (error: any) {
      console.error('Error deleting payroll:', error);
      res.status(500).json({ message: error.message || 'Failed to delete payroll' });
    }
  });

  app.put("/api/payroll/payment/:recordId", authenticateToken, async (req, res) => {
    try {
      const recordId = parseInt(req.params.recordId);
      const { status, amount, method, reference } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: 'Payment status is required' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Employees cannot update payment status' });
      }
      
      const updatedRecord = await storage.updatePaymentStatus(recordId, status, amount, method, reference);
      res.json(updatedRecord);
    } catch (error: any) {
      console.error('Error updating payment status:', error);
      res.status(500).json({ message: error.message || 'Failed to update payment status' });
    }
  });

  // Enhanced Permission Management API Routes
  
  // Get all permissions with filtering
  app.get("/api/permissions/enhanced", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const { category, module } = req.query;
      let permissions;
      
      if (category) {
        permissions = await storage.getPermissionsByCategory(category as string);
      } else if (module) {
        permissions = await storage.getPermissionsByModule(module as string);
      } else {
        permissions = await storage.getAllPermissions();
      }
      
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch permissions' });
    }
  });

  // Create new permission
  app.post("/api/permissions/enhanced", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can create permissions' });
      }
      
      const permission = await storage.createPermission(req.body);
      res.status(201).json(permission);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create permission' });
    }
  });

  // Update permission
  app.put("/api/permissions/enhanced/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can update permissions' });
      }
      
      const id = parseInt(req.params.id);
      const permission = await storage.updatePermission(id, req.body);
      res.json(permission);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update permission' });
    }
  });

  // Delete permission
  app.delete("/api/permissions/enhanced/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can delete permissions' });
      }
      
      const id = parseInt(req.params.id);
      await storage.deletePermission(id);
      res.json({ message: 'Permission deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete permission' });
    }
  });

  // User Permission Routes
  
  // Get user permissions
  app.get("/api/user-permissions/:userId", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const companyId = req.user.companyId;
      
      if (req.user.role === 'employee' && req.user.id !== userId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      const permissions = await storage.getUserPermissions(userId, companyId);
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch user permissions' });
    }
  });

  // Check user permission
  app.get("/api/user-permissions/:userId/check/:permissionName", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const permissionName = req.params.permissionName;
      const companyId = req.user.companyId;
      
      if (req.user.role === 'employee' && req.user.id !== userId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      const hasPermission = await storage.hasUserPermission(userId, permissionName, companyId);
      res.json({ hasPermission });
    } catch (error) {
      res.status(500).json({ message: 'Failed to check user permission' });
    }
  });

  // Grant user permission
  app.post("/api/user-permissions", authenticateToken, async (req, res) => {
    try {
      console.log('Grant permission request received:', req.body);
      console.log('User making request:', req.user);
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const grantData = {
        ...req.body,
        grantedBy: req.user.id,
        companyId: req.user.companyId,
        isActive: true,
        grantedAt: new Date()
      };
      
      console.log('About to grant permission with data:', grantData);
      const userPermission = await storage.grantUserPermission(grantData);
      console.log('Permission granted successfully:', userPermission);
      
      res.status(201).json(userPermission);
    } catch (error) {
      console.error('Failed to grant permission - ERROR:', error);
      res.status(500).json({ message: 'Failed to grant permission', error: error.message });
    }
  });

  // Revoke user permission
  app.delete("/api/user-permissions/:userId/:permissionId", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const userId = parseInt(req.params.userId);
      const permissionId = parseInt(req.params.permissionId);
      const companyId = req.user.companyId;
      
      await storage.revokeUserPermission(userId, permissionId, companyId);
      res.json({ message: 'Permission revoked successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to revoke permission' });
    }
  });

  // Enhanced Permission Request Routes
  
  // Get permission requests with enhanced filtering
  app.get("/api/permission-requests/enhanced", authenticateToken, async (req, res) => {
    try {
      // Use basic permission requests for now
      const requests = await storage.getPermissionRequests(req.user.companyId);
      res.json(requests);
    } catch (error) {
      console.error('Permission requests error:', error);
      res.status(500).json({ message: 'Failed to fetch permission requests' });
    }
  });

  // Create enhanced permission request
  app.post("/api/permission-requests/enhanced", authenticateToken, async (req, res) => {
    try {
      const request = await storage.createPermissionRequestEnhanced({
        ...req.body,
        userId: req.user.id,
        companyId: req.user.companyId
      });
      
      res.status(201).json(request);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create permission request' });
    }
  });

  // Approve permission request by level
  app.put("/api/permission-requests/enhanced/:id/approve", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const id = parseInt(req.params.id);
      const { level, comments } = req.body;
      
      const request = await storage.approvePermissionRequestLevel(id, req.user.id, level, comments);
      res.json(request);
    } catch (error) {
      res.status(500).json({ message: 'Failed to approve permission request' });
    }
  });

  // Reject permission request by level
  app.put("/api/permission-requests/enhanced/:id/reject", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const id = parseInt(req.params.id);
      const { level, comments } = req.body;
      
      const request = await storage.rejectPermissionRequestLevel(id, req.user.id, level, comments);
      res.json(request);
    } catch (error) {
      res.status(500).json({ message: 'Failed to reject permission request' });
    }
  });

  // Role Permission Routes
  
  // Get role permissions
  app.get("/api/role-permissions/:role", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const role = req.params.role;
      const companyId = req.user.role === 'system_admin' ? undefined : req.user.companyId;
      
      const permissions = await storage.getRolePermissionsEnhanced(role, companyId);
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch role permissions' });
    }
  });

  // Assign role permission
  app.post("/api/role-permissions", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const rolePermission = await storage.assignRolePermission({
        ...req.body,
        companyId: req.user.role === 'system_admin' ? req.body.companyId : req.user.companyId
      });
      
      res.status(201).json(rolePermission);
    } catch (error) {
      res.status(500).json({ message: 'Failed to assign role permission' });
    }
  });

  // Remove role permission
  app.delete("/api/role-permissions/:role/:permissionId", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const role = req.params.role;
      const permissionId = parseInt(req.params.permissionId);
      const companyId = req.user.role === 'system_admin' ? undefined : req.user.companyId;
      
      await storage.removeRolePermission(role, permissionId, companyId);
      res.json({ message: 'Role permission removed successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to remove role permission' });
    }
  });

  // Permission Template Routes
  
  // Get permission templates
  app.get("/api/permission-templates", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const { role } = req.query;
      const templates = await storage.getPermissionTemplates(role as string);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch permission templates' });
    }
  });

  // Create permission template
  app.post("/api/permission-templates", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can create templates' });
      }
      
      const template = await storage.createPermissionTemplate(req.body);
      res.status(201).json(template);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create permission template' });
    }
  });

  // Update permission template
  app.put("/api/permission-templates/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can update templates' });
      }
      
      const id = parseInt(req.params.id);
      const template = await storage.updatePermissionTemplate(id, req.body);
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update permission template' });
    }
  });

  // Delete permission template
  app.delete("/api/permission-templates/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can delete templates' });
      }
      
      const id = parseInt(req.params.id);
      await storage.deletePermissionTemplate(id);
      res.json({ message: 'Permission template deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete permission template' });
    }
  });

  // Apply permission template
  app.post("/api/permission-templates/:id/apply", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const templateId = parseInt(req.params.id);
      const { userId } = req.body;
      
      const permissions = await storage.applyPermissionTemplate(
        templateId, 
        userId, 
        req.user.companyId, 
        req.user.id
      );
      
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to apply permission template' });
    }
  });

  // Company Settings API Routes
  // Biometric Machines
  app.get("/api/biometric-machines/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const machines = await storage.getBiometricMachinesByCompany(companyId);
      res.json(machines);
    } catch (error) {
      console.error('Error fetching biometric machines:', error);
      res.status(500).json({ message: 'Failed to fetch biometric machines' });
    }
  });

  app.post("/api/biometric-machines", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const machineData = { ...req.body, companyId: req.user.companyId };
      const machine = await storage.createBiometricMachine(machineData);
      res.json(machine);
    } catch (error) {
      console.error('Error creating biometric machine:', error);
      res.status(500).json({ message: 'Failed to create biometric machine' });
    }
  });

  app.put("/api/biometric-machines/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const machine = await storage.updateBiometricMachine(id, req.body);
      res.json(machine);
    } catch (error) {
      console.error('Error updating biometric machine:', error);
      res.status(500).json({ message: 'Failed to update biometric machine' });
    }
  });

  app.delete("/api/biometric-machines/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteBiometricMachine(id);
      res.json({ message: 'Biometric machine deleted' });
    } catch (error) {
      console.error('Error deleting biometric machine:', error);
      res.status(500).json({ message: 'Failed to delete biometric machine' });
    }
  });

  // Holidays
  app.get("/api/holidays/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const holidays = await storage.getHolidaysByCompany(companyId);
      res.json(holidays);
    } catch (error) {
      console.error('Error fetching holidays:', error);
      res.status(500).json({ message: 'Failed to fetch holidays' });
    }
  });

  app.post("/api/holidays", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const holidayData = { ...req.body, companyId: req.user.companyId };
      const holiday = await storage.createHoliday(holidayData);
      res.json(holiday);
    } catch (error) {
      console.error('Error creating holiday:', error);
      res.status(500).json({ message: 'Failed to create holiday' });
    }
  });

  app.put("/api/holidays/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const holiday = await storage.updateHoliday(id, req.body);
      res.json(holiday);
    } catch (error) {
      console.error('Error updating holiday:', error);
      res.status(500).json({ message: 'Failed to update holiday' });
    }
  });

  app.delete("/api/holidays/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteHoliday(id);
      res.json({ message: 'Holiday deleted' });
    } catch (error) {
      console.error('Error deleting holiday:', error);
      res.status(500).json({ message: 'Failed to delete holiday' });
    }
  });

  // Leave Policies
  app.get("/api/leave-policies/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const policies = await storage.getLeavePoliciesByCompany(companyId);
      res.json(policies);
    } catch (error) {
      console.error('Error fetching leave policies:', error);
      res.status(500).json({ message: 'Failed to fetch leave policies' });
    }
  });

  app.post("/api/leave-policies", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const policyData = { ...req.body, companyId: req.user.companyId };
      const policy = await storage.createLeavePolicy(policyData);
      res.json(policy);
    } catch (error) {
      console.error('Error creating leave policy:', error);
      res.status(500).json({ message: 'Failed to create leave policy' });
    }
  });

  app.put("/api/leave-policies/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const policy = await storage.updateLeavePolicy(id, req.body);
      res.json(policy);
    } catch (error) {
      console.error('Error updating leave policy:', error);
      res.status(500).json({ message: 'Failed to update leave policy' });
    }
  });

  app.delete("/api/leave-policies/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteLeavePolicy(id);
      res.json({ message: 'Leave policy deleted' });
    } catch (error) {
      console.error('Error deleting leave policy:', error);
      res.status(500).json({ message: 'Failed to delete leave policy' });
    }
  });

  // Designations
  app.get("/api/designations/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const designations = await storage.getDesignationsByCompany(companyId);
      res.json(designations);
    } catch (error) {
      console.error('Error fetching designations:', error);
      res.status(500).json({ message: 'Failed to fetch designations' });
    }
  });

  app.post("/api/designations", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const designationData = { ...req.body, companyId: req.user.companyId };
      const designation = await storage.createDesignation(designationData);
      res.json(designation);
    } catch (error) {
      console.error('Error creating designation:', error);
      res.status(500).json({ message: 'Failed to create designation' });
    }
  });

  app.put("/api/designations/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const designation = await storage.updateDesignation(id, req.body);
      res.json(designation);
    } catch (error) {
      console.error('Error updating designation:', error);
      res.status(500).json({ message: 'Failed to update designation' });
    }
  });

  app.delete("/api/designations/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteDesignation(id);
      res.json({ message: 'Designation deleted' });
    } catch (error) {
      console.error('Error deleting designation:', error);
      res.status(500).json({ message: 'Failed to delete designation' });
    }
  });

  // Branches
  app.get("/api/branches/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const branches = await storage.getBranchesByCompany(companyId);
      res.json(branches);
    } catch (error) {
      console.error('Error fetching branches:', error);
      res.status(500).json({ message: 'Failed to fetch branches' });
    }
  });

  app.post("/api/branches", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const branchData = { ...req.body, companyId: req.user.companyId };
      const branch = await storage.createBranch(branchData);
      res.json(branch);
    } catch (error) {
      console.error('Error creating branch:', error);
      res.status(500).json({ message: 'Failed to create branch' });
    }
  });

  app.put("/api/branches/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const branch = await storage.updateBranch(id, req.body);
      res.json(branch);
    } catch (error) {
      console.error('Error updating branch:', error);
      res.status(500).json({ message: 'Failed to update branch' });
    }
  });

  app.delete("/api/branches/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteBranch(id);
      res.json({ message: 'Branch deleted' });
    } catch (error) {
      console.error('Error deleting branch:', error);
      res.status(500).json({ message: 'Failed to delete branch' });
    }
  });

  // Locations
  app.get("/api/locations/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const locations = await storage.getLocationsByCompany(companyId);
      res.json(locations);
    } catch (error) {
      console.error('Error fetching locations:', error);
      res.status(500).json({ message: 'Failed to fetch locations' });
    }
  });

  app.post("/api/locations", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const locationData = { ...req.body, companyId: req.user.companyId };
      const location = await storage.createLocation(locationData);
      res.json(location);
    } catch (error) {
      console.error('Error creating location:', error);
      res.status(500).json({ message: 'Failed to create location' });
    }
  });

  app.put("/api/locations/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const location = await storage.updateLocation(id, req.body);
      res.json(location);
    } catch (error) {
      console.error('Error updating location:', error);
      res.status(500).json({ message: 'Failed to update location' });
    }
  });

  app.delete("/api/locations/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteLocation(id);
      res.json({ message: 'Location deleted' });
    } catch (error) {
      console.error('Error deleting location:', error);
      res.status(500).json({ message: 'Failed to delete location' });
    }
  });

  // Cost Centers
  app.get("/api/cost-centers/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const costCenters = await storage.getCostCentersByCompany(companyId);
      res.json(costCenters);
    } catch (error) {
      console.error('Error fetching cost centers:', error);
      res.status(500).json({ message: 'Failed to fetch cost centers' });
    }
  });

  app.post("/api/cost-centers", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const costCenterData = { ...req.body, companyId: req.user.companyId };
      const costCenter = await storage.createCostCenter(costCenterData);
      res.json(costCenter);
    } catch (error) {
      console.error('Error creating cost center:', error);
      res.status(500).json({ message: 'Failed to create cost center' });
    }
  });

  app.put("/api/cost-centers/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const costCenter = await storage.updateCostCenter(id, req.body);
      res.json(costCenter);
    } catch (error) {
      console.error('Error updating cost center:', error);
      res.status(500).json({ message: 'Failed to update cost center' });
    }
  });

  app.delete("/api/cost-centers/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteCostCenter(id);
      res.json({ message: 'Cost center deleted' });
    } catch (error) {
      console.error('Error deleting cost center:', error);
      res.status(500).json({ message: 'Failed to delete cost center' });
    }
  });

  // Client Compliances API Routes
  
  // Get clients by company
  app.get("/api/clients/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const clients = await storage.getClientsByCompany(companyId);
      res.json(clients);
    } catch (error) {
      console.error('Error fetching clients:', error);
      res.status(500).json({ message: 'Failed to fetch clients' });
    }
  });

  // Create client
  app.post("/api/clients", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const clientData = { ...req.body, companyId: req.user.companyId };
      const client = await storage.createClient(clientData);
      res.json(client);
    } catch (error) {
      console.error('Error creating client:', error);
      res.status(500).json({ message: 'Failed to create client' });
    }
  });

  // Update client
  app.put("/api/clients/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const client = await storage.updateClient(id, req.body);
      res.json(client);
    } catch (error) {
      console.error('Error updating client:', error);
      res.status(500).json({ message: 'Failed to update client' });
    }
  });

  // Delete client
  app.delete("/api/clients/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteClient(id);
      res.json({ message: 'Client deleted' });
    } catch (error) {
      console.error('Error deleting client:', error);
      res.status(500).json({ message: 'Failed to delete client' });
    }
  });

  // Compliance Setups API Routes
  
  // Get compliance setups by company
  app.get("/api/compliance-setups/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const setups = await storage.getComplianceSetupsByCompany(companyId);
      res.json(setups);
    } catch (error) {
      console.error('Error fetching compliance setups:', error);
      res.status(500).json({ message: 'Failed to fetch compliance setups' });
    }
  });

  // Create compliance setup
  app.post("/api/compliance-setups", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const setupData = { ...req.body, companyId: req.user.companyId };
      const setup = await storage.createComplianceSetup(setupData);
      
      // Auto-generate compliance data for all projects this employee is assigned to
      const assignments = await storage.getEmployeeAssignmentsByEmployee(setup.employeeId);
      for (const assignment of assignments) {
        if (assignment.deassignDate === null) { // Only active assignments
          await storage.autoGenerateComplianceData(
            req.user.companyId,
            setup.employeeId,
            assignment.projectId
          );
        }
      }
      
      res.json(setup);
    } catch (error) {
      console.error('Error creating compliance setup:', error);
      res.status(500).json({ message: 'Failed to create compliance setup' });
    }
  });

  // Update compliance setup
  app.put("/api/compliance-setups/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const setup = await storage.updateComplianceSetup(id, req.body);
      res.json(setup);
    } catch (error) {
      console.error('Error updating compliance setup:', error);
      res.status(500).json({ message: 'Failed to update compliance setup' });
    }
  });

  // Delete compliance setup
  app.delete("/api/compliance-setups/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteComplianceSetup(id);
      res.json({ message: 'Compliance setup deleted' });
    } catch (error) {
      console.error('Error deleting compliance setup:', error);
      res.status(500).json({ message: 'Failed to delete compliance setup' });
    }
  });

  // Compliances Data API Routes
  
  // Get compliances data by company
  app.get("/api/compliances-data/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const data = await storage.getCompliancesDataByCompany(companyId);
      res.json(data);
    } catch (error) {
      console.error('Error fetching compliances data:', error);
      res.status(500).json({ message: 'Failed to fetch compliances data' });
    }
  });

  // Get compliances data by project and month
  app.get("/api/compliances-data/:companyId/:projectId/:month", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const projectId = parseInt(req.params.projectId);
      const month = req.params.month;
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      const data = await storage.getCompliancesDataByProjectAndMonth(companyId, projectId, month);
      res.json(data);
    } catch (error) {
      console.error('Error fetching compliances data by project and month:', error);
      res.status(500).json({ message: 'Failed to fetch compliances data' });
    }
  });

  // Create compliances data
  app.post("/api/compliances-data", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const complianceData = { ...req.body, companyId: req.user.companyId };
      const data = await storage.createCompliancesData(complianceData);
      res.json(data);
    } catch (error) {
      console.error('Error creating compliances data:', error);
      res.status(500).json({ message: 'Failed to create compliances data' });
    }
  });

  // Update compliances data
  app.put("/api/compliances-data/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const data = await storage.updateCompliancesData(id, req.body);
      res.json(data);
    } catch (error) {
      console.error('Error updating compliances data:', error);
      res.status(500).json({ message: 'Failed to update compliances data' });
    }
  });

  // Delete compliances data
  app.delete("/api/compliances-data/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteCompliancesData(id);
      res.json({ message: 'Compliances data deleted' });
    } catch (error) {
      console.error('Error deleting compliances data:', error);
      res.status(500).json({ message: 'Failed to delete compliances data' });
    }
  });

  // Auto-generate compliance data for all assignments in a project
  app.post("/api/compliances-data/generate/:projectId", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const projectId = parseInt(req.params.projectId);
      await storage.generateComplianceDataForProject(req.user.companyId, projectId);
      res.json({ message: 'Compliance data generated successfully for all assigned employees' });
    } catch (error) {
      console.error('Error generating compliance data:', error);
      res.status(500).json({ message: 'Failed to generate compliance data' });
    }
  });

  // Employee Assignment Routes
  app.get("/api/employee-assignments/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const assignments = await storage.getEmployeeAssignmentsByCompany(companyId);
      res.json(assignments);
    } catch (error: any) {
      console.error("Error fetching employee assignments:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/employee-assignments", authenticateToken, async (req, res) => {
    try {
      const assignmentData = { ...req.body, companyId: req.user.companyId };
      const assignment = await storage.createEmployeeAssignment(assignmentData);
      
      res.json(assignment);
    } catch (error: any) {
      console.error("Error creating employee assignment:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/employee-assignments/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const assignment = await storage.updateEmployeeAssignment(id, req.body);
      res.json(assignment);
    } catch (error: any) {
      console.error("Error updating employee assignment:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/employee-assignments/:id/deassign", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { deassignDate } = req.body;
      const assignment = await storage.updateEmployeeAssignment(id, { deassignDate });
      res.json(assignment);
    } catch (error: any) {
      console.error("Error de-assigning employee:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/employee-assignments/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteEmployeeAssignment(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting employee assignment:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Admin Aadhaar Lookup Route  
  app.post("/api/admin/lookup-employee-by-aadhaar", authenticateToken, async (req, res) => {
    try {
      console.log('🔍 Admin Aadhaar lookup request:', {
        user: req.user.email,
        role: req.user.role,
        body: req.body
      });

      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied. Admin access required.' });
      }

      const { aadhaarNo } = req.body;
      
      if (!aadhaarNo || aadhaarNo.length !== 12) {
        console.log('❌ Invalid Aadhaar number:', aadhaarNo);
        return res.status(400).json({ message: 'Valid 12-digit Aadhaar number is required' });
      }

      console.log('🔎 Looking up employee by Aadhaar:', aadhaarNo);
      
      // Look up employee profile by Aadhaar number
      const employeeProfile = await storage.getEmployeeProfileByAadhaar(aadhaarNo);
      console.log('📋 Employee profile found:', employeeProfile ? 'YES' : 'NO');
      
      if (employeeProfile) {
        // Also get KYC details for this profile
        const kycDetails = await storage.getKycDetailsByProfile(employeeProfile.id);
        console.log('🆔 KYC details found:', kycDetails ? 'YES' : 'NO');
        
        const response = {
          found: true,
          employeeProfile,
          kycDetails: kycDetails || { aadharNo: aadhaarNo }
        };
        
        console.log('✅ Sending success response:', response);
        res.json(response);
      } else {
        console.log('❌ No employee profile found for Aadhaar:', aadhaarNo);
        res.json({
          found: false,
          message: 'No employee profile found with this Aadhaar number'
        });
      }
    } catch (error) {
      console.error('💥 Error in admin Aadhaar lookup:', error);
      res.status(500).json({ message: 'Failed to lookup employee by Aadhaar' });
    }
  });

  // ========== EXCEL EXPORT ROUTES ==========

  // Employee Export to Excel
  app.get("/api/employees/export/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const employees = await storage.getEmployeesByCompany(companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Employees');
      
      // Define columns
      worksheet.columns = [
        { header: 'Employee ID', key: 'employeeId', width: 15 },
        { header: 'First Name', key: 'firstName', width: 20 },
        { header: 'Last Name', key: 'lastName', width: 20 },
        { header: 'Email', key: 'email', width: 30 },
        { header: 'Phone', key: 'phone', width: 15 },
        { header: 'Department', key: 'department', width: 20 },
        { header: 'Position', key: 'position', width: 25 },
        { header: 'Salary', key: 'salary', width: 15 },
        { header: 'Hire Date', key: 'hireDate', width: 15 },
        { header: 'Status', key: 'status', width: 15 },
        { header: 'Address', key: 'address', width: 40 },
        { header: 'Date of Birth', key: 'dateOfBirth', width: 15 },
        { header: 'Emergency Contact', key: 'emergencyContact', width: 25 },
        { header: 'Emergency Phone', key: 'emergencyPhone', width: 20 }
      ];

      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD3D3D3' }
      };

      // Add data rows
      employees.forEach(emp => {
        const department = departments.find(d => d.id === emp.departmentId);
        worksheet.addRow({
          employeeId: emp.employeeId,
          firstName: emp.firstName,
          lastName: emp.lastName,
          email: emp.email,
          phone: emp.phone,
          department: department?.name || 'N/A',
          position: emp.position,
          salary: emp.salary,
          hireDate: emp.hireDate ? new Date(emp.hireDate).toLocaleDateString() : '',
          status: emp.status,
          address: emp.address,
          dateOfBirth: emp.dateOfBirth ? new Date(emp.dateOfBirth).toLocaleDateString() : '',
          emergencyContact: emp.emergencyContact,
          emergencyPhone: emp.emergencyPhone
        });
      });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=employees_${new Date().toISOString().split('T')[0]}.xlsx`);
      
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error('Employee export error:', error);
      res.status(500).json({ message: 'Failed to export employees' });
    }
  });

  // Payroll Export to Excel
  app.get("/api/payroll/export/:companyId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const employees = await storage.getEmployeesByCompany(companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Payroll');
      
      // Define columns
      worksheet.columns = [
        { header: 'Month', key: 'month', width: 12 },
        { header: 'Employee ID', key: 'employeeId', width: 15 },
        { header: 'Employee Name', key: 'employeeName', width: 25 },
        { header: 'Department', key: 'department', width: 20 },
        { header: 'Basic Salary', key: 'basicSalary', width: 15 },
        { header: 'HRA', key: 'hra', width: 15 },
        { header: 'Special Allowance', key: 'specialAllowance', width: 20 },
        { header: 'Transport Allowance', key: 'transportAllowance', width: 20 },
        { header: 'Medical Allowance', key: 'medicalAllowance', width: 18 },
        { header: 'Gross Salary', key: 'grossSalary', width: 15 },
        { header: 'EPF Deduction', key: 'epfDeduction', width: 15 },
        { header: 'ESIC Deduction', key: 'esicDeduction', width: 15 },
        { header: 'TDS Deduction', key: 'tdsDeduction', width: 15 },
        { header: 'PT Deduction', key: 'ptDeduction', width: 15 },
        { header: 'Net Salary', key: 'netSalary', width: 15 },
        { header: 'Payment Status', key: 'paymentStatus', width: 15 }
      ];

      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD3D3D3' }
      };

      // Get actual payroll records for the specified month/year
      const monthlyPayrolls = await storage.getMonthlyPayrolls(companyId);
      const monthlyPayroll = monthlyPayrolls.find(mp => mp.month === month && mp.year === year);
      
      if (!monthlyPayroll) {
        return res.status(404).json({ message: `No payroll found for ${year}-${month.toString().padStart(2, '0')}` });
      }

      const payrollRecords = await storage.getPayrollRecords(monthlyPayroll.id);
      
      // Format month as MMMYY (e.g., "Feb25" for February 2025)
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const monthStr = monthNames[month - 1] + year.toString().slice(-2);
      
      // Guard against empty records
      if (!payrollRecords || payrollRecords.length === 0) {
        return res.status(404).json({ message: `No payroll records found for ${year}-${month.toString().padStart(2, '0')}` });
      }

      console.log('Payroll records count:', payrollRecords.length);
      console.log('First record sample:', JSON.stringify(payrollRecords[0], null, 2));

      // Add data rows using actual payroll records with proper INR formatting
      payrollRecords.forEach((record, index) => {
        // Use actual values from payroll records (already correctly calculated)
        const basicSal = parseFloat(record.basicSalary || '0');
        const hraAmount = parseFloat(record.hra || '0');
        const conveyanceAllowance = parseFloat(record.conveyanceAllowance || '0');
        const otherAllowances = parseFloat(record.otherAllowances || '0');
        const grossSal = parseFloat(record.grossSalary || '0');
        const epfDed = parseFloat(record.epfEmployee || '0');
        const esicDed = parseFloat(record.esicEmployee || '0');
        const tdsDed = parseFloat(record.tdsAmount || '0');
        const ptDed = parseFloat(record.ptAmount || '0');
        const netSal = parseFloat(record.netSalary || '0');

        console.log(`Record ${index + 1}: ${record.employeeName} - Basic: ${basicSal}, Gross: ${grossSal}`);
        
        const row = worksheet.addRow({
          month: monthStr,
          employeeId: record.employeeCode,
          employeeName: record.employeeName,
          department: record.department || 'N/A',
          basicSalary: basicSal,
          hra: hraAmount,
          specialAllowance: conveyanceAllowance,
          transportAllowance: otherAllowances,
          medicalAllowance: 0,
          grossSalary: grossSal,
          epfDeduction: epfDed,
          esicDeduction: esicDed,
          tdsDeduction: tdsDed,
          ptDeduction: ptDed,
          netSalary: netSal,
          paymentStatus: record.paymentStatus === 'paid' ? 'Paid' : 'Pending'
        });

        // Apply INR currency formatting to all money columns
        row.getCell('basicSalary').numFmt = '₹#,##0.00';
        row.getCell('hra').numFmt = '₹#,##0.00';
        row.getCell('specialAllowance').numFmt = '₹#,##0.00';
        row.getCell('transportAllowance').numFmt = '₹#,##0.00';
        row.getCell('medicalAllowance').numFmt = '₹#,##0.00';
        row.getCell('grossSalary').numFmt = '₹#,##0.00';
        row.getCell('epfDeduction').numFmt = '₹#,##0.00';
        row.getCell('esicDeduction').numFmt = '₹#,##0.00';
        row.getCell('tdsDeduction').numFmt = '₹#,##0.00';
        row.getCell('ptDeduction').numFmt = '₹#,##0.00';
        row.getCell('netSalary').numFmt = '₹#,##0.00';
      });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=payroll_${year}_${month.toString().padStart(2, '0')}.xlsx`);
      
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error('Payroll export error:', error);
      res.status(500).json({ message: 'Failed to export payroll' });
    }
  });

  // Compliances Data Export to Excel
  app.get("/api/compliances/export/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const compliancesData = await storage.getCompliancesDataByCompany(companyId);
      const clients = await storage.getClientsByCompany(companyId);
      
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Compliances Data');
      
      // Define columns
      worksheet.columns = [
        { header: 'Client Name', key: 'clientName', width: 25 },
        { header: 'Compliance Type', key: 'complianceType', width: 20 },
        { header: 'Period', key: 'period', width: 15 },
        { header: 'Due Date', key: 'dueDate', width: 15 },
        { header: 'Filing Date', key: 'filingDate', width: 15 },
        { header: 'Status', key: 'status', width: 15 },
        { header: 'Amount', key: 'amount', width: 15 },
        { header: 'Penalty', key: 'penalty', width: 15 },
        { header: 'Total Amount', key: 'totalAmount', width: 15 },
        { header: 'Filed By', key: 'filedBy', width: 20 },
        { header: 'Remarks', key: 'remarks', width: 30 }
      ];

      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD3D3D3' }
      };

      // Add data rows
      compliancesData.forEach(compliance => {
        const client = clients.find(c => c.id === compliance.clientId);
        worksheet.addRow({
          clientName: client?.projectName || 'N/A',
          complianceType: compliance.complianceType,
          period: compliance.period,
          dueDate: compliance.dueDate ? new Date(compliance.dueDate).toLocaleDateString() : '',
          filingDate: compliance.filingDate ? new Date(compliance.filingDate).toLocaleDateString() : '',
          status: compliance.status,
          amount: compliance.amount || '',
          penalty: compliance.penalty || '',
          totalAmount: compliance.totalAmount || '',
          filedBy: compliance.filedBy || '',
          remarks: compliance.remarks || ''
        });
      });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=compliances_${new Date().toISOString().split('T')[0]}.xlsx`);
      
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error('Compliances export error:', error);
      res.status(500).json({ message: 'Failed to export compliances data' });
    }
  });

  // Attendance Export to Excel
  app.get("/api/attendance/export/:companyId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const employees = await storage.getEmployeesByCompany(companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Attendance');
      
      // Define columns
      worksheet.columns = [
        { header: 'Employee ID', key: 'employeeId', width: 15 },
        { header: 'Employee Name', key: 'employeeName', width: 25 },
        { header: 'Department', key: 'department', width: 20 },
        { header: 'Present Days', key: 'presentDays', width: 15 },
        { header: 'Absent Days', key: 'absentDays', width: 15 },
        { header: 'Leave Days', key: 'leaveDays', width: 15 },
        { header: 'Weekly Off', key: 'weeklyOff', width: 15 },
        { header: 'Holidays', key: 'holidays', width: 15 },
        { header: 'Pay Days', key: 'payDays', width: 15 },
        { header: 'OT Hours', key: 'otHours', width: 15 },
        { header: 'Total Hours', key: 'totalHours', width: 15 },
        { header: 'Late Coming', key: 'lateComing', width: 15 },
        { header: 'Early Going', key: 'earlyGoing', width: 15 }
      ];

      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD3D3D3' }
      };

      // Add data rows
      for (const emp of employees) {
        const department = departments.find(d => d.id === emp.departmentId);
        let monthlyRecord = await storage.getMonthlyAttendanceByEmployee(emp.id, year, month);
        
        // If no saved record, calculate defaults
        if (!monthlyRecord) {
          const basePresent = 20 + (emp.id % 5);
          const weeklyOff = 4;
          const leave = emp.id % 3;
          const holidays = 2;
          const payDays = basePresent + weeklyOff + leave + holidays;
          const otHours = (emp.id + 1) * 1.5;
          
          monthlyRecord = {
            presentDays: basePresent,
            payableDays: payDays,
            totalHoursWorked: otHours.toString()
          };
        }

        const presentDays = monthlyRecord.presentDays || 20;
        const weeklyOff = 4;
        const holidays = 2;
        const leaveDays = Math.max(0, (monthlyRecord.payableDays || 26) - presentDays - weeklyOff - holidays);
        const absentDays = 30 - presentDays - leaveDays - weeklyOff - holidays;
        const otHours = parseFloat(monthlyRecord.totalHoursWorked || '0');

        worksheet.addRow({
          employeeId: emp.employeeId,
          employeeName: `${emp.firstName} ${emp.lastName}`,
          department: department?.name || 'N/A',
          presentDays: presentDays,
          absentDays: Math.max(0, absentDays),
          leaveDays: leaveDays,
          weeklyOff: weeklyOff,
          holidays: holidays,
          payDays: monthlyRecord.payableDays || 26,
          otHours: otHours.toFixed(1),
          totalHours: (presentDays * 8 + otHours).toFixed(1),
          lateComing: Math.floor(Math.random() * 5), // Random for demo
          earlyGoing: Math.floor(Math.random() * 3) // Random for demo
        });
      }

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=attendance_${year}_${month.toString().padStart(2, '0')}.xlsx`);
      
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error('Attendance export error:', error);
      res.status(500).json({ message: 'Failed to export attendance' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
