import type { Request } from 'express';

// Extend Express Request interface to include custom user property
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        username: string;
        email: string;
        role: 'system_admin' | 'admin' | 'employee';
        companyId: number | null;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
      };
    }
  }
}

export {};