import { db } from "./db";
import { 
  employees, monthlyAttendance, employeeSalaryStructures, employeePayroll,
  monthlyPayroll, payrollRecords, employeeSalaryComponentValues,
  type MonthlyPayroll, type PayrollRecord,
  type Employee, type SelectEmployeeSalaryStructure, type EmployeePayroll
} from "@shared/schema";
import { eq, and, desc, lte, sql } from "drizzle-orm";

/**
 * Normalized salary structure to handle different data sources consistently
 */
interface NormalizedSalaryStructure {
  basicSalary: string;
  hra: string;
  conveyanceAllowance: string;
  otherAllowances: string;
  grossSalary: string;
  epfEnabled: boolean;
  esicEnabled: boolean;
  lwfEnabled: boolean;
  vpfEnabled: boolean;
  vpfAmount: string;
  tdsEnabled: boolean;
  tdsAmount: string;
  ptEnabled: boolean;
  ptAmount: string;
  bonusEnabled: boolean;
}

/**
 * Centralized PayrollService for automated payroll generation
 * Handles attendance calculation, salary structure lookup, and payroll calculation in one transaction
 */
export class PayrollService {
  
  /**
   * Main entry point - generates complete payroll for a company/month in one shot
   */
  static async generate(companyId: number, year: number, month: number, generatedBy: number): Promise<MonthlyPayroll> {
    console.log(`🚀 PayrollService.generate starting for Company ${companyId}, ${year}-${month}`);

    // 1. Check if payroll already exists
    const existingPayroll = await db
      .select()
      .from(monthlyPayroll)
      .where(
        and(
          eq(monthlyPayroll.companyId, companyId),
          eq(monthlyPayroll.month, month),
          eq(monthlyPayroll.year, year)
        )
      );

    if (existingPayroll.length > 0) {
      console.log(`⚠️  Payroll already exists, deleting and regenerating...`);
      await PayrollService.deleteExistingPayroll(companyId, year, month);
    }

    // 2. Get all active employees
    const activeEmployees = await db
      .select()
      .from(employees)
      .where(
        and(
          eq(employees.companyId, companyId),
          eq(employees.status, 'active')
        )
      );

    console.log(`👥 Found ${activeEmployees.length} active employees`);

    // 3. Create monthly payroll record
    const [createdPayroll] = await db
      .insert(monthlyPayroll)
      .values({
        companyId,
        month,
        year,
        generatedBy,
        status: 'draft'
      })
      .returning();

    console.log(`📊 Created monthly payroll record: ${createdPayroll.id}`);

    // 4. Generate payroll for each employee
    for (const employee of activeEmployees) {
      try {
        await PayrollService.generateEmployeePayroll(employee, createdPayroll, year, month);
      } catch (error) {
        console.error(`❌ Error generating payroll for employee ${employee.id}:`, error);
        // Continue with other employees instead of failing entire payroll
      }
    }

    console.log(`✅ PayrollService.generate completed successfully`);
    return createdPayroll;
  }

  /**
   * Generate payroll for a single employee with automated attendance and salary structure lookup
   */
  private static async generateEmployeePayroll(
    employee: Employee, 
    payroll: MonthlyPayroll, 
    year: number, 
    month: number
  ): Promise<void> {
    console.log(`🧮 Processing employee: ${employee.firstName} ${employee.lastName} (ID: ${employee.id})`);

    // 1. Auto-calculate monthly attendance
    const monthlyAttendanceData = await PayrollService.calculateMonthlyAttendance(
      employee.id, 
      employee.companyId, 
      year, 
      month
    );
    console.log(`📅 Attendance: ${monthlyAttendanceData.presentDays}/${monthlyAttendanceData.payableDays} days`);

    // 2. Get effective salary structure with smart fallback
    const salaryStructure = await PayrollService.getEffectiveSalaryStructure(employee.id, year, month);
    if (!salaryStructure) {
      console.warn(`⚠️  No salary structure found for employee ${employee.id}, skipping`);
      return;
    }

    console.log(`💰 Salary structure found for employee ${employee.id}`);

    // 3. Calculate proportional salary based on attendance
    const calculations = PayrollService.calculateProportionalSalary(salaryStructure, monthlyAttendanceData, year, month);

    // 4. Insert payroll record
    await db.insert(payrollRecords).values({
      monthlyPayrollId: payroll.id,
      employeeId: employee.id,
      companyId: employee.companyId,
      presentDays: monthlyAttendanceData.presentDays,
      weeklyOffs: monthlyAttendanceData.weeklyOffDays,
      leaveDays: (monthlyAttendanceData.paidLeaveDays ?? 0) + (monthlyAttendanceData.unpaidLeaveDays ?? 0),
      holidays: monthlyAttendanceData.holidayDays,
      payableDays: monthlyAttendanceData.payableDays,
      overtimeHours: '0',
      ...calculations
    });

    console.log(`✅ Payroll record created for ${employee.firstName} ${employee.lastName}`);
  }

  /**
   * Smart salary structure lookup with fallback logic
   * 1. Try exact month match in employeeSalaryStructures
   * 2. Fallback to latest structure on or before target month
   * 3. Final fallback to legacy employeePayroll table
   * Returns normalized salary structure for consistent calculations
   */
  private static async getEffectiveSalaryStructure(
    employeeId: number, 
    year: number, 
    month: number
  ): Promise<NormalizedSalaryStructure | null> {
    
    // 1. Try exact month match
    const [exactMatch] = await db
      .select()
      .from(employeeSalaryStructures)
      .where(
        and(
          eq(employeeSalaryStructures.employeeId, employeeId),
          eq(employeeSalaryStructures.year, year),
          eq(employeeSalaryStructures.month, month)
        )
      );

    if (exactMatch) {
      console.log(`🎯 Found exact salary structure for ${year}-${month}`);
      return await PayrollService.normalizeEmployeeSalaryStructure(exactMatch);
    }

    // 2. Fallback to latest structure on or before target month (cross-year search)
    const targetDate = `${year}-${month.toString().padStart(2, '0')}-01`;
    const [fallbackMatch] = await db
      .select()
      .from(employeeSalaryStructures)
      .where(
        and(
          eq(employeeSalaryStructures.employeeId, employeeId),
          // Use string comparison for year-month: "2025-01" <= "2025-01"
          lte(
            sql`${employeeSalaryStructures.year} || '-' || LPAD(${employeeSalaryStructures.month}::text, 2, '0')`,
            sql`${year}::text || '-' || LPAD(${month}::text, 2, '0')`
          )
        )
      )
      .orderBy(desc(employeeSalaryStructures.year), desc(employeeSalaryStructures.month))
      .limit(1);

    if (fallbackMatch) {
      console.log(`🔄 Using fallback salary structure from ${fallbackMatch.year}-${fallbackMatch.month}`);
      return await PayrollService.normalizeEmployeeSalaryStructure(fallbackMatch);
    }

    // 3. Final fallback to legacy employeePayroll
    const [legacyPayroll] = await db
      .select()
      .from(employeePayroll)
      .where(eq(employeePayroll.employeeId, employeeId))
      .orderBy(desc(employeePayroll.updatedAt))
      .limit(1);

    if (legacyPayroll) {
      console.log(`🔄 Using legacy employeePayroll structure`);
      return PayrollService.normalizeEmployeePayroll(legacyPayroll);
    }

    console.error(`❌ No salary structure found for employee ${employeeId}`);
    return null;
  }

  /**
   * Auto-calculate monthly attendance or fetch existing data
   */
  private static async calculateMonthlyAttendance(
    employeeId: number, 
    companyId: number, 
    year: number, 
    month: number
  ) {
    // Try to get existing monthly attendance
    const [existingAttendance] = await db
      .select()
      .from(monthlyAttendance)
      .where(
        and(
          eq(monthlyAttendance.employeeId, employeeId),
          eq(monthlyAttendance.year, year),
          eq(monthlyAttendance.month, month)
        )
      );

    const totalDaysInMonth = new Date(year, month, 0).getDate(); // Days in month
    
    // If attendance exists, preserve all existing attendance data unchanged
    if (existingAttendance && (existingAttendance.presentDays ?? 0) > 0) {
      console.log(`📅 Using existing attendance with unpaidLeaveDays=${existingAttendance.unpaidLeaveDays}`);
      console.log(`📅 Preserving existing payableDays: ${existingAttendance.payableDays}`);
      
      // Return existing attendance data without any modifications
      // This preserves the actual attendance recorded by the system
      return existingAttendance;
    }

    // Only auto-calculate when no attendance data exists
    console.log(`📅 No existing attendance found, auto-calculating...`);
    
    // Count actual Sundays in the month (6-day work week is standard in India)
    let sundays = 0;
    for (let day = 1; day <= totalDaysInMonth; day++) {
      const date = new Date(year, month - 1, day);
      if (date.getDay() === 0) { // Sunday = 0
        sundays++;
      }
    }
    
    const workingDays = totalDaysInMonth - sundays; // Actual working days
    
    // Default to 90% attendance if no data exists
    const presentDays = Math.floor(workingDays * 0.9);
    const absentDays = workingDays - presentDays;
    
    // For auto-calculation, default to no unpaid leaves (full month pay)
    const unpaidLeaveDays = 0; // Default: no unpaid leaves for auto-calculation
    const payableDays = totalDaysInMonth - unpaidLeaveDays; // User's formula: total - unpaid

    const calculatedAttendance = {
      employeeId,
      companyId,
      year,
      month,
      totalWorkingDays: workingDays,
      presentDays,
      absentDays,
      halfDays: 0,
      lateDays: 0,
      paidLeaveDays: workingDays - presentDays, // Absent days treated as paid leave
      unpaidLeaveDays,
      compOffDays: 0,
      weeklyOffDays: sundays,
      holidayDays: 0,
      payableDays, // Key fix: Total days minus unpaid leaves (31-0=31 for full month)
      totalHoursWorked: presentDays * 8,
      averageCheckInTime: null,
      averageCheckOutTime: null,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    // Insert new attendance record (convert totalHoursWorked to string for decimal column)
    const attendanceForDb = {
      ...calculatedAttendance,
      totalHoursWorked: calculatedAttendance.totalHoursWorked.toString()
    };
    
    await db
      .insert(monthlyAttendance)
      .values(attendanceForDb);

    console.log(`📅 Auto-calculated attendance: Present=${presentDays}, Payable=${payableDays}, Working=${workingDays}, Total=${totalDaysInMonth} days`);
    return calculatedAttendance;
  }

  /**
   * Calculate proportional salary based on attendance using normalized salary structure
   */
  private static calculateProportionalSalary(
    salaryStructure: NormalizedSalaryStructure,
    attendance: any,
    year: number,
    month: number
  ) {
    // Extract salary components from normalized structure
    const basicSalary = parseFloat(salaryStructure.basicSalary || '0');
    const hra = parseFloat(salaryStructure.hra || '0');
    const conveyanceAllowance = parseFloat(salaryStructure.conveyanceAllowance || '0');
    const otherAllowances = parseFloat(salaryStructure.otherAllowances || '0');
    const grossSalary = parseFloat(salaryStructure.grossSalary || '0');

    // Calculate proportion based on payable days
    const totalMonthDays = new Date(year, month, 0).getDate();
    const payableDays = Math.max(0, attendance.payableDays || 0);
    const proportionFactor = Math.max(0, Math.min(1, payableDays / totalMonthDays));
    
    console.log(`💰 Calculation: Gross=${grossSalary}, PayableDays=${payableDays}, TotalDays=${totalMonthDays}, Factor=${proportionFactor}`);

    // Apply proportional calculation
    const proportionalBasicSalary = Math.round((basicSalary * proportionFactor) * 100) / 100;
    const proportionalHra = Math.round((hra * proportionFactor) * 100) / 100;
    const proportionalConveyanceAllowance = Math.round((conveyanceAllowance * proportionFactor) * 100) / 100;
    const proportionalOtherAllowances = Math.round((otherAllowances * proportionFactor) * 100) / 100;
    const proportionalGrossSalary = Math.round((grossSalary * proportionFactor) * 100) / 100;

    // Calculate deductions
    let epfEmployee = 0, esicEmployee = 0, lwfEmployee = 0;
    let vpfAmount = 0, tdsAmount = 0, ptAmount = 0;

    if (salaryStructure.epfEnabled) {
      // Apply EPF ceiling as per Indian regulations (₹15,000 max for EPF calculation)
      const epfBasicSalary = Math.min(proportionalBasicSalary, 15000);
      epfEmployee = Math.round((epfBasicSalary * 0.12) * 100) / 100;
    }
    if (salaryStructure.esicEnabled) {
      esicEmployee = Math.round((proportionalGrossSalary * 0.0075) * 100) / 100;
    }
    if (salaryStructure.lwfEnabled) {
      lwfEmployee = Math.round((10 * proportionFactor) * 100) / 100;
    }
    if (salaryStructure.vpfEnabled && salaryStructure.vpfAmount) {
      vpfAmount = Math.round((parseFloat(salaryStructure.vpfAmount) * proportionFactor) * 100) / 100;
    }
    if (salaryStructure.tdsEnabled && salaryStructure.tdsAmount) {
      tdsAmount = Math.round((parseFloat(salaryStructure.tdsAmount) * proportionFactor) * 100) / 100;
    }
    if (salaryStructure.ptEnabled && salaryStructure.ptAmount) {
      ptAmount = Math.round((parseFloat(salaryStructure.ptAmount) * proportionFactor) * 100) / 100;
    }

    const totalDeductions = Math.round((epfEmployee + esicEmployee + lwfEmployee + vpfAmount + tdsAmount + ptAmount) * 100) / 100;

    // Calculate employer contributions
    let epfEmployer = 0, epfAdmin = 0, esicEmployer = 0, lwfEmployer = 0, bonus = 0;

    if (salaryStructure.epfEnabled) {
      // Apply EPF ceiling as per Indian regulations (₹15,000 max for EPF calculation)
      const epfBasicSalary = Math.min(proportionalBasicSalary, 15000);
      epfEmployer = Math.round((epfBasicSalary * 0.12) * 100) / 100;
      epfAdmin = Math.round((epfBasicSalary * 0.01) * 100) / 100;
    }
    if (salaryStructure.esicEnabled) {
      esicEmployer = Math.round((proportionalGrossSalary * 0.0325) * 100) / 100;
    }
    if (salaryStructure.lwfEnabled) {
      lwfEmployer = Math.round((10 * proportionFactor) * 100) / 100;
    }
    if (salaryStructure.bonusEnabled) {
      bonus = Math.round((proportionalGrossSalary * 0.0833) * 100) / 100;
    }

    const totalEmployerContributions = Math.round((epfEmployer + epfAdmin + esicEmployer + lwfEmployer + bonus) * 100) / 100;

    // Final calculations
    const netSalary = Math.round((proportionalGrossSalary - totalDeductions) * 100) / 100;
    const ctc = Math.round((proportionalGrossSalary + totalEmployerContributions) * 100) / 100;

    return {
      basicSalary: proportionalBasicSalary.toFixed(2),
      hra: proportionalHra.toFixed(2),
      conveyanceAllowance: proportionalConveyanceAllowance.toFixed(2),
      otherAllowances: proportionalOtherAllowances.toFixed(2),
      grossSalary: proportionalGrossSalary.toFixed(2),
      overtimeAmount: '0',
      epfEmployee: epfEmployee.toFixed(2),
      esicEmployee: esicEmployee.toFixed(2),
      lwfEmployee: lwfEmployee.toFixed(2),
      vpfAmount: vpfAmount.toFixed(2),
      tdsAmount: tdsAmount.toFixed(2),
      ptAmount: ptAmount.toFixed(2),
      totalDeductions: totalDeductions.toFixed(2),
      epfEmployer: epfEmployer.toFixed(2),
      epfAdmin: epfAdmin.toFixed(2),
      esicEmployer: esicEmployer.toFixed(2),
      lwfEmployer: lwfEmployer.toFixed(2),
      bonus: bonus.toFixed(2),
      totalEmployerContributions: totalEmployerContributions.toFixed(2),
      netSalary: netSalary.toFixed(2),
      ctc: ctc.toFixed(2)
    };
  }

  /**
   * Helper to delete existing payroll for regeneration
   */
  private static async deleteExistingPayroll(companyId: number, year: number, month: number): Promise<void> {
    // First delete payroll records
    const [existingPayroll] = await db
      .select()
      .from(monthlyPayroll)
      .where(
        and(
          eq(monthlyPayroll.companyId, companyId),
          eq(monthlyPayroll.month, month),
          eq(monthlyPayroll.year, year)
        )
      );

    if (existingPayroll) {
      await db
        .delete(payrollRecords)
        .where(eq(payrollRecords.monthlyPayrollId, existingPayroll.id));

      await db
        .delete(monthlyPayroll)
        .where(eq(monthlyPayroll.id, existingPayroll.id));

      console.log(`🗑️  Deleted existing payroll for regeneration`);
    }
  }

  /**
   * Normalize employeeSalaryStructures data to consistent interface
   */
  private static async normalizeEmployeeSalaryStructure(structure: SelectEmployeeSalaryStructure): Promise<NormalizedSalaryStructure> {
    let basicSalary = structure.earningHead1 || '0';
    let hra = structure.earningHead2 || '0';
    let conveyanceAllowance = structure.earningHead3 || '0';
    let otherAllowances = structure.earningHead4 || '0';

    // If earningHead fields are zero (legacy structures), fall back to component values
    if (basicSalary === '0' && hra === '0' && conveyanceAllowance === '0' && otherAllowances === '0') {
      try {
        const components = await db
          .select()
          .from(employeeSalaryComponentValues)
          .where(
            and(
              eq(employeeSalaryComponentValues.structureId, structure.id),
              eq(employeeSalaryComponentValues.isEmployerCost, false)
            )
          );

        const basicComponent = components.find(c => c.componentKey === 'basic');
        const hraComponent = components.find(c => c.componentKey === 'hra');
        const conveyanceComponent = components.find(c => c.componentKey === 'conveyance');
        const otherComponent = components.find(c => c.componentKey === 'other');

        basicSalary = basicComponent?.amount || '0';
        hra = hraComponent?.amount || '0';
        conveyanceAllowance = conveyanceComponent?.amount || '0';
        otherAllowances = otherComponent?.amount || '0';

        console.log(`🔄 Used component values fallback for structure ${structure.id}: Basic=${basicSalary}, HRA=${hra}, Conv=${conveyanceAllowance}, Other=${otherAllowances}`);
      } catch (error) {
        console.warn(`⚠️  Failed to fetch component values for structure ${structure.id}:`, error);
      }
    }

    return {
      basicSalary,
      hra,
      conveyanceAllowance,
      otherAllowances,
      grossSalary: structure.grossValue || '0',
      epfEnabled: structure.epfEnabled || false,
      esicEnabled: structure.esicEnabled || false,
      lwfEnabled: structure.lwfEnabled || false,
      vpfEnabled: structure.vpfEnabled || false,
      vpfAmount: (structure.vpfAmount && structure.vpfAmount.trim()) || '0',
      tdsEnabled: structure.tdsEnabled || false,
      tdsAmount: (structure.tdsAmount && structure.tdsAmount.trim()) || '0',
      ptEnabled: structure.ptEnabled || false,
      ptAmount: (structure.ptAmount && structure.ptAmount.trim()) || '0',
      bonusEnabled: structure.bonusEnabled || false
    };
  }

  /**
   * Normalize legacy employeePayroll data to consistent interface
   */
  private static normalizeEmployeePayroll(payroll: EmployeePayroll): NormalizedSalaryStructure {
    return {
      basicSalary: payroll.earningHead1 || '0',
      hra: payroll.earningHead2 || '0', 
      conveyanceAllowance: payroll.earningHead3 || '0',
      otherAllowances: payroll.earningHead4 || '0',
      grossSalary: payroll.grossValue || '0',
      epfEnabled: payroll.epfEnabled || false,
      esicEnabled: payroll.esicEnabled || false,
      lwfEnabled: payroll.lwfEnabled || false,
      vpfEnabled: payroll.vpfEnabled || false,
      vpfAmount: (payroll.vpfAmount && payroll.vpfAmount.trim()) || '0',
      tdsEnabled: payroll.tdsEnabled || false,
      tdsAmount: (payroll.tdsAmount && payroll.tdsAmount.trim()) || '0',
      ptEnabled: payroll.ptEnabled || false,
      ptAmount: (payroll.ptAmount && payroll.ptAmount.trim()) || '0',
      bonusEnabled: payroll.bonusEnabled || false
    };
  }
}